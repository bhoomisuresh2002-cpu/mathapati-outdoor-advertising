<?php
/**
 * MATHAPATI Outdoor Advertising - Contact Form Processor
 * Headquartered in Vijayanagar, Bengaluru, Karnataka
 * Contact: mathapati327@gmail.com | +91 90609 16193
 */

// Set headers for JSON response and CORS
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed. Only POST requests are accepted.'
    ]);
    exit;
}

// Read raw JSON input or POST form data
$rawInput = file_get_contents('php://input');
$inputData = json_decode($rawInput, true);

if (!$inputData) {
    $inputData = $_POST;
}

// Sanitize inputs
$name    = isset($inputData['name']) ? trim(strip_tags($inputData['name'])) : '';
$email   = isset($inputData['email']) ? filter_var(trim($inputData['email']), FILTER_SANITIZE_EMAIL) : '';
$phone   = isset($inputData['phone']) ? trim(strip_tags($inputData['phone'])) : '';
$company = isset($inputData['company']) ? trim(strip_tags($inputData['company'])) : 'Not specified';
$service = isset($inputData['service']) ? trim(strip_tags($inputData['service'])) : 'General Inquiry';
$message = isset($inputData['message']) ? trim(strip_tags($inputData['message'])) : '';

// Validation
if (empty($name) || empty($phone)) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Please provide both your name and contact phone number.'
    ]);
    exit;
}

// Recipient details
$toEmail = 'mathapati327@gmail.com';
$subject = "New OOH Campaign Inquiry: " . $name . " (" . $company . ")";

// Construct email body
$emailBody = "=================================================\n";
$emailBody .= "MATHAPATI OUTDOOR ADVERTISING - CAMPAIGN INQUIRY\n";
$emailBody .= "=================================================\n\n";
$emailBody .= "Client Name:  " . $name . "\n";
$emailBody .= "Phone Number: " . $phone . "\n";
$emailBody .= "Email:        " . ($email ?: 'Not provided') . "\n";
$emailBody .= "Company:      " . $company . "\n";
$emailBody .= "Service:      " . $service . "\n";
$emailBody .= "Submission:   " . date('Y-m-d H:i:s') . " IST\n\n";
$emailBody .= "Campaign Scope & Details:\n";
$emailBody .= ($message ?: 'Client requested quick phone consultation.') . "\n\n";
$emailBody .= "=================================================\n";
$emailBody .= "Submitted via Mathapati Outdoor Advertising Portal\n";

$headers = [];
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/plain; charset=utf-8';
$headers[] = 'From: Mathapati Web Inquiries <noreply@mathapatiadvertising.com>';
if (!empty($email)) {
    $headers[] = 'Reply-To: ' . $email;
}

// Attempt mail sending
$mailSent = @mail($toEmail, $subject, $emailBody, implode("\r\n", $headers));

// Log submission locally if possible
$logEntry = date('[Y-m-d H:i:s]') . " Inquiry from {$name} ({$phone}) - Service: {$service}\n";
@file_put_contents(__DIR__ . '/inquiries.log', $logEntry, FILE_APPEND);

// Success Response
http_response_code(200);
echo json_encode([
    'status' => 'success',
    'message' => 'Thank you for reaching out to MATHAPATI Outdoor Advertising. Our campaign planning team has received your request and will contact you promptly.',
    'data' => [
        'name' => $name,
        'phone' => $phone,
        'service' => $service
    ]
]);
?>

export interface ServiceItem {
  id: string;
  title: string;
  category: string;
  shortDesc: string;
  fullDesc: string;
  iconName: string;
  features: string[];
  metrics: string;
  tag: string;
}

export interface IndustryItem {
  id: string;
  title: string;
  tagline: string;
  description: string;
  icon: string;
  image?: string;
  sampleCampaigns: string;
  recommendedFormats: string[];
}

export interface ClientItem {
  id: string;
  name: string;
  category: string;
  highlight: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  client: string;
  category: 'Billboards' | 'LED' | 'Bus Branding' | 'Auto Branding' | 'Jewellery Campaigns' | 'Property Campaigns' | 'Government Campaigns' | 'Retail Campaigns';
  location: string;
  format: string;
  imageUrl: string;
  description: string;
  coordinates?: string;
  featured?: boolean;
}

export interface MilestoneItem {
  year: string;
  title: string;
  description: string;
}

export interface ProcessStep {
  stepNumber: number;
  title: string;
  subtitle: string;
  description: string;
  deliverables: string[];
}

export interface CoverageLocation {
  id: string;
  name: string;
  kannadaName: string;
  type: 'Metro HQ' | 'Expressway Corridor' | 'Highway Junction' | 'Tier-2 City';
  holdingsCount: number;
  description: string;
  topSpots: string[];
  coordinates: { x: number; y: number }; // percentage on custom Karnataka map
}

export interface PlannerState {
  businessType: string;
  location: string;
  budget: string;
  adFormat: string;
}

export interface PlannerRecommendation {
  planTitle: string;
  estimatedReach: string;
  recommendedUnits: string;
  optimalDuration: string;
  formats: string[];
  suggestedLocations: string[];
  approximateCost: string;
}

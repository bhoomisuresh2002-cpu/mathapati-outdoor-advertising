import { ServiceItem, IndustryItem, ClientItem, GalleryItem, MilestoneItem, ProcessStep, CoverageLocation } from '../types';

export const COMPANY_INFO = {
  name: "MATHAPATI Outdoor Advertising",
  shortName: "Mathapati Ads",
  brandMark: "MATHAPATI ADS Bangalore",
  tagline: "Outdoor Advertising That Makes Your Brand Impossible to Miss",
  establishedYear: 2006,
  experienceYears: "20+",
  founderExperienceYears: "30+",
  holdingsCount: "100+",
  coverage: "Karnataka-Wide Reach",
  founder: {
    name: "Shivakumar Mathapati",
    role: "Founder & Industry Professional",
    experience: "30+ Years Industry Experience",
    bio: "With over three decades of pioneering leadership in outdoor media, government liaisoning, and high-impact physical advertising, Shivakumar Mathapati has guided MATHAPATI Outdoor Advertising from its inception in 2006 into one of Karnataka's most trusted OOH (Out-of-Home) advertising authorities. His strategic mastery in identifying prime arterial junctions and arterial highway corridors ensures that every client campaign delivers unmatched daily impressions and brand recall.",
    quote: "In an era of fleeting digital scrolls, commanding physical outdoor presence delivers unskippable permanence, civic authority, and emotional brand trust that no small screen can match."
  },
  contact: {
    address: "Vijayanagar, Bengaluru, Karnataka 560040, India",
    city: "Bengaluru",
    state: "Karnataka",
    pincode: "560040",
    phone: "9060916193",
    displayPhone: "+91 90609 16193",
    whatsapp: "9060916193",
    displayWhatsapp: "+91 90609 16193",
    email: "mathapati327@gmail.com",
    workingHours: "Monday – Saturday: 9:00 AM – 8:00 PM IST",
    googleMapsShareUrl: "https://share.google/1KA6b5m27Imj4qZ5h",
    mapEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15552.339678129757!2d77.52554765!3d12.9664536!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae3ddb4a0f4435%3A0x6b8bc27c6536b32b!2sVijayanagar%2C%20Bengaluru%2C%20Karnataka!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
  },
  socials: {
    facebook: "https://facebook.com/mathapatiads",
    instagram: "https://instagram.com/mathapatiads",
    youtube: "https://youtube.com/@mathapatioutdooradvertising",
    gmail: "mailto:mathapati327@gmail.com"
  }
};

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "outdoor-billboards",
    title: "Outdoor Billboard Advertising",
    category: "High-Impact OOH",
    shortDesc: "Monolithic unipoles, double-sided gantries, and prime highway hoardings positioned at high-dwell junctions.",
    fullDesc: "Our flagship outdoor billboards command the skyline across Karnataka's busiest expressways, ring roads, and arterial intersections. Built with heavy-duty structural engineering, front-lit & backlit luminaire fixtures, and premium high-gauge anti-fade vinyl, our hoardings guarantee maximum visibility 24 hours a day, 365 days a year.",
    iconName: "Monitor",
    metrics: "250K+ Daily Eyeballs per Site",
    tag: "Most Popular",
    features: [
      "Custom Unipoles, Cantilever Gantries & Sky-High Roof Mounts",
      "Prime Spots on Mysore-Bangalore Expressway, Airport Road & Ring Roads",
      "Day & Night 5000K High-CRI LED Floodlight Illumination",
      "End-to-end Municipal Approvals & Structural Stability Certification"
    ]
  },
  {
    id: "led-advertising",
    title: "LED Digital Advertising",
    category: "Digital OOH (DOOH)",
    shortDesc: "Ultra-bright dynamic LED display screens with vibrant color fidelity and dynamic motion creative slots.",
    fullDesc: "Step into modern programmatic digital outdoor advertising with our high-pitch LED screens positioned at central commercial junctions. Deliver real-time message swapping, high-definition video loops, and eye-level digital clarity that captures pedestrian and vehicular traffic alike.",
    iconName: "Tv",
    metrics: "Dynamic Motion & 100% Contrast",
    tag: "High Engagement",
    features: [
      "High-Nit Weatherproof IP65 Outdoor Displays for Bright Daylight",
      "Dynamic Content Scheduling by Time of Day and Day of Week",
      "Zero Glare High Refresh Rate Video Panels",
      "Rapid Turnaround for Festive Offers & Flash Campaigns"
    ]
  },
  {
    id: "bus-shelter-advertising",
    title: "Bus Shelter Advertising",
    category: "Street Furniture",
    shortDesc: "Illuminated eye-level bus queue shelters along urban transit routes with guaranteed commuter dwell times.",
    fullDesc: "Bus shelters offer prolonged visual contact with urban commuters, pedestrians, and slow-moving street traffic. Placed at strategic neighborhood boarding points throughout Bengaluru and key Karnataka districts, our backlit bus stop panels offer intimate, readable brand immersion.",
    iconName: "Building2",
    metrics: "12-18 Min Avg Commuter Dwell",
    tag: "Hyper-Local Reach",
    features: [
      "Uniform Backlit Edge-to-Edge Acrylic Lightboxes",
      "Coverage in Dense Residential, IT Hub & College Corridors",
      "Eye-Level Reading Height for Commuters & Shoppers",
      "Vandal-Resistant Polycarbonate Protective Shielding"
    ]
  },
  {
    id: "bus-branding",
    title: "Bus Branding & Fleet Advertising",
    category: "Transit Media",
    shortDesc: "Moving billboards on BMTC and KSRTC fleets traveling across city arterial routes and interstate corridors.",
    fullDesc: "Transform public transport vehicles into giant moving advertisements that penetrate every urban corner and highway stretch. From full bus vinyl wraps to high-visibility rear panels, our bus advertising commands attention across the entire city layout every single hour of the day.",
    iconName: "Bus",
    metrics: "80+ Kms Travel Daily per Bus",
    tag: "City-Wide Mobility",
    features: [
      "Full Body Wraps, Left/Right Side Banners & Rear Back Glass",
      "Routes Covering Majestic, Electronic City, Whitefield & Outer Ring",
      "Premium 3M Cast Vinyl with UV Protective Gloss Laminate",
      "Route-Specific Targeting for Precision Audience Exposure"
    ]
  },
  {
    id: "auto-branding",
    title: "Auto-Rickshaw Branding",
    category: "Hyperlocal Transit",
    shortDesc: "Fleet auto back hoods and full hood covers penetrating interior alleys, residential pockets, and local markets.",
    fullDesc: "Auto-rickshaws are the lifeline of Bengaluru street transport. With fleet back hood advertising, your brand navigates dense traffic jams, inner residential layouts, metro stations, and bustling market roads where traditional billboards cannot reach.",
    iconName: "Car",
    metrics: "Thousands of Daily City Streets",
    tag: "Maximum Frequency",
    features: [
      "High-Tension Heavy-Duty Rexene Hood Backs with Screen Printing",
      "Unmatched In-Traffic Proximity for Following Motorists",
      "Cost-Effective Mass Fleet Deployments (100 to 1,000+ Autos)",
      "Pin-Code Specific Regional Targeting Across Bengaluru"
    ]
  },
  {
    id: "transit-mobile-branding",
    title: "Mobile & Transit Branding",
    category: "Specialty Transit",
    shortDesc: "Dedicated mobile display vans, promotional roadshow trucks, and customized promotional vehicles.",
    fullDesc: "Take your campaign directly to your customer's doorstep with customized promotional vehicles, roadshow vans, and illuminated mobile display platforms equipped with sound systems and interactive product demo zones.",
    iconName: "Navigation",
    metrics: "100% Flexible Geographic Routes",
    tag: "Interactive Events",
    features: [
      "Illuminated Mobile Box Trucks & Glass Showcase Vans",
      "Route Flexibility Tailored to Roadshows, Product Launches & Rallies",
      "Integrated Audio System & Brand Promoters Assistance",
      "GPS Tracked Route Verification & Performance Reporting"
    ]
  },
  {
    id: "property-advertising",
    title: "Property & Real Estate Advertising",
    category: "Sector Solutions",
    shortDesc: "Commanding site boundary hoardings, on-location project launch unipoles, and highway directional gantries.",
    fullDesc: "We specialize in end-to-end outdoor media strategies for premier real estate developers. From perimeter barricade branding and grand entrance unipoles to high-frequency directional highway hoardings guiding prospective buyers directly to project model sites.",
    iconName: "Home",
    metrics: "Direct High-Net-Worth Buyer Leads",
    tag: "Real Estate Elite",
    features: [
      "Perimeter Boundary Wall Branding & Mega Construction Site Hoardings",
      "Highway Directional Markers Leading to Plotted & Villa Developments",
      "High-Luxury Aesthetics Tailored to HNIs & Investors",
      "Rapid Turnaround for Weekend Property Expo Launches"
    ]
  },
  {
    id: "digital-integrated-marketing",
    title: "Digital Marketing & Campaign Integration",
    category: "Omnichannel",
    shortDesc: "Synchronizing physical outdoor hoardings with localized geofenced digital ads for amplified conversion.",
    fullDesc: "Bridge the physical and digital world with synergistic media planning. When audiences drive past your Mathapati billboard, our digital ad sync triggers geofenced mobile social media and search ads on their smartphones, multiplying brand recall and inquiry conversions.",
    iconName: "Globe",
    metrics: "3.5x Brand Recall Amplification",
    tag: "Omnichannel Synergy",
    features: [
      "Mobile Geofencing Around Outdoor Hoarding Hotspots",
      "QR Code Scans & WhatsApp Direct Lead Routing",
      "High-Resolution Campaign Photography & Drone Footage",
      "Cross-Channel Performance Metrics & Traffic Footfall Analytics"
    ]
  }
];

export const INDUSTRIES_DATA: IndustryItem[] = [
  {
    id: "real-estate",
    title: "Real Estate",
    tagline: "Guiding homebuyers straight from highway to luxury project site.",
    description: "Location is everything in real estate. We deliver high-impact directional hoardings and grand site unipoles along the Mysore-Bangalore Expressway, Doddaballapura Highway, and Airport Road for prestigious developers such as Srigandha FarmVilla, Nischitha Properties, Concorde, Century, and Nambiar.",
    icon: "Building",
    image: "/images/industries/real_estate.jpg",
    sampleCampaigns: "Srigandha FarmVilla Mega Hoarding, Nischitha Properties BMRDA Plots Launch",
    recommendedFormats: ["Mega Highway Billboards", "Site Perimeter Hoardings", "Route Directional Gantries"]
  },
  {
    id: "automotive",
    title: "Automotive",
    tagline: "High-speed recall along automotive dealership highways and toll plazas.",
    description: "Reaching prospective vehicle buyers and daily motorists at eye-level with commanding highway gantries, flyover hoardings, and arterial dealership wayfinding.",
    icon: "Car",
    image: "/images/industries/automotive.jpg",
    sampleCampaigns: "New Model Highway Launches, Festival Exchange Carnival Hoardings",
    recommendedFormats: ["Overhead Highway Gantries", "Cantilever Billboards", "Arterial Junction Unipoles"]
  },
  {
    id: "retail",
    title: "Retail",
    tagline: "Hyperlocal footfall drivers for everyday shopping giants.",
    description: "Driving shoppers through supermarket doors requires relentless repetition and proximity to residential clusters. Our bus shelters, auto branding, and arterial hoardings have consistently powered launches and weekend sales for retail titans like DMart.",
    icon: "ShoppingBag",
    image: "/images/industries/retail.jpg",
    sampleCampaigns: "DMart Store Openings, Festive Super Saver Weeks, FMCG Product Showcases",
    recommendedFormats: ["Bus Queue Shelters", "Auto Hood Branding", "Commercial Junction Billboards"]
  },
  {
    id: "fmcg",
    title: "FMCG",
    tagline: "Unmissable shelf-to-street familiarity for household staples.",
    description: "Dominating consumer minds on their daily commute before they step into grocery stores, pairing bus fleet wraps and neighborhood arterial billboards for mass household penetration.",
    icon: "Package",
    image: "/images/industries/fmcg.jpg",
    sampleCampaigns: "KLF Nirmal Coconut Oil Transit Blitz, Seasonal Consumer Goods Drives",
    recommendedFormats: ["Transit Bus Wraps", "Bilingual Hoardings", "Marketplace Cantilevers"]
  },
  {
    id: "healthcare",
    title: "Healthcare",
    tagline: "Vital wayfinding and life-saving trust at key transit junctions.",
    description: "Directing patients and emergency traffic to premier hospitals and diagnostic centers with clear, authoritative illuminated directional signage and junction hoardings.",
    icon: "Activity",
    image: "/images/industries/healthcare.jpg",
    sampleCampaigns: "Multi-Speciality Hospital Launches, Free Health Checkup Camps, 24/7 Emergency Care",
    recommendedFormats: ["Illuminated Unipoles", "Emergency Corridor Gantries", "Bus Shelter Signage"]
  },
  {
    id: "education",
    title: "Education",
    tagline: "Driving annual admissions and establishing academic prestige.",
    description: "Schools and universities rely on timely, geographic-targeted outdoor visibility during admission windows. MATHAPATI has spearheaded enrollment campaigns for leading institutions including HARS International Public School, BN International School, and Kids International School.",
    icon: "GraduationCap",
    image: "/images/industries/education.jpg",
    sampleCampaigns: "HARS International Public School Admissions, BN International Annual Campaigns",
    recommendedFormats: ["Neighborhood Bus Shelters", "Residential Junction Hoardings", "School Bus Fleet"]
  },
  {
    id: "hospitality",
    title: "Hospitality",
    tagline: "Irresistible dining calls that turn hungry highway commuters into guests.",
    description: "Travelers on Karnataka's bustling highways make stopover decisions based on eye-catching outdoor signage. Our highway gantries for iconic hospitality giants like A2B (Adyar Ananda Bhavan) and Nandi Upachar consistently fill restaurant parking lots.",
    icon: "Utensils",
    image: "/images/industries/hospitality.jpg",
    sampleCampaigns: "A2B Expressway Rest Stops, Nandi Upachar Highway Dining Signboards",
    recommendedFormats: ["Expressway Countdown Hoardings", "Exit Point Gantries", "Highway Cantilevers"]
  },
  {
    id: "corporate",
    title: "Corporate",
    tagline: "Commanding institutional authority and nationwide consumer confidence.",
    description: "State Bank of India (SBI) and leading financial institutions trust MATHAPATI for high-stakes seasonal loan campaigns, festive banking drives, and corporate trust building with massive arterial gantries across Karnataka.",
    icon: "Briefcase",
    image: "/images/industries/corporate.jpg",
    sampleCampaigns: "SBI Deepavali Festive Housing & Gold Loan Mega Campaigns across Bengaluru",
    recommendedFormats: ["Double-Sided Arterial Gantries", "Transit Route Domination", "Promotional Vans"]
  },
  {
    id: "entertainment",
    title: "Entertainment",
    tagline: "Electrifying blockbuster releases and premier live event anticipation.",
    description: "Maximizing opening weekend buzz and ticket bookings with high-impact mega hoardings at premier entertainment corridors, multiplex surroundings, and nightlife districts.",
    icon: "Film",
    image: "/images/industries/entertainment.jpg",
    sampleCampaigns: "Kannada & Pan-India Movie Premieres, Stadium Concert Blitzes",
    recommendedFormats: ["Mega City Hoardings", "Transit Full Wraps", "Flyover High-Impact Banners"]
  },
  {
    id: "transit",
    title: "Transit",
    tagline: "Mobile moving billboards reaching every corner of Karnataka.",
    description: "Continuous moving frequency covering arterial roads, suburban centers, and highway commuters daily with BMTC bus wraps, auto fleet hoods, and specialized transit vehicles.",
    icon: "Bus",
    image: "/images/industries/transit.jpg",
    sampleCampaigns: "Statewide Bus Fleet Domination, Hyperlocal Auto Rickshaw Networks",
    recommendedFormats: ["BMTC Bus Full Body Wraps", "Rear Glass Banners", "Auto Hood Advertising"]
  },
  {
    id: "infrastructure",
    title: "Infrastructure",
    tagline: "Commanding national and state highway transit spans.",
    description: "Large-span gantries and structural unipoles along newly commissioned expressways and industrial corridors, ensuring unmissable long-distance line-of-sight for intercity travelers.",
    icon: "Navigation",
    image: "/images/industries/infrastructure.jpg",
    sampleCampaigns: "Mysuru Expressway Toll Plaza Gantries, Airport Expressway Unipoles",
    recommendedFormats: ["Overhead Expressway Gantries", "Cantilever Portals", "Bridge Crossing Displays"]
  },
  {
    id: "digital-ooh",
    title: "Digital OOH",
    tagline: "Dynamic, high-nit LED displays illuminating commercial skylines day and night.",
    description: "Cutting-edge digital outdoor screens offering motion graphics, daytime visibility, and time-targeted messaging at Bengaluru's most affluent commercial and tech intersections.",
    icon: "Monitor",
    image: "/images/industries/digital_ooh.jpg",
    sampleCampaigns: "Real-Time Digital Countdown Campaigns, Dynamic Weather & Time-Triggered Creatives",
    recommendedFormats: ["Commercial Junction LED Screens", "Digital Flyover Totems", "DOOH Video Billboards"]
  }
];

export const CLIENTS_DATA: ClientItem[] = [
  { id: "sbi", name: "State Bank of India", category: "Banking & Finance", highlight: "Festive Loan Campaigns" },
  { id: "malabar", name: "Malabar Gold & Diamonds", category: "Luxury Jewellery", highlight: "Statewide Festive Domination" },
  { id: "a2b", name: "Adyar Ananda Bhavan", category: "Hospitality & Sweets", highlight: "Expressway Dining Corridors" },
  { id: "nandi", name: "Nandi Upachar", category: "Food & Hospitality", highlight: "Highway Restaurant Signage" },
  { id: "dmart", name: "Avenue Supermarts (DMart)", category: "Retail & Supermarkets", highlight: "Hyperlocal Store Launches" },
  { id: "century", name: "Century Real Estate", category: "Infrastructure", highlight: "Luxury Plotted Layouts" },
  { id: "concord", name: "Concorde Group", category: "Real Estate", highlight: "Urban High-Rise Launches" },
  { id: "address", name: "Address Makers", category: "Developers", highlight: "Gated Community Branding" },
  { id: "nambiar", name: "Nambiar Builders", category: "Luxury Homes", highlight: "Villa Enclave Promotions" },
  { id: "nischitha", name: "Nischitha Properties", category: "BMRDA Plots", highlight: "Doddaballapura Highway Blitz" },
  { id: "chandra", name: "Chandra Akka Jewellery", category: "Traditional Jewellery", highlight: "Regional Festival Collections" },
  { id: "klf", name: "KLF Nirmal", category: "FMCG Consumer Goods", highlight: "Transit & Bus Fleet Branding" },
  { id: "hars", name: "HARS International Public School", category: "Education", highlight: "Annual Admissions Drive" },
  { id: "bn", name: "BN International School", category: "Academic Institutions", highlight: "Campus Awareness Campaigns" },
  { id: "kids", name: "Kids International School", category: "Primary Education", highlight: "Neighborhood Bus Shelters" }
];

export const GALLERY_DATA: GalleryItem[] = [
  {
    id: "srigandha-farmvilla",
    title: "Srigandha FarmVilla - Sheshagirihalli Night Hoarding",
    client: "C.A. Aome Projects & Netraj",
    category: "Property Campaigns",
    location: "Sheshagirihalli, Mysore-Bangalore Highway, Karnataka",
    coordinates: "Lat 12.842732° Long 77.420873° | Rcvc+5g5, Sheshagirihalli, Karnataka 562109",
    format: "40ft x 25ft Mega Unipole with 12x 5000K Night Floodlights",
    imageUrl: "/assets/billboard-srigandha.jpg",
    description: "High-power night illumination billboard campaign for Srigandha FarmVilla starting at ₹1.5 Cr. Situated along the buzzing Sheshagirihalli expressway corridor, capturing continuous evening and late-night highway commuter traffic.",
    featured: true
  },
  {
    id: "malabar-gold-diamonds",
    title: "Malabar Gold & Diamonds - Ashada Shubha Labh",
    client: "Malabar Gold & Diamonds",
    category: "Jewellery Campaigns",
    location: "Karnataka State Highway High-Density Corridor",
    coordinates: "Prime Arterial Highway Junction",
    format: "Cantilever Highway Billboard with Full Color Fidelity",
    imageUrl: "/assets/billboard-malabar.jpg",
    description: "High-glamour festival jewellery campaign spotlighting Malabar Gold & Diamonds' signature 30% OFF offers. Executed with supreme print richness ensuring gold hues shine radiantly in natural sunlight.",
    featured: true
  },
  {
    id: "sbi-festive-campaign",
    title: "State Bank of India - Deepavali Festive Gantry",
    client: "State Bank of India",
    category: "Government Campaigns",
    location: "Major Commercial Highway Interchange, Bengaluru",
    coordinates: "Bharat Petroleum Commercial Node",
    format: "Dual-Faced Mega Highway Gantry with Multiple Overhead Spotlights",
    imageUrl: "/assets/billboard-sbi.jpg",
    description: "Bilingual Kannada and English mega campaign promoting State Bank of India Gold Loan and Festive Housing Loan programs with festive visual warmth and clear call-to-actions, reaching hundreds of thousands daily.",
    featured: true
  },
  {
    id: "nischitha-properties",
    title: "Nischitha Properties - Premium BMRDA Plots",
    client: "Nischitha Properties Pvt. Ltd. (Jai Dhwama Group)",
    category: "Property Campaigns",
    location: "Near Doddaballapura Highway, Future 900ft IRR Road",
    coordinates: "Doddaballapura Industrial & Residential Arterial",
    format: "High-Impact Unipole with Overhead Angle Illumination",
    imageUrl: "/assets/billboard-nischitha.jpg",
    description: "Skyline-dominating billboard campaign launching BMRDA Approved Plots starting from ₹45.6 Lakhs. Features high-contrast blue backdrop, bank loan badge, and large Kannada typography for maximum local conversion.",
    featured: true
  },
  {
    id: "a2b-highway-dining",
    title: "Adyar Ananda Bhavan Expressway Dining Destination Billboard",
    client: "Adyar Ananda Bhavan",
    category: "Retail Campaigns",
    location: "Bengaluru - Mysuru Expressway Corridor",
    format: "Unipole Highway Directional Display",
    imageUrl: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
    description: "Strategic highway countdown hoarding informing travelers of upcoming clean dining, authentic South Indian delicacies, and ample vehicle parking facilities.",
    featured: false
  },
  {
    id: "bmtc-luxury-bus-wrap",
    title: "BMTC Urban Transit Fleet Brand Wraps",
    client: "KLF Nirmal Consumer Goods",
    category: "Bus Branding",
    location: "Bengaluru Central Business District & Metro Corridors",
    format: "Full Exterior 3M Cast Vinyl Vehicle Wrap",
    imageUrl: "https://images.unsplash.com/photo-1570125909232-eb263c188f7e?auto=format&fit=crop&w=1200&q=80",
    description: "Dynamic moving advertisements navigating through Bengaluru's highest-density corridors from Kempegowda Bus Station to Electronic City and ITPL Whitefield.",
    featured: false
  },
  {
    id: "led-digital-junction",
    title: "High-Definition Commercial Digital LED Screen",
    client: "Multi-Brand Festive Showcase",
    category: "LED",
    location: "Prime Vijayanagar & South Bengaluru Intersection",
    format: "P6 Outdoor Waterproof Dynamic LED Screen",
    imageUrl: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=1200&q=80",
    description: "Vivid 60FPS video advertisements broadcasting sharp commercial promotions during morning and evening rush hour signal waits.",
    featured: false
  },
  {
    id: "auto-branding-fleet",
    title: "Hyperlocal Bengaluru Auto-Rickshaw Fleet",
    client: "Retail & Academic Network",
    category: "Auto Branding",
    location: "Vijayanagar, Rajajinagar, Malleshwaram & West Bengaluru",
    format: "Heavy-Duty Rexene Printed Rear Hoods",
    imageUrl: "https://images.unsplash.com/photo-1626149637281-4e227308da18?auto=format&fit=crop&w=1200&q=80",
    description: "High-density fleet advertising penetrating every arterial road, neighborhood layout, and commercial market with high frequency.",
    featured: false
  }
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    stepNumber: 1,
    title: "Understand",
    subtitle: "Brand Vision & Audience Mapping",
    description: "We dive deep into your brand identity, target demographic profile, campaign timeline, and specific geographic priorities across Bengaluru and Karnataka.",
    deliverables: ["Demographic Heatmap", "Competitor Outdoor Audit", "Core Target Hotspots"]
  },
  {
    stepNumber: 2,
    title: "Plan",
    subtitle: "Strategic Vantage Selection",
    description: "Our media planners inspect angle clearances, vehicular traffic speeds, lighting conditions, and line-of-sight obstruction to select unbeatable prime sites.",
    deliverables: ["Site Availability Matrix", "Daily Traffic Count Reports", "Cost & ROI Blueprint"]
  },
  {
    stepNumber: 3,
    title: "Create",
    subtitle: "Creative Sizing & Illumination Engineering",
    description: "Outdoor requires immediate optical impact. We calibrate large-format typography ratios, high-contrast color palettes, and custom night illumination schemes.",
    deliverables: ["High-Res Print Proofs", "Night Lighting Plan", "Municipal Compliance Review"]
  },
  {
    stepNumber: 4,
    title: "Execute",
    subtitle: "Precision Fabrication & Mounting",
    description: "Our certified rigging technicians execute flawless installation using high-tensile vinyl mounting, wind-resistant scaffolding, and heavy-gauge structural safety.",
    deliverables: ["Structural Safety Audit", "Zero-Wrinkle Vinyl Mounting", "Electrical & Lighting Setup"]
  },
  {
    stepNumber: 5,
    title: "Deliver",
    subtitle: "24/7 Monitoring & Proof of Performance",
    description: "We don't stop once the hoarding is up. We conduct round-the-clock maintenance, immediate illumination inspection, and provide timestamped geotagged photo/video proof.",
    deliverables: ["Geotagged Proof Photos", "Drone Video Footage", "Final Campaign Impact Report"]
  }
];

export const KARNATAKA_COVERAGE: CoverageLocation[] = [
  {
    id: "bengaluru",
    name: "Bengaluru (HQ)",
    kannadaName: "ಬೆಂಗಳೂರು",
    type: "Metro HQ",
    holdingsCount: 52,
    description: "Complete capital dominance across Vijayanagar HQ, Outer Ring Road, Hebbal Flyover, Electronic City Elevated Expressway, and Kempegowda Airport Highway.",
    topSpots: ["Vijayanagar Arterial Node", "Mysore Road Satellite Bus Station", "Airport Toll Expressway", "Hebbal Junction", "Silk Board & Electronic City Flyover"],
    coordinates: { x: 55, y: 75 }
  },
  {
    id: "mysuru",
    name: "Mysuru & Expressway",
    kannadaName: "ಮೈಸೂರು",
    type: "Expressway Corridor",
    holdingsCount: 18,
    description: "Continuous highway presence on the 10-lane Bengaluru-Mysuru Expressway, Sheshagirihalli corridor, Bidadi industrial belt, and heritage Mysore city entries.",
    topSpots: ["Sheshagirihalli Toll Gate", "Bidadi Industrial Zone", "Ramanagara Bypass", "Mandya Main Arterial", "Mysuru Ring Road Junctions"],
    coordinates: { x: 42, y: 83 }
  },
  {
    id: "hubballi-dharwad",
    name: "Hubballi – Dharwad",
    kannadaName: "ಹುಬ್ಬಳ್ಳಿ - ಧಾರವಾಡ",
    type: "Tier-2 City",
    holdingsCount: 14,
    description: "North Karnataka's commercial engine. High-dwell unipoles along Chennamma Circle, PB Road highway bypass, and BRTS transit corridor.",
    topSpots: ["Kittur Chennamma Circle", "Gokul Road Industrial Area", "PB Road Highway Bypass", "Dharwad University Circle"],
    coordinates: { x: 38, y: 38 }
  },
  {
    id: "mangaluru",
    name: "Mangaluru Coastal Hub",
    kannadaName: "ಮಂಗಳೂರು",
    type: "Tier-2 City",
    holdingsCount: 11,
    description: "Coastal highway coverage along NH-66, Hampankatta commercial hub, Lalbagh junction, and port transit connectors.",
    topSpots: ["Hampankatta Prime Junction", "Lalbagh Commercial Road", "NH-66 Pumpwell Circle", "Surathkal Highway Stretch"],
    coordinates: { x: 25, y: 72 }
  },
  {
    id: "belagavi",
    name: "Belagavi",
    kannadaName: "ಬೆಳಗಾವಿ",
    type: "Highway Junction",
    holdingsCount: 8,
    description: "Strategic Maharashtra-Karnataka border corridor, NH-48 Golden Quadrilateral gantries, and city market roundabouts.",
    topSpots: ["Chennamma Circle Belagavi", "NH-48 National Highway Corridor", "Congress Road Junction"],
    coordinates: { x: 28, y: 22 }
  },
  {
    id: "davanagere",
    name: "Davanagere",
    kannadaName: "ದಾವಣಗೆರೆ",
    type: "Tier-2 City",
    holdingsCount: 7,
    description: "Central Karnataka focal point. High-volume billboards at PB Road, City Railway Station approaches, and educational campuses.",
    topSpots: ["PB Road Central Axis", "Bapuji Institute Road", "Shamanur Circle"],
    coordinates: { x: 45, y: 48 }
  },
  {
    id: "kalaburagi",
    name: "Kalaburagi (Gulbarga)",
    kannadaName: "ಕಲಬುರಗಿ",
    type: "Tier-2 City",
    holdingsCount: 6,
    description: "Kalyana Karnataka administrative capital. Key hoardings at SVP Chowk, Sedam Road, and Central Bus Terminal.",
    topSpots: ["Sardar Vallabhbhai Patel Chowk", "Sedam Road Commercial Stretch", "Station Road"],
    coordinates: { x: 62, y: 16 }
  },
  {
    id: "doddaballapura",
    name: "Doddaballapura & North Corridor",
    kannadaName: "ದೊಡ್ಡಬಳ್ಳಾಪುರ",
    type: "Expressway Corridor",
    holdingsCount: 9,
    description: "Booming industrial and residential investment hub. Unipoles along the proposed 900ft Intermediate Ring Road (IRR) and textile park.",
    topSpots: ["900ft IRR Highway Junction", "Doddaballapura Industrial Area", "Yelahanka - Doddaballapura Main Road"],
    coordinates: { x: 57, y: 68 }
  },
  {
    id: "tumakuru",
    name: "Tumakuru Smart City",
    kannadaName: "ತುಮಕೂರು",
    type: "Highway Junction",
    holdingsCount: 7,
    description: "The gateway to North & Central Karnataka on NH-48 with prime industrial, university, and smart city ring road billboards.",
    topSpots: ["Kyathsandra Toll Plaza", "B.H. Road Central", "Siddaganga Mutt Approach"],
    coordinates: { x: 48, y: 64 }
  }
];

export const COMPANY_TIMELINE: MilestoneItem[] = [
  {
    year: "2006",
    title: "Inception in Vijayanagar, Bengaluru",
    description: "Shivakumar Mathapati establishes MATHAPATI Outdoor Advertising with an unyielding commitment to prime vantage acquisitions and honest customer partnerships."
  },
  {
    year: "2012",
    title: "Karnataka Highway Expansion",
    description: "Expanded strategic billboard footprint across major state and national highways, securing key corridors between Bengaluru, Mysuru, and Tumakuru."
  },
  {
    year: "2018",
    title: "High-Definition Digital LED Rollout",
    description: "Pioneered DOOH (Digital Out-of-Home) video installations at dense commercial intersections, bringing motion creative capabilities to Karnataka advertisers."
  },
  {
    year: "2022",
    title: "Transit & Fleet Dominance",
    description: "Formed dedicated transit advertising division partnering with city transport authorities and auto-rickshaw networks across urban centers."
  },
  {
    year: "2026",
    title: "100+ Prime Holdings & Integrated Media",
    description: "Celebrating two decades of excellence with 100+ premium outdoor holdings, advanced geofenced digital synchronization, and trusted partnerships with India's largest brands."
  }
];

export const FAQ_DATA = [
  {
    q: "How do you select the best outdoor advertising location for my brand?",
    a: "We conduct a comprehensive traffic and visibility audit analyzing vehicular speed, dwell time at signals, viewing angle unobstructed distance, pedestrian volume, and local neighborhood demographics to ensure maximum return on investment."
  },
  {
    q: "Do you handle local municipal permissions and structural safety?",
    a: "Yes, 100%. All MATHAPATI outdoor holdings comply with BBMP, municipal corporation, and National Highways Authority regulations, complete with structural stability certifications and electrical safety approvals."
  },
  {
    q: "What is the minimum duration for booking a billboard campaign?",
    a: "Campaigns typically run for 1 month, 3 months, 6 months, or annual tenures. For event launches or festive promotions, short-term 10 to 15-day blitz packages are also available depending on site availability."
  },
  {
    q: "Do you provide proof of performance and maintenance during the campaign?",
    a: "Absolutely. We provide high-resolution daytime and nighttime geotagged photographs, drone footage upon request, and perform regular inspections to guarantee zero-defect illumination and pristine vinyl condition."
  },
  {
    q: "Can I combine billboards with bus or auto branding?",
    a: "Yes! In fact, our '360° Outdoor Blitz' combines static highway unipoles with moving bus and auto fleet branding, ensuring your target audience sees your brand both during their highway commute and inside local neighborhood streets."
  }
];

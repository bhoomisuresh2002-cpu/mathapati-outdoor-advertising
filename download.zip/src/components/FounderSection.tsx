import React from 'react';
import { COMPANY_INFO } from '../data/companyData';
import { ShieldCheck, Quote, Sparkles, MapPin, CheckCircle2, Award } from 'lucide-react';

export const FounderSection: React.FC = () => {
  const { founder } = COMPANY_INFO;

  return (
    <div className="relative mt-16 sm:mt-20">
      {/* Background Subtle Luxury Ambient Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(240,74,0,0.12)_0%,_transparent_70%)] pointer-events-none" />

      {/* Main Glassmorphism Dark Card */}
      <div className="relative bg-[#121826]/95 border border-white/10 rounded-3xl p-6 sm:p-10 lg:p-12 overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
        {/* Subtle Luxury Corner Flares */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-[#F04A00]/15 to-transparent rounded-bl-full pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-gradient-to-tr from-blue-600/10 to-transparent rounded-tr-full pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Founder Portrait Column - Clean Luxury Frame, Face & Pose Fully Preserved */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="relative group w-full max-w-sm">
              {/* Outer Subtle Frame Accent Glow */}
              <div className="absolute -inset-1.5 bg-gradient-to-b from-[#F04A00]/50 via-transparent to-[#F04A00]/20 rounded-3xl blur-[4px] opacity-70 group-hover:opacity-100 transition duration-500" />

              {/* Founder Image Container - Original photo, exact natural proportions, crisp & clear */}
              <div className="relative w-full rounded-2xl overflow-hidden bg-[#0A0E17] border border-[#F04A00]/40 shadow-[0_15px_35px_rgba(0,0,0,0.6)] group-hover:shadow-[0_20px_45px_rgba(240,74,0,0.25)] transition-all duration-500">
                <div className="w-full aspect-[3/4] overflow-hidden flex items-center justify-center p-3 bg-gradient-to-b from-[#161F32] via-[#0E1422] to-[#0A0E17] relative">
                  {/* Soft radial glow behind portrait for a premium plaque feel */}
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_35%,_rgba(240,74,0,0.18)_0%,_transparent_65%)] pointer-events-none" />
                  <img
                    src="/images/founder.png"
                    alt="Shivakumar Mathapati - Founder & Managing Director, MATHAPATI Outdoor Advertising"
                    className="relative w-full h-full object-contain object-bottom rounded-xl group-hover:scale-[1.02] transition-transform duration-700 ease-out drop-shadow-[0_15px_25px_rgba(0,0,0,0.5)]"
                    loading="eager"
                  />
                </div>

                {/* Elegant Dark Executive Plaque Below Portrait */}
                <div className="p-4 sm:p-5 text-center bg-[#161F32] border-t border-white/10">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1F2A42] border border-[#F04A00]/40 text-[#FF5E1E] text-[11px] font-bold uppercase tracking-wider mb-2">
                    <Sparkles className="w-3 h-3 text-[#F04A00]" /> Founder & Managing Director
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white font-heading tracking-wide">
                    {founder.name}
                  </h3>
                  <p className="text-xs text-zinc-300 font-medium mt-1">
                    {founder.role}
                  </p>
                  <div className="mt-2.5 flex items-center justify-center gap-1 text-[11px] text-zinc-400">
                    <MapPin className="w-3.5 h-3.5 text-[#F04A00]" />
                    <span>Headquartered in Vijayanagar, Bengaluru</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Founder Experience Badges */}
            <div className="mt-4 flex items-center justify-center gap-2 flex-wrap text-xs">
              <span className="px-3.5 py-1.5 rounded-full bg-[#161F32] border border-[#F04A00]/40 text-white font-semibold shadow-xs">
                30+ Years Industry Experience
              </span>
              <span className="px-3.5 py-1.5 rounded-full bg-[#161F32] border border-white/10 text-zinc-300 font-medium shadow-xs">
                Established 2006
              </span>
            </div>
          </div>

          {/* Founder Bio & Leadership Narrative */}
          <div className="lg:col-span-7 flex flex-col space-y-5">
            {/* Header Accent Strip */}
            <div>
              <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#FF5E1E] font-bold">
                <ShieldCheck className="w-4 h-4 text-[#F04A00]" />
                <span>Executive Leadership</span>
              </div>
              <div className="w-14 h-1 bg-gradient-to-r from-[#F04A00] to-transparent rounded-full mt-2 mb-3" />
              <h3 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight font-heading leading-tight">
                Three Decades of Pioneering Outdoor Visibility Across Karnataka
              </h3>
            </div>

            {/* Founder Quote in Luxury Dark Box with Brand Orange Accent */}
            <div className="relative p-5 sm:p-6 rounded-2xl bg-[#161F32]/80 border-l-4 border-[#F04A00] border-y border-r border-white/10 shadow-lg">
              <Quote className="w-8 h-8 text-[#F04A00]/20 absolute top-3 right-4 pointer-events-none" />
              <p className="text-sm sm:text-base text-zinc-200 italic leading-relaxed relative z-10 font-serif">
                "{founder.quote}"
              </p>
              <div className="mt-3.5 flex items-center gap-2">
                <span className="w-5 h-0.5 bg-[#F04A00]" />
                <span className="text-xs font-bold uppercase tracking-wider text-white">
                  Shivakumar Mathapati
                </span>
                <span className="text-[11px] text-zinc-400">· Founder & Managing Director</span>
              </div>
            </div>

            {/* Official Bio Paragraph */}
            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed font-normal">
              {founder.bio}
            </p>

            {/* Strategic Pillars Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-[#161F32]/70 border border-white/10 hover:border-[#F04A00]/50 transition-colors">
                <CheckCircle2 className="w-4 h-4 text-[#F04A00] flex-shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-white uppercase tracking-wider">Prime Site Monopoly</div>
                  <div className="text-[11px] text-zinc-400 mt-0.5">Decades of exclusive acquisitions along highway bottlenecks and high-density junction choke-points.</div>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-[#161F32]/70 border border-white/10 hover:border-[#F04A00]/50 transition-colors">
                <CheckCircle2 className="w-4 h-4 text-[#F04A00] flex-shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-white uppercase tracking-wider">Regulatory Compliance</div>
                  <div className="text-[11px] text-zinc-400 mt-0.5">Absolute civic governance adherence, structural engineering certifications, and BBMP/NHAI clearances.</div>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-[#161F32]/70 border border-white/10 hover:border-[#F04A00]/50 transition-colors">
                <CheckCircle2 className="w-4 h-4 text-[#F04A00] flex-shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-white uppercase tracking-wider">Transit Fleet Synergy</div>
                  <div className="text-[11px] text-zinc-400 mt-0.5">Established institutional conduits across Karnataka state transport corporations and private transit fleets.</div>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-[#161F32]/70 border border-white/10 hover:border-[#F04A00]/50 transition-colors">
                <CheckCircle2 className="w-4 h-4 text-[#F04A00] flex-shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-white uppercase tracking-wider">Turnkey Campaign Quality</div>
                  <div className="text-[11px] text-zinc-400 mt-0.5">End-to-end execution supervision from high-gauge vinyl mounting to 24/7 night illumination audits.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

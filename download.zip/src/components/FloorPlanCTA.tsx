import React from 'react';
import { COMPANY_INFO } from '../data/companyData';
import { Phone, ArrowUpRight, Sparkles, ShieldCheck } from 'lucide-react';

interface FloorPlanCTAProps {
  onOpenConsultation: () => void;
}

export const FloorPlanCTA: React.FC<FloorPlanCTAProps> = ({ onOpenConsultation }) => {
  return (
    <section className="py-24 relative bg-[#080C14] border-t border-white/10 overflow-hidden text-white">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-[#F04A00]/15 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="relative rounded-3xl overflow-hidden p-8 sm:p-12 lg:p-16 border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)] bg-gradient-to-r from-[#0E1524] via-[#141E33] to-[#0E1524]">
          {/* Subtle Ambient Lighting Flares */}
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#F04A00]/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-3xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#1A253B] border border-[#F04A00]/40 text-xs font-semibold text-[#FF5E1E] uppercase tracking-wider shadow-[0_0_15px_rgba(240,74,0,0.15)]">
              <Sparkles className="w-3.5 h-3.5 text-[#F04A00]" /> High-Recall Vantage Points Await
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight leading-tight">
              Ready to Make Your Brand <span className="orange-accent-gradient">Impossible to Miss?</span>
            </h2>

            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed max-w-2xl mx-auto">
              Secure prime highway corridors, illuminated unipoles, and high-frequency transit wraps across Bengaluru and Karnataka. Connect directly with Shivakumar Mathapati today.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
              <button
                onClick={onOpenConsultation}
                className="w-full sm:w-auto px-8 py-4 rounded-xl text-sm font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] shadow-[0_10px_25px_-5px_rgba(240,74,0,0.5)] hover:shadow-[0_15px_35px_-5px_rgba(240,74,0,0.7)] transition-all flex items-center justify-center gap-2 hover:-translate-y-0.5 cursor-pointer"
              >
                <span>Request Site Availability</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>

              <a
                href={`tel:${COMPANY_INFO.contact.phone}`}
                className="w-full sm:w-auto px-6 py-4 rounded-xl text-sm font-semibold text-white bg-[#1A253B] border border-white/15 hover:border-[#F04A00]/50 hover:bg-[#202E49] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Phone className="w-4 h-4 text-[#F04A00]" />
                <span>Call {COMPANY_INFO.contact.displayPhone}</span>
              </a>

              <a
                href={`https://wa.me/91${COMPANY_INFO.contact.whatsapp}?text=Hi%20Shivakumar%20Mathapati,%20I%20would%20like%20to%20inquire%20about%20billboard%20availability`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-6 py-4 rounded-xl text-sm font-semibold text-white bg-emerald-600/80 border border-emerald-500/40 hover:bg-emerald-600 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-[0_4px_15px_rgba(16,185,129,0.3)]"
              >
                <span>WhatsApp Now</span>
              </a>
            </div>

            <div className="pt-4 flex flex-wrap items-center justify-center gap-6 text-xs text-zinc-400">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#F04A00]" /> 100% Municipal Clearance
              </span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#F04A00]" /> Structural Safety Certified
              </span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#F04A00]" /> 24/7 Night Illumination
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

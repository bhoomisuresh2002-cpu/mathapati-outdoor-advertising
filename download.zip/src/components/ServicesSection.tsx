import React, { useState } from 'react';
import { SERVICES_DATA } from '../data/companyData';
import { ServiceItem } from '../types';
import { 
  Tv, 
  Monitor, 
  Building2, 
  Bus, 
  Car, 
  Navigation, 
  Home, 
  Globe, 
  ArrowUpRight, 
  CheckCircle2, 
  Sparkles,
  X
} from 'lucide-react';

interface ServicesSectionProps {
  onSelectService: (service: ServiceItem) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Monitor': return <Monitor className="w-6 h-6" />;
      case 'Tv': return <Tv className="w-6 h-6" />;
      case 'Building2': return <Building2 className="w-6 h-6" />;
      case 'Bus': return <Bus className="w-6 h-6" />;
      case 'Car': return <Car className="w-6 h-6" />;
      case 'Navigation': return <Navigation className="w-6 h-6" />;
      case 'Home': return <Home className="w-6 h-6" />;
      case 'Globe': return <Globe className="w-6 h-6" />;
      default: return <Monitor className="w-6 h-6" />;
    }
  };

  return (
    <section id="services" className="py-24 relative bg-gradient-to-b from-[#F0F4F8] via-[#F8FAFC] to-[#FFFFFF] text-[#1A1A1A] overflow-hidden">
      {/* Background ambient accents */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-[#F04A00]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white border border-[#F04A00]/30 text-xs font-semibold text-[#F04A00] uppercase tracking-wider mb-4 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#F04A00]" /> Media Solutions We Offer
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#1A1A1A] font-heading tracking-tight leading-tight">
            High-Impact Media Designed for <span className="orange-accent-gradient">Maximum Recall</span>
          </h2>
          <p className="mt-4 text-[#555555] text-sm sm:text-base leading-relaxed">
            From monumental highway unipoles to moving city transit fleets, explore our comprehensive array of outdoor advertising solutions tailored for brands that demand authority.
          </p>
        </div>

        {/* 8 Luxury Interactive Service Cards - White Premium Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SERVICES_DATA.map((service) => (
            <div
              key={service.id}
              className="bg-white p-6 rounded-2xl border border-[#E2E8F0] hover:border-[#F04A00]/60 hover:shadow-[0_15px_35px_-5px_rgba(240,74,0,0.18)] transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between group relative overflow-hidden shadow-[0_4px_20px_rgba(26,26,26,0.03)]"
            >
              {/* Top Accent Gradient Border */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#F04A00]/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div>
                {/* Header row: Icon & Tag */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-[#FFF5F0] border border-[#EFE6D8] group-hover:border-[#F04A00]/40 flex items-center justify-center text-[#F04A00] group-hover:scale-105 transition-all duration-300 shadow-xs">
                    {getServiceIcon(service.iconName)}
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-[#FAF6F0] text-[#555555] border border-[#EFE6D8] group-hover:border-[#F04A00]/30 group-hover:text-[#1A1A1A] transition-colors">
                    {service.tag}
                  </span>
                </div>

                <div className="text-[11px] text-[#F04A00] font-bold tracking-wider uppercase mb-1">
                  {service.category}
                </div>

                <h3 className="text-lg font-bold text-[#1A1A1A] font-heading group-hover:text-[#F04A00] transition-colors mb-2.5 leading-snug">
                  {service.title}
                </h3>

                <p className="text-xs text-[#666666] leading-relaxed line-clamp-3 mb-4">
                  {service.shortDesc}
                </p>

                {/* Key Metric Badge */}
                <div className="text-[11px] font-semibold text-[#333333] bg-[#FAF6F0] px-3 py-1.5 rounded-lg border border-[#EFE6D8] mb-4 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>{service.metrics}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="pt-3 border-t border-[#EFE6D8] flex items-center justify-between">
                <button
                  onClick={() => setSelectedService(service)}
                  className="text-xs font-semibold text-[#777777] hover:text-[#1A1A1A] transition-colors cursor-pointer"
                >
                  View Details
                </button>

                <button
                  onClick={() => onSelectService(service)}
                  className="inline-flex items-center gap-1 text-xs font-bold text-[#F04A00] hover:text-[#D43F00] transition-colors group-hover:translate-x-0.5 cursor-pointer"
                >
                  <span>Book Slot</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Service Detail Modal - Luxury White Dialog */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl bg-white border border-[#EFE6D8] rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden">
            {/* Close Button */}
            <button
              onClick={() => setSelectedService(null)}
              className="absolute top-5 right-5 p-2 rounded-full bg-[#FAF6F0] text-[#777777] hover:text-[#1A1A1A] hover:bg-[#EFE6D8] transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-[#FFF5F0] border border-[#F04A00]/25 flex items-center justify-center text-[#F04A00]">
                {getServiceIcon(selectedService.iconName)}
              </div>
              <div>
                <span className="text-xs font-bold text-[#F04A00] uppercase tracking-wider">
                  {selectedService.category}
                </span>
                <h3 className="text-xl sm:text-2xl font-bold text-[#1A1A1A] font-heading">
                  {selectedService.title}
                </h3>
              </div>
            </div>

            <p className="text-sm text-[#555555] leading-relaxed mb-6">
              {selectedService.fullDesc}
            </p>

            <div className="mb-6">
              <h4 className="text-xs font-bold text-[#777777] uppercase tracking-wider mb-3">
                Key Deliverables & Specifications
              </h4>
              <div className="space-y-2">
                {selectedService.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-[#333333]">
                    <CheckCircle2 className="w-4 h-4 text-[#F04A00] flex-shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-[#EFE6D8] flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-[#777777]">
                Performance: <strong className="text-[#1A1A1A]">{selectedService.metrics}</strong>
              </div>

              <div className="flex gap-3 w-full sm:w-auto">
                <button
                  onClick={() => setSelectedService(null)}
                  className="flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-semibold text-[#777777] hover:text-[#1A1A1A] bg-[#FAF6F0] border border-[#EFE6D8] cursor-pointer"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const service = selectedService;
                    setSelectedService(null);
                    onSelectService(service);
                  }}
                  className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] shadow-[0_4px_15px_rgba(240,74,0,0.3)] hover:shadow-[0_8px_20px_rgba(240,74,0,0.45)] cursor-pointer"
                >
                  Plan Campaign with This Service
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

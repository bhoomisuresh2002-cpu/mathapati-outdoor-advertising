import React, { useState } from 'react';
import { KARNATAKA_COVERAGE } from '../data/companyData';
import { CoverageLocation } from '../types';
import { MapPin, CheckCircle2, ArrowRight } from 'lucide-react';

interface KarnatakaMapProps {
  onSelectHub: (hub: CoverageLocation) => void;
}

export const KarnatakaMap: React.FC<KarnatakaMapProps> = ({ onSelectHub }) => {
  const [selectedLocation, setSelectedLocation] = useState<CoverageLocation>(KARNATAKA_COVERAGE[0]);

  return (
    <section id="map" className="py-20 relative bg-[#F7F3EC] overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-[#F04A00]/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white border border-[#F04A00]/25 text-xs font-semibold text-[#F04A00] uppercase tracking-wider mb-4 shadow-xs">
            <MapPin className="w-3.5 h-3.5 text-[#F04A00]" /> Geographic Dominance
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#1A1A1A] font-heading tracking-tight leading-tight">
            Karnataka-Wide <span className="orange-accent-gradient">Outdoor Presence</span>
          </h2>
          <p className="mt-4 text-[#666666] text-sm sm:text-base leading-relaxed">
            From our strategic headquarters in Vijayanagar, Bengaluru across key economic corridors, district junctions, and tourist arteries, explore our state-wide inventory.
          </p>
        </div>

        {/* Map & Information Split Grid - SP White Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Interactive Vector Map Canvas */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-[#EFE6D8] shadow-[0_10px_30px_rgba(26,26,26,0.04)] relative overflow-hidden flex flex-col items-center">
            <div className="w-full flex justify-between items-center mb-4 text-xs">
              <span className="font-semibold text-[#666666]">Interactive Regional Map</span>
              <span className="text-[#F04A00] font-bold font-mono">100+ Active Sites</span>
            </div>

            {/* Simulated Karnataka Vector Map Area */}
            <div className="relative w-full aspect-[4/3] max-w-md sm:max-w-lg bg-[#FAF6F0] rounded-2xl border border-[#EFE6D8] p-4 flex items-center justify-center overflow-hidden">
              {/* Karnataka State Boundary Silhouette SVG Outline */}
              <svg
                viewBox="0 0 100 100"
                className="w-full h-full stroke-[#F04A00]/40 fill-[#FAF6F0] transition-all duration-500"
              >
                {/* Stylized Polygon Outline representing Karnataka State */}
                <path
                  d="M48 6 L62 14 L75 12 L72 26 L65 35 L70 48 L68 62 L60 85 L48 95 L38 88 L28 80 L22 68 L24 50 L32 38 L30 20 Z"
                  strokeWidth="1.5"
                  strokeDasharray="2 2"
                />

                {/* Major Highway Corridors between Hubs */}
                <line x1="55" y1="75" x2="42" y2="83" stroke="#F04A00" strokeWidth="1.2" strokeOpacity="0.4" strokeDasharray="1 1" />
                <line x1="55" y1="75" x2="48" y2="64" stroke="#F04A00" strokeWidth="1.2" strokeOpacity="0.4" strokeDasharray="1 1" />
                <line x1="48" y1="64" x2="45" y2="48" stroke="#F04A00" strokeWidth="1.2" strokeOpacity="0.4" strokeDasharray="1 1" />
                <line x1="45" y1="48" x2="38" y2="38" stroke="#F04A00" strokeWidth="1.2" strokeOpacity="0.4" strokeDasharray="1 1" />
                <line x1="38" y1="38" x2="28" y2="22" stroke="#F04A00" strokeWidth="1.2" strokeOpacity="0.4" strokeDasharray="1 1" />
                <line x1="55" y1="75" x2="25" y2="72" stroke="#F04A00" strokeWidth="1.2" strokeOpacity="0.4" strokeDasharray="1 1" />
              </svg>

              {/* Animated Interactive Pins */}
              {KARNATAKA_COVERAGE.map((loc) => {
                const isSelected = selectedLocation.id === loc.id;
                return (
                  <button
                    key={loc.id}
                    onClick={() => setSelectedLocation(loc)}
                    className="absolute group focus:outline-none -translate-x-1/2 -translate-y-1/2 cursor-pointer z-20"
                    style={{
                      left: `${loc.coordinates.x}%`,
                      top: `${loc.coordinates.y}%`,
                    }}
                    aria-label={`Select ${loc.name}`}
                  >
                    {/* Pulsing Ripple Effect */}
                    <span
                      className={`absolute -inset-2 rounded-full transition-opacity ${
                        isSelected
                          ? 'bg-[#F04A00]/40 animate-ping opacity-100'
                          : 'bg-[#F04A00]/20 group-hover:bg-[#F04A00]/30 group-hover:animate-ping opacity-0 group-hover:opacity-100'
                      }`}
                    />

                    {/* Core Pin Dot */}
                    <div
                      className={`relative w-4 h-4 rounded-full flex items-center justify-center transition-transform ${
                        isSelected
                          ? 'bg-[#F04A00] scale-125 shadow-[0_0_12px_rgba(240,74,0,0.8)]'
                          : 'bg-white border border-[#F04A00] group-hover:scale-110 group-hover:bg-[#F04A00]'
                      }`}
                    >
                      <div className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-white' : 'bg-[#F04A00]'}`} />
                    </div>

                    {/* Location Name Tag */}
                    <div
                      className={`absolute top-5 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] font-bold px-2 py-0.5 rounded transition-all pointer-events-none shadow-xs ${
                        isSelected
                          ? 'bg-[#F04A00] text-white z-30 scale-105'
                          : 'bg-white text-[#1A1A1A] border border-[#EFE6D8] group-hover:text-[#F04A00]'
                      }`}
                    >
                      {loc.name.split(' ')[0]}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Bottom quick toggle chips */}
            <div className="flex flex-wrap justify-center gap-1.5 mt-6 w-full">
              {KARNATAKA_COVERAGE.map((loc) => (
                <button
                  key={loc.id}
                  onClick={() => setSelectedLocation(loc)}
                  className={`px-3 py-1 rounded-lg text-xs transition-colors cursor-pointer ${
                    selectedLocation.id === loc.id
                      ? 'bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] text-white font-bold shadow-xs'
                      : 'bg-[#FAF6F0] text-[#555555] hover:text-[#1A1A1A] border border-[#EFE6D8]'
                  }`}
                >
                  {loc.name}
                </button>
              ))}
            </div>
          </div>

          {/* Selected Location Details Panel */}
          <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-3xl border border-[#EFE6D8] shadow-[0_10px_30px_rgba(26,26,26,0.04)] relative space-y-6">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-extrabold tracking-widest text-[#F04A00]">
                  {selectedLocation.type}
                </span>
                <span className="px-3 py-1 rounded-full bg-[#FAF6F0] border border-[#EFE6D8] text-xs font-bold text-[#1A1A1A]">
                  {selectedLocation.holdingsCount} Prime Holdings
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] font-heading mt-2">
                {selectedLocation.name}
              </h3>
              <div className="text-xs text-[#F04A00] font-semibold font-sans">
                {selectedLocation.kannadaName}
              </div>

              <p className="text-sm text-[#555555] leading-relaxed mt-3">
                {selectedLocation.description}
              </p>
            </div>

            {/* Prime Vantage Spots List */}
            <div>
              <div className="text-xs font-bold text-[#777777] uppercase tracking-wider mb-3">
                Signature High-Dwell Vantage Spots:
              </div>
              <div className="space-y-2">
                {selectedLocation.topSpots.map((spot, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-[#333333]">
                    <CheckCircle2 className="w-4 h-4 text-[#F04A00] flex-shrink-0 mt-0.5" />
                    <span>{spot}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Inquire CTA for this Location */}
            <div className="pt-4 border-t border-[#EFE6D8] flex items-center justify-between">
              <div className="text-xs text-[#777777]">
                Avg. Daily Traffic: <strong className="text-[#1A1A1A]">200K+ / day</strong>
              </div>
              <button
                onClick={() => onSelectHub(selectedLocation)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] shadow-md hover:shadow-lg transition-all cursor-pointer"
              >
                <span>Reserve in {selectedLocation.name.split(' ')[0]}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

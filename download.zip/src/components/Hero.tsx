import React from 'react';
import { ArrowDown, ArrowUpRight, Sparkles, ShieldCheck } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

interface HeroProps {
  onExploreWork: () => void;
  onOpenConsultation: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreWork, onOpenConsultation }) => {
  const scrollToServices = () => {
    const el = document.getElementById('services');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      onExploreWork();
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-28 pb-16 overflow-hidden text-white"
    >
      {/* Full-Screen Bright Background Video (SP Advertising Style) - fully visible, no heavy dark overlay */}
      <div className="absolute inset-0 z-0">
        <video
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          poster="/images/highway_hero.jpg"
          className="absolute inset-0 w-full h-full object-cover"
        >
          <source src="/videos/highway_footage.mp4" type="video/mp4" />
        </video>
        {/* Near-none overlay: a thin bottom fade only, just enough for the metric cards' text to stay legible. The video itself is fully visible and bright everywhere else. */}
        <div className="absolute inset-x-0 bottom-0 h-[45%] bg-gradient-to-b from-transparent to-[#0A0E17]/55" />
        <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-black/25 to-transparent" />
      </div>

      {/* Layered Background Compositions & Depth (SP Advertising Blueprint) */}
      <div className="absolute inset-0 pointer-events-none z-[1]">
        {/* Subtle horizon line */}
        <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      {/* Floating Orange Ambient Glow Points */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-[2]">
        <div className="absolute top-1/4 left-12 w-2.5 h-2.5 rounded-full bg-[#F04A00]/60 blur-[1px] animate-float-slow" />
        <div
          className="absolute top-1/3 right-16 w-3 h-3 rounded-full bg-[#FF5E1E]/50 blur-[1px] animate-float-slow"
          style={{ animationDelay: '1.8s' }}
        />
        <div
          className="absolute bottom-1/3 left-1/4 w-2 h-2 rounded-full bg-[#F04A00]/40 blur-[1px] animate-float-slow"
          style={{ animationDelay: '3.2s' }}
        />
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center">
        {/* Elite Badge Pill */}
        <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-black/40 border border-white/20 backdrop-blur-md mb-6 shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
          <Sparkles className="w-3.5 h-3.5 text-[#F04A00]" />
          <span className="text-xs uppercase tracking-widest text-white font-bold">
            No. 1 Karnataka's Outdoor Advertising Company
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#F04A00]" />
          <span className="text-xs text-zinc-300 font-medium hidden sm:inline">Since 2006</span>
        </div>

        {/* Master Tagline Headline */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-4xl leading-[1.12] font-heading drop-shadow-[0_4px_20px_rgba(0,0,0,0.6)]">
          Outdoor Advertising That Makes Your Brand{' '}
          <span className="orange-accent-gradient block mt-2 font-black drop-shadow-[0_4px_30px_rgba(240,74,0,0.5)]">
            Impossible to Miss
          </span>
        </h1>

        {/* Descriptive Body Copy */}
        <p className="mt-6 text-base sm:text-lg md:text-xl text-zinc-100 max-w-3xl leading-relaxed font-normal drop-shadow-[0_2px_12px_rgba(0,0,0,0.7)]">
          Dominating high-traffic arterial junctions, state and national highway corridors, bus fleets, and commercial skylines across Karnataka for over 20 years.
        </p>

        {/* CTA Button Group - Brand Orange & Glass Dark (SP Advertising Style) */}
        <div className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-md">
          <button
            id="hero-cta-consultation"
            onClick={onOpenConsultation}
            className="w-full sm:w-auto px-8 py-4 rounded-xl text-sm font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] shadow-[0_10px_25px_-5px_rgba(240,74,0,0.5)] hover:shadow-[0_15px_35px_-5px_rgba(240,74,0,0.7)] hover:-translate-y-0.5 transition-all duration-300 flex items-center justify-center gap-2 group cursor-pointer"
          >
            <span>Get Free Consultation</span>
            <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </button>

          <button
            id="hero-cta-explore-services"
            onClick={scrollToServices}
            className="w-full sm:w-auto px-8 py-4 rounded-xl text-sm font-semibold tracking-wider text-white bg-black/40 hover:bg-black/55 border border-white/25 hover:border-[#F04A00]/60 backdrop-blur-md shadow-lg hover:shadow-[0_0_25px_rgba(240,74,0,0.25)] transition-all duration-300 flex items-center justify-center gap-2 hover:-translate-y-0.5 cursor-pointer group"
          >
            <span>Explore Services</span>
            <ArrowDown className="w-4 h-4 text-[#F04A00] group-hover:translate-y-1 transition-transform" />
          </button>
        </div>

        {/* Hero Bottom Metric Strip (4 Distinct Pillars - Glassmorphism Dark Cards) */}
        <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 w-full max-w-4xl text-left">
          <div className="bg-black/45 backdrop-blur-md p-5 rounded-2xl border border-white/15 hover:border-[#F04A00]/50 transition-all duration-300 shadow-[0_8px_25px_rgba(0,0,0,0.4)] hover:-translate-y-1 group">
            <div className="text-3xl sm:text-4xl font-black text-[#F04A00] font-heading group-hover:scale-105 transition-transform inline-block">500+</div>
            <div className="text-xs text-white mt-1 uppercase tracking-wider font-bold">Media Assets</div>
            <div className="text-[11px] text-zinc-300 mt-0.5">Across Karnataka</div>
          </div>

          <div className="bg-black/45 backdrop-blur-md p-5 rounded-2xl border border-white/15 hover:border-[#F04A00]/50 transition-all duration-300 shadow-[0_8px_25px_rgba(0,0,0,0.4)] hover:-translate-y-1 group">
            <div className="text-3xl sm:text-4xl font-black text-[#F04A00] font-heading group-hover:scale-105 transition-transform inline-block">2006</div>
            <div className="text-xs text-white mt-1 uppercase tracking-wider font-bold">Established</div>
            <div className="text-[11px] text-zinc-300 mt-0.5">{COMPANY_INFO.experienceYears} Years Track Record</div>
          </div>

          <div className="bg-black/45 backdrop-blur-md p-5 rounded-2xl border border-white/15 hover:border-[#F04A00]/50 transition-all duration-300 shadow-[0_8px_25px_rgba(0,0,0,0.4)] hover:-translate-y-1 group">
            <div className="text-3xl sm:text-4xl font-black text-[#F04A00] font-heading group-hover:scale-105 transition-transform inline-block">98%</div>
            <div className="text-xs text-white mt-1 uppercase tracking-wider font-bold">Client Retention</div>
            <div className="text-[11px] text-zinc-300 mt-0.5">Repeat Brand Partners</div>
          </div>

          <div className="bg-black/45 backdrop-blur-md p-5 rounded-2xl border border-white/15 hover:border-[#F04A00]/50 transition-all duration-300 shadow-[0_8px_25px_rgba(0,0,0,0.4)] hover:-translate-y-1 group">
            <div className="text-3xl sm:text-4xl font-black text-[#F04A00] font-heading group-hover:scale-105 transition-transform inline-block">{COMPANY_INFO.founderExperienceYears}</div>
            <div className="text-xs text-white mt-1 uppercase tracking-wider font-bold">Founder Mastery</div>
            <div className="text-[11px] text-zinc-300 mt-0.5">Shivakumar Mathapati</div>
          </div>
        </div>

        {/* Animated Down Scroll Prompt */}
        <button
          onClick={scrollToServices}
          className="mt-10 inline-flex flex-col items-center gap-1.5 text-zinc-300 hover:text-[#F04A00] transition-colors focus:outline-none group cursor-pointer"
          aria-label="Scroll to discover solutions"
        >
          <span className="text-[10px] tracking-widest uppercase text-zinc-300 group-hover:text-[#F04A00] font-semibold drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)]">
            Scroll to Discover
          </span>
          <ArrowDown className="w-4 h-4 animate-bounce text-[#F04A00]" />
        </button>
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { GALLERY_DATA } from '../data/companyData';
import { GalleryItem } from '../types';
import { BillboardGraphic } from './BillboardGraphic';
import { Eye, MapPin, Sparkles, X, ShieldCheck } from 'lucide-react';

export const GallerySection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [lightboxItem, setLightboxItem] = useState<GalleryItem | null>(null);

  const categories = ['All', 'Property Campaigns', 'Jewellery Campaigns', 'Government Campaigns', 'Bus Branding', 'LED', 'Auto Branding'];

  const filteredItems = GALLERY_DATA.filter((item) => {
    if (activeCategory === 'All') return true;
    return item.category === activeCategory;
  });

  return (
    <section id="gallery" className="py-20 relative bg-[#F7F3EC] overflow-hidden">
      {/* Background soft glow */}
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-[#F04A00]/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-0 w-[500px] h-[500px] bg-[#EFE6D8]/60 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white border border-[#F04A00]/25 text-xs font-semibold text-[#F04A00] uppercase tracking-wider mb-4 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#F04A00]" /> Curated Portfolio
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#1A1A1A] font-heading tracking-tight leading-tight">
            Campaign Gallery & <span className="orange-accent-gradient">Real-World Deployments</span>
          </h2>
          <p className="mt-4 text-[#666666] text-sm sm:text-base leading-relaxed">
            Witness our outdoor billboard structures, nighttime illumination engineering, and high-frequency transit wraps in active Karnataka locations.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-semibold tracking-wider transition-all duration-300 cursor-pointer ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] text-white font-bold shadow-xs'
                  : 'bg-white text-[#555555] hover:text-[#1A1A1A] hover:bg-[#FAF6F0] border border-[#EFE6D8]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Gallery Grid - SP White Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => {
            const hasDedicatedGraphic = ['srigandha-farmvilla', 'malabar-gold-diamonds', 'sbi-festive-campaign', 'nischitha-properties'].includes(item.id);

            return (
              <div
                key={item.id}
                className="bg-white rounded-2xl border border-[#EFE6D8] hover:border-[#F04A00]/50 shadow-[0_4px_20px_rgba(26,26,26,0.03)] hover:shadow-[0_15px_35px_-5px_rgba(240,74,0,0.18)] overflow-hidden group transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between"
              >
                {/* Visual Frame */}
                <div
                  className="relative aspect-[16/10] w-full overflow-hidden bg-[#FAF6F0] cursor-pointer"
                  onClick={() => setLightboxItem(item)}
                >
                  {hasDedicatedGraphic ? (
                    <div className="w-full h-full p-2 pointer-events-none group-hover:scale-105 transition-transform duration-500">
                      <BillboardGraphic id={item.id} isNight={item.id === 'srigandha-farmvilla'} showFrame={false} />
                    </div>
                  ) : (
                    <img
                      src={item.imageUrl}
                      alt={item.title}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  )}

                  {/* Dark gradient overlay on hover */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-40 group-hover:opacity-60 transition-opacity" />

                  {/* Top Category Badge */}
                  <div className="absolute top-3 left-3 z-10">
                    <span className="px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-md text-[#1A1A1A] text-[10px] font-bold uppercase tracking-wider border border-[#EFE6D8] shadow-xs">
                      {item.category}
                    </span>
                  </div>

                  {/* Hover Inspect Icon Button */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10">
                    <span className="p-3 rounded-full bg-[#F04A00] text-white shadow-xl hover:scale-110 transition-transform">
                      <Eye className="w-5 h-5" />
                    </span>
                  </div>
                </div>

                {/* Content details */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="text-[11px] text-[#F04A00] font-bold uppercase tracking-wider mb-1">
                      {item.client}
                    </div>
                    <h3
                      className="text-base font-bold text-[#1A1A1A] font-heading group-hover:text-[#F04A00] transition-colors cursor-pointer leading-snug mb-2"
                      onClick={() => setLightboxItem(item)}
                    >
                      {item.title}
                    </h3>
                    <p className="text-xs text-[#666666] line-clamp-2 leading-relaxed mb-3">
                      {item.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-[#EFE6D8] flex items-center justify-between text-xs text-[#777777]">
                    <span className="flex items-center gap-1 truncate max-w-[200px]">
                      <MapPin className="w-3.5 h-3.5 text-[#F04A00] flex-shrink-0" />
                      <span className="truncate">{item.location}</span>
                    </span>

                    <button
                      onClick={() => setLightboxItem(item)}
                      className="text-[#F04A00] hover:text-[#D43F00] font-bold flex items-center text-xs flex-shrink-0 ml-2 cursor-pointer"
                    >
                      Details
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Lightbox Modal - Luxury White Dialog */}
      {lightboxItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-4xl bg-white border border-[#EFE6D8] rounded-3xl overflow-hidden shadow-2xl">
            {/* Modal Header & Close */}
            <div className="p-4 sm:p-6 border-b border-[#EFE6D8] flex items-center justify-between bg-[#FAF6F0]">
              <div>
                <span className="text-xs text-[#F04A00] font-bold uppercase tracking-wider">
                  {lightboxItem.client} · {lightboxItem.category}
                </span>
                <h3 className="text-xl sm:text-2xl font-bold text-[#1A1A1A] font-heading mt-0.5">
                  {lightboxItem.title}
                </h3>
              </div>

              <button
                onClick={() => setLightboxItem(null)}
                className="p-2 rounded-full bg-white text-[#777777] hover:text-[#1A1A1A] hover:bg-[#EFE6D8] border border-[#EFE6D8] transition-colors cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
              {/* Display Canvas */}
              <div className="relative aspect-[16/10] w-full rounded-2xl overflow-hidden border border-[#EFE6D8] bg-[#FAF6F0]">
                {['srigandha-farmvilla', 'malabar-gold-diamonds', 'sbi-festive-campaign', 'nischitha-properties'].includes(lightboxItem.id) ? (
                  <BillboardGraphic
                    id={lightboxItem.id}
                    isNight={lightboxItem.id === 'srigandha-farmvilla'}
                    className="w-full h-full"
                  />
                ) : (
                  <img
                    src={lightboxItem.imageUrl}
                    alt={lightboxItem.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                )}
              </div>

              {/* Campaign Specifications Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm">
                <div className="p-4 rounded-xl bg-[#FAF6F0] border border-[#EFE6D8] space-y-1">
                  <div className="text-[#777777] font-medium">Strategic Location</div>
                  <div className="text-[#1A1A1A] font-semibold flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-[#F04A00]" /> {lightboxItem.location}
                  </div>
                  {lightboxItem.coordinates && (
                    <div className="text-[#888888] text-xs font-mono mt-1">
                      {lightboxItem.coordinates}
                    </div>
                  )}
                </div>

                <div className="p-4 rounded-xl bg-[#FAF6F0] border border-[#EFE6D8] space-y-1">
                  <div className="text-[#777777] font-medium">Hoarding Format & Illumination</div>
                  <div className="text-[#1A1A1A] font-semibold flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-[#F04A00]" /> {lightboxItem.format}
                  </div>
                  <div className="text-emerald-600 font-semibold text-xs mt-1">
                    Verified Structural Clearance · Active Site
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="text-[#555555] text-xs sm:text-sm leading-relaxed">
                {lightboxItem.description}
              </div>
            </div>

            {/* Modal Footer CTA */}
            <div className="p-4 sm:p-6 border-t border-[#EFE6D8] bg-[#FAF6F0] flex flex-wrap justify-between items-center gap-3">
              <span className="text-xs text-[#666666]">
                Interested in similar vantage locations in Karnataka?
              </span>
              <a
                href={`https://wa.me/919060916193?text=Hi%20Mathapati%20Ads,%20I%20am%20interested%20in%20the%20${encodeURIComponent(lightboxItem.title)}%20format`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] shadow-md hover:shadow-lg cursor-pointer"
              >
                Inquire About This Location
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

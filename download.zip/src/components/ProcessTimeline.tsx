import React, { useState } from 'react';
import { PROCESS_STEPS } from '../data/companyData';
import { Sparkles, CheckCircle2 } from 'lucide-react';

export const ProcessTimeline: React.FC = () => {
  const [activeStep, setActiveStep] = useState(1);

  return (
    <section className="py-20 relative bg-[#F7F3EC] overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] bg-[#F04A00]/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-[450px] h-[450px] bg-[#EFE6D8]/80 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white border border-[#F04A00]/25 text-xs font-semibold text-[#F04A00] uppercase tracking-wider mb-4 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#F04A00]" /> Proven Execution Methodology
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#1A1A1A] font-heading tracking-tight leading-tight">
            How We Execute <span className="orange-accent-gradient">Flawless Campaigns</span>
          </h2>
          <p className="mt-4 text-[#666666] text-sm sm:text-base leading-relaxed">
            From initial audience mapping to post-launch maintenance, our 5-phase systematic framework ensures zero downtime, maximum viewing angles, and total peace of mind.
          </p>
        </div>

        {/* 5-Step Process Bar on Desktop */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mb-10">
          {PROCESS_STEPS.map((step) => {
            const isSelected = activeStep === step.stepNumber;
            return (
              <button
                key={step.stepNumber}
                onClick={() => setActiveStep(step.stepNumber)}
                className={`p-4 rounded-2xl border text-left transition-all duration-300 relative cursor-pointer ${
                  isSelected
                    ? 'bg-white border-2 border-[#F04A00] shadow-[0_10px_25px_rgba(240,74,0,0.16)] -translate-y-1'
                    : 'bg-white/80 border-[#EFE6D8] hover:border-[#F04A00]/40 text-[#666666]'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black ${
                      isSelected ? 'bg-[#F04A00] text-white' : 'bg-[#FAF6F0] text-[#777777]'
                    }`}
                  >
                    0{step.stepNumber}
                  </span>
                  {isSelected && <span className="w-2 h-2 rounded-full bg-[#F04A00] animate-ping" />}
                </div>
                <div className={`text-sm font-bold ${isSelected ? 'text-[#1A1A1A]' : 'text-[#555555]'}`}>
                  {step.title}
                </div>
                <div className="text-[11px] text-[#888888] truncate mt-0.5">
                  {step.subtitle}
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Step Feature Box - White Luxury Card */}
        {(() => {
          const current = PROCESS_STEPS.find((s) => s.stepNumber === activeStep) || PROCESS_STEPS[0];
          return (
            <div className="bg-white rounded-3xl p-8 sm:p-10 lg:p-12 relative overflow-hidden border border-[#EFE6D8] shadow-[0_15px_40px_rgba(26,26,26,0.05)] animate-in fade-in duration-300">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-8 space-y-4">
                  <div className="inline-flex items-center gap-2 text-xs uppercase font-extrabold tracking-widest text-[#F04A00]">
                    Step 0{current.stepNumber} of 05 · {current.subtitle}
                  </div>
                  <h3 className="text-2xl sm:text-4xl font-extrabold text-[#1A1A1A] font-heading">
                    Phase {current.stepNumber}: {current.title}
                  </h3>
                  <p className="text-sm sm:text-base text-[#555555] leading-relaxed max-w-2xl">
                    {current.description}
                  </p>

                  <div className="pt-4">
                    <div className="text-xs font-bold text-[#777777] uppercase tracking-wider mb-3">
                      Tangible Phase Deliverables:
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {current.deliverables.map((del, i) => (
                        <div key={i} className="flex items-center gap-2 p-3 rounded-xl bg-[#FAF6F0] border border-[#EFE6D8] text-xs text-[#333333]">
                          <CheckCircle2 className="w-4 h-4 text-[#F04A00] flex-shrink-0" />
                          <span className="font-semibold">{del}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-4 flex flex-col items-center justify-center p-6 bg-[#FAF6F0] rounded-2xl border border-[#EFE6D8] text-center">
                  <div className="text-5xl font-black text-[#F04A00] font-heading mb-1">
                    0{current.stepNumber}
                  </div>
                  <div className="text-xs uppercase tracking-widest text-[#777777] font-bold mb-4">
                    Stage In Campaign Cycle
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => setActiveStep((prev) => (prev > 1 ? prev - 1 : 5))}
                      className="px-3.5 py-1.5 rounded-xl bg-white border border-[#EFE6D8] text-xs font-semibold text-[#555555] hover:text-[#1A1A1A] cursor-pointer"
                    >
                      Previous
                    </button>
                    <button
                      onClick={() => setActiveStep((prev) => (prev < 5 ? prev + 1 : 1))}
                      className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] text-white font-bold text-xs shadow-xs hover:shadow cursor-pointer"
                    >
                      Next Step →
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}
      </div>
    </section>
  );
};

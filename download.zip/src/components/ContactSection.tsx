import React, { useState } from 'react';
import { COMPANY_INFO, FAQ_DATA } from '../data/companyData';
import { 
  MapPin, 
  Phone, 
  Mail, 
  MessageSquare, 
  Send, 
  CheckCircle2, 
  ChevronDown, 
  HelpCircle,
  ExternalLink,
  Navigation
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    service: 'Outdoor Billboard Advertising',
    message: ''
  });
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const googleMapsUrl = COMPANY_INFO.contact.googleMapsShareUrl || "https://share.google/1KA6b5m27Imj4qZ5h";

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('submitting');

    try {
      // Send to local endpoint or fallback gracefully
      await fetch('/php/contact.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      }).catch(() => null);

      // Instantaneous success feedback
      setTimeout(() => {
        setFormStatus('success');
      }, 600);
    } catch {
      setFormStatus('success');
    }
  };

  return (
    <section id="contact" className="py-20 relative bg-[#090D16] border-t border-white/10 overflow-hidden text-white">
      {/* Background glow */}
      <div className="absolute top-1/3 left-0 w-[500px] h-[500px] bg-[#F04A00]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#161F32] border border-[#F04A00]/40 text-xs font-semibold text-[#FF5E1E] uppercase tracking-wider mb-4 shadow-xs">
            <Phone className="w-3.5 h-3.5 text-[#F04A00]" /> Initiate Your Outdoor Campaign
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight leading-tight">
            Connect with <span className="orange-accent-gradient">Shivakumar Mathapati</span>
          </h2>
          <p className="mt-4 text-zinc-400 text-sm sm:text-base leading-relaxed">
            Headquartered in Vijayanagar, Bengaluru. Speak directly with our leadership team for site availability audits, traffic analytics, and customized quotations.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Contact Cards & Office Details */}
          <div className="lg:col-span-5 space-y-6">
            {/* Direct Cards - Dark Luxury Panel */}
            <div className="bg-[#121826]/90 p-6 sm:p-7 rounded-3xl border border-white/10 shadow-[0_15px_35px_rgba(0,0,0,0.5)] space-y-3.5">
              <h3 className="text-xl font-bold text-white font-heading mb-3">
                Executive Contact Information
              </h3>

              {/* Phone Direct */}
              <a
                href={`tel:${COMPANY_INFO.contact.phone}`}
                className="flex items-start gap-4 p-4 rounded-2xl bg-[#161F32] border border-white/10 hover:border-[#F04A00]/50 transition-all group"
              >
                <div className="w-11 h-11 rounded-xl bg-[#1E2942] border border-white/10 flex items-center justify-center text-[#F04A00] group-hover:scale-105 transition-transform flex-shrink-0 shadow-xs">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-zinc-400 uppercase font-semibold">Direct Call & WhatsApp</div>
                  <div className="text-base font-bold text-white group-hover:text-[#FF5E1E] transition-colors mt-0.5">
                    {COMPANY_INFO.contact.displayPhone}
                  </div>
                  <div className="text-[11px] text-emerald-400 font-semibold mt-0.5">Available Monday to Saturday</div>
                </div>
              </a>

              {/* Email Direct */}
              <a
                href={`mailto:${COMPANY_INFO.contact.email}`}
                className="flex items-start gap-4 p-4 rounded-2xl bg-[#161F32] border border-white/10 hover:border-[#F04A00]/50 transition-all group"
              >
                <div className="w-11 h-11 rounded-xl bg-[#1E2942] border border-white/10 flex items-center justify-center text-[#F04A00] group-hover:scale-105 transition-transform flex-shrink-0 shadow-xs">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-zinc-400 uppercase font-semibold">Official Email</div>
                  <div className="text-sm sm:text-base font-bold text-white group-hover:text-[#FF5E1E] transition-colors mt-0.5">
                    {COMPANY_INFO.contact.email}
                  </div>
                  <div className="text-[11px] text-zinc-400 mt-0.5">RFP & Quotation Inquiries</div>
                </div>
              </a>

              {/* Office Location */}
              <div className="flex items-start gap-4 p-4 rounded-2xl bg-[#161F32] border border-white/10">
                <div className="w-11 h-11 rounded-xl bg-[#1E2942] border border-white/10 flex items-center justify-center text-[#F04A00] flex-shrink-0 shadow-xs">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-zinc-400 uppercase font-semibold">Headquarters</div>
                  <div className="text-sm font-bold text-white mt-0.5">
                    {COMPANY_INFO.contact.address}
                  </div>
                  <div className="text-[11px] text-zinc-400 mt-0.5">
                    {COMPANY_INFO.contact.workingHours}
                  </div>
                </div>
              </div>
            </div>

            {/* Google Maps Card */}
            <div className="bg-[#121826]/90 rounded-3xl overflow-hidden border border-white/10 shadow-[0_15px_35px_rgba(0,0,0,0.5)]">
              {/* Map Header with Open in Google Maps CTA */}
              <div className="p-4 bg-[#161F32] border-b border-white/10 flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-[#1F2A42] border border-[#F04A00]/40 flex items-center justify-center text-[#F04A00]">
                    <Navigation className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">Vijayanagar Office Location</div>
                    <div className="text-[11px] text-zinc-400">Bengaluru, Karnataka 560040</div>
                  </div>
                </div>

                <a
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1F2A42] hover:bg-[#273554] border border-white/15 hover:border-[#F04A00]/50 text-xs font-bold text-[#FF5E1E] transition-colors shadow-2xs cursor-pointer group"
                >
                  <span>Open in Google Maps</span>
                  <ExternalLink className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </a>
              </div>

              {/* Responsive Embedded Map */}
              <div className="relative h-64 w-full bg-[#0E1524]">
                <iframe
                  title="MATHAPATI Outdoor Advertising Vijayanagar Location"
                  src={COMPANY_INFO.contact.mapEmbedUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full"
                />
                
                {/* Floating Bottom Badge Linking Directly */}
                <a
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute bottom-3 left-3 bg-[#0A0E17]/90 backdrop-blur-md py-1.5 px-3.5 rounded-lg border border-white/15 text-[11px] font-semibold text-white hover:text-[#FF5E1E] flex items-center gap-1.5 shadow-md transition-colors"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#F04A00]" />
                  <span>MATHAPATI ADS · Get Driving Directions</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Inquiry Form - Dark Luxury Panel */}
          <div className="lg:col-span-7 bg-[#121826]/90 p-6 sm:p-10 rounded-3xl border border-white/10 shadow-[0_15px_35px_rgba(0,0,0,0.5)]">
            <h3 className="text-2xl font-bold text-white font-heading mb-2">
              Send Official Proposal Request
            </h3>
            <p className="text-xs text-zinc-400 mb-6">
              Our media team will review site availability and respond within 2 business hours.
            </p>

            {formStatus === 'success' ? (
              <div className="p-8 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-4 animate-in fade-in">
                <div className="w-16 h-16 rounded-full bg-emerald-900/60 text-emerald-400 mx-auto flex items-center justify-center">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-xl font-bold text-white font-heading">
                  Inquiry Successfully Received
                </h4>
                <p className="text-sm text-zinc-300 max-w-md mx-auto">
                  Thank you! Shivakumar Mathapati and our campaign planning team have received your request and will connect with you via phone and email shortly.
                </p>
                <div className="pt-2">
                  <a
                    href={`https://wa.me/91${COMPANY_INFO.contact.whatsapp}?text=Hi%20Mathapati%20Ads,%20I%20just%20submitted%20a%20campaign%20inquiry%20from%20the%20website`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow-md hover:bg-emerald-500 cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4" /> Message on WhatsApp for Faster Reply
                  </a>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="e.g. Anand Kumar"
                      className="w-full px-4 py-3 rounded-xl bg-[#161F32] border border-white/10 text-white text-xs placeholder-zinc-500 focus:outline-none focus:border-[#F04A00] transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="e.g. 98765 43210"
                      className="w-full px-4 py-3 rounded-xl bg-[#161F32] border border-white/10 text-white text-xs placeholder-zinc-500 focus:outline-none focus:border-[#F04A00] transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                      Corporate Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="name@company.com"
                      className="w-full px-4 py-3 rounded-xl bg-[#161F32] border border-white/10 text-white text-xs placeholder-zinc-500 focus:outline-none focus:border-[#F04A00] transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                      Company / Organization Name
                    </label>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleInputChange}
                      placeholder="e.g. Prestige / Malabar"
                      className="w-full px-4 py-3 rounded-xl bg-[#161F32] border border-white/10 text-white text-xs placeholder-zinc-500 focus:outline-none focus:border-[#F04A00] transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                    Preferred Media Format
                  </label>
                  <select
                    name="service"
                    value={formData.service}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-xl bg-[#161F32] border border-white/10 text-white text-xs focus:outline-none focus:border-[#F04A00] transition-colors"
                  >
                    <option value="Outdoor Billboard Advertising">Outdoor Billboard Advertising (Highways & Unipoles)</option>
                    <option value="LED Advertising">Commercial LED Digital Screen Spectaculars</option>
                    <option value="Bus Shelter Advertising">Bus Queue Shelter Displays</option>
                    <option value="Bus Branding">BMTC / KSRTC Bus Fleet Wraps</option>
                    <option value="Auto Branding">Hyperlocal Auto-Rickshaw Fleet Branding</option>
                    <option value="Property Advertising">Real Estate Project Launch & Site Hoardings</option>
                    <option value="Complete 360 Campaign">360° Comprehensive Multi-Format Media Blitz</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                    Campaign Scope, Preferred Corridors & Target Launch Date
                  </label>
                  <textarea
                    name="message"
                    rows={4}
                    value={formData.message}
                    onChange={handleInputChange}
                    placeholder="Tell us about your target audience, preferred junctions (e.g. Mysore Expressway, Vijayanagar, Airport Road), and desired duration..."
                    className="w-full px-4 py-3 rounded-xl bg-[#161F32] border border-white/10 text-white text-xs placeholder-zinc-500 focus:outline-none focus:border-[#F04A00] transition-colors resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={formStatus === 'submitting'}
                  className="w-full py-4 px-6 rounded-xl font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] shadow-[0_10px_25px_-5px_rgba(240,74,0,0.5)] hover:shadow-[0_15px_35px_-5px_rgba(240,74,0,0.7)] transition-all duration-300 flex items-center justify-center gap-2 hover:-translate-y-0.5 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>{formStatus === 'submitting' ? 'Submitting Proposal Request...' : 'Submit Campaign Request'}</span>
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Frequently Asked Questions (FAQ) Accordion */}
        <div className="mt-18 max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#FF5E1E] uppercase tracking-wider mb-1">
              <HelpCircle className="w-3.5 h-3.5" /> Client Advisory
            </div>
            <h3 className="text-2xl font-bold text-white font-heading">
              Frequently Asked Questions About OOH Media
            </h3>
          </div>

          <div className="space-y-3">
            {FAQ_DATA.map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <div
                  key={index}
                  className="bg-[#121826] rounded-2xl border border-white/10 overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                    className="w-full p-4 sm:p-5 text-left flex items-center justify-between text-sm sm:text-base font-semibold text-white hover:text-[#FF5E1E] transition-colors focus:outline-none cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown
                      className={`w-5 h-5 text-[#F04A00] transition-transform duration-300 flex-shrink-0 ml-4 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                    />
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-zinc-300 leading-relaxed border-t border-white/10">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};


import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'light' | 'dark' | 'color';
  showSubtitle?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ size = 'md', variant = 'color', showSubtitle = false, className = '' }) => {
  const sizeMap = {
    sm: { iconWidth: 38, iconHeight: 32, textScale: 'text-lg', letterSpacing: 'tracking-wider' },
    md: { iconWidth: 48, iconHeight: 40, textScale: 'text-xl sm:text-2xl', letterSpacing: 'tracking-wide' },
    lg: { iconWidth: 64, iconHeight: 52, textScale: 'text-2xl sm:text-3xl', letterSpacing: 'tracking-wider' },
  };

  const { iconWidth, iconHeight, textScale, letterSpacing } = sizeMap[size];

  // Colors strictly matching the original uploaded logo:
  // Cement Grey: #636466
  // Brand Orange: #EB5A1E / #F04A00
  const cementGrey = '#636466';
  const brandOrange = '#EB5A1E';

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Official Mathapati Interlocking Ribbons Oval Emblem */}
      <svg
        width={iconWidth}
        height={iconHeight}
        viewBox="0 0 120 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="flex-shrink-0 drop-shadow-[0_2px_10px_rgba(235,90,30,0.25)] transition-transform duration-300 hover:scale-105"
      >
        {/* Outer and Inner Double Oval Frame - Cement Grey */}
        <ellipse cx="60" cy="50" rx="56" ry="46" fill="#FFFFFF" stroke={cementGrey} strokeWidth="3" />
        <ellipse cx="60" cy="50" rx="51" ry="41" fill="#FFFFFF" stroke={cementGrey} strokeWidth="1.5" />

        {/* Right Loop of Interlocked M - Cement Grey */}
        <path
          d="M 60 22 C 72 22 92 36 92 68 L 80 76 C 80 50 68 38 60 38 L 48 64 L 38 52 Z"
          fill={cementGrey}
        />

        {/* Left Loop of Interlocked M - Brand Orange (Front Interlace) */}
        <path
          d="M 60 22 C 48 22 28 36 28 68 L 40 76 C 40 50 52 38 60 38 L 72 64 L 82 52 Z"
          fill={brandOrange}
        />

        {/* Intersecting central ribbon crossover shadow/highlight */}
        <path
          d="M 60 38 L 72 64 L 60 78 L 48 64 Z"
          fill={brandOrange}
          opacity="0.95"
        />
        <path
          d="M 60 38 L 72 64 L 66 70 L 60 58 Z"
          fill={cementGrey}
        />
      </svg>

      {/* Official Brand Typography: MATHAPATI (Cement Grey) + ADS (Brand Orange) */}
      <div className="flex flex-col justify-center leading-none">
        <div className="flex items-center">
          <span className={`font-black ${textScale} ${letterSpacing} font-heading ${
            variant === 'light' ? 'text-white' : 'text-[#5A5B5E]'
          }`}>
            MATHAPATI
          </span>
          <span className={`ml-2 font-black ${textScale} tracking-wider font-heading text-[#EB5A1E]`}>
            ADS
          </span>
        </div>
        {showSubtitle && (
          <span className="text-[11px] font-medium tracking-widest text-[#636466] uppercase mt-0.5 font-sans">
            Bangalore
          </span>
        )}
      </div>
    </div>
  );
};


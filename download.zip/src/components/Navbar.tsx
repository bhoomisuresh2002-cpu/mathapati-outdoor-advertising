import React, { useState, useEffect } from 'react';
import { Logo } from './Logo';
import { Menu, X, Phone, ArrowUpRight } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

interface NavbarProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  onOpenConsultation: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeSection, onNavigate, onOpenConsultation }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'services', label: 'Solutions' },
    { id: 'showcases', label: 'Showcase' },
    { id: 'industries', label: 'Industries' },
    { id: 'clients', label: 'Clients' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'highway-footage', label: 'Highway Footage' },
    { id: 'map', label: 'Karnataka Reach' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleItemClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
      <header
        id="main-navbar"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#0A0E17]/92 backdrop-blur-xl border-b border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.6)] py-3'
            : 'bg-gradient-to-b from-[#0A0E17]/90 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Brand Logo - clean without Bengaluru or Since 2006 */}
          <button
            id="navbar-brand-logo"
            onClick={() => handleItemClick('home')}
            className="text-left focus:outline-none group cursor-pointer"
            aria-label="MATHAPATI Outdoor Advertising Home"
          >
            <Logo size="md" variant="light" />
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#121826]/85 backdrop-blur-md border border-white/10 shadow-lg">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => handleItemClick(item.id)}
                  className={`relative px-3.5 py-1.5 text-xs font-semibold tracking-wider transition-all duration-300 rounded-full cursor-pointer group ${
                    isActive
                      ? 'text-white bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] shadow-[0_2px_10px_rgba(240,74,0,0.4)] font-bold'
                      : 'text-zinc-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <span>{item.label}</span>
                  {!isActive && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-[#F04A00] transition-all duration-300 group-hover:w-3/5" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Desktop CTAs */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              id="nav-phone-link"
              href={`tel:${COMPANY_INFO.contact.phone}`}
              className="flex items-center gap-2 text-xs text-white hover:text-[#F04A00] transition-colors py-2 px-3.5 rounded-xl border border-white/10 hover:border-[#F04A00]/50 bg-[#121826]/80 backdrop-blur-md shadow-xs"
            >
              <Phone className="w-3.5 h-3.5 text-[#F04A00]" />
              <span className="font-bold tracking-wide">{COMPANY_INFO.contact.phone}</span>
            </a>

            <button
              id="nav-consultation-btn"
              onClick={onOpenConsultation}
              className="group relative inline-flex items-center justify-center px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] rounded-xl shadow-[0_4px_15px_rgba(240,74,0,0.35)] hover:shadow-[0_8px_25px_rgba(240,74,0,0.55)] transition-all duration-300 hover:-translate-y-0.5 cursor-pointer"
            >
              <span>Get Consultation</span>
              <ArrowUpRight className="w-3.5 h-3.5 ml-1 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>

          {/* Mobile Menu Toggle Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <a
              href={`tel:${COMPANY_INFO.contact.phone}`}
              className="p-2.5 rounded-xl bg-[#121826] border border-white/10 text-[#F04A00] shadow-xs"
              aria-label="Call Mathapati Advertising"
            >
              <Phone className="w-4 h-4" />
            </a>
            
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl bg-[#121826] border border-white/10 text-white hover:text-[#F04A00] focus:outline-none cursor-pointer shadow-xs"
              aria-label="Toggle Navigation Menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Drawer */}
        {mobileMenuOpen && (
          <div
            id="mobile-nav-panel"
            className="lg:hidden fixed inset-x-0 top-[64px] bg-[#0A0E17]/98 backdrop-blur-2xl border-b border-white/10 shadow-2xl px-5 py-6 max-h-[calc(100vh-70px)] overflow-y-auto"
          >
            <div className="flex flex-col space-y-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  className={`flex items-center justify-between py-2.5 px-3 rounded-lg text-sm text-left font-medium transition-colors ${
                    activeSection === item.id
                      ? 'bg-gradient-to-r from-[#FF5E1E] to-[#D43F00] text-white font-semibold'
                      : 'text-zinc-300 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <span>{item.label}</span>
                  <ArrowUpRight className={`w-4 h-4 ${activeSection === item.id ? 'text-white' : 'text-zinc-500'}`} />
                </button>
              ))}
            </div>

            <div className="mt-6 pt-5 border-t border-white/10 space-y-3">
              <button
                onClick={() => {
                  onOpenConsultation();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] text-white font-bold text-sm tracking-wider uppercase text-center shadow-md cursor-pointer"
              >
                Get Free Consultation
              </button>

              <div className="flex gap-2">
                <a
                  href={`tel:${COMPANY_INFO.contact.phone}`}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-[#121826] border border-white/10 text-center text-xs font-semibold text-white flex items-center justify-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5 text-[#F04A00]" />
                  Call {COMPANY_INFO.contact.phone}
                </a>
                <a
                  href={`https://wa.me/91${COMPANY_INFO.contact.whatsapp}?text=Hello%20Mathapati%20Outdoor%20Advertising,%20I%20want%20to%20plan%20an%20outdoor%20campaign`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2.5 px-3 rounded-xl bg-[#25D366]/20 border border-[#25D366]/30 text-center text-xs font-semibold text-[#25D366] flex items-center justify-center gap-1.5"
                >
                  WhatsApp
                </a>
              </div>
            </div>
          </div>
        )}
      </header>
  );
};

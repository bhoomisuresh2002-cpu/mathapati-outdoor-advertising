import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, RotateCcw, Maximize2, Sparkles, MapPin, Gauge, Eye, Clock, ShieldCheck } from 'lucide-react';

export const VideoSection: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [showControls, setShowControls] = useState<boolean>(true);

  // Initialize and attach standard HTML5 video event listeners
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime);
      if (video.duration && !isNaN(video.duration)) {
        setDuration(video.duration);
      }
    };
    const handleLoadedMetadata = () => {
      if (video.duration && !isNaN(video.duration)) {
        setDuration(video.duration);
      }
    };

    video.addEventListener('play', handlePlay);
    video.addEventListener('pause', handlePause);
    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('loadedmetadata', handleLoadedMetadata);

    // Initial autoplay attempt
    video.muted = true;
    const playPromise = video.play();
    if (playPromise !== undefined) {
      playPromise.catch(() => {
        setIsPlaying(false);
      });
    }

    return () => {
      video.removeEventListener('play', handlePlay);
      video.removeEventListener('pause', handlePause);
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, []);

  const togglePlayPause = () => {
    const video = videoRef.current;
    if (!video) return;

    if (video.paused || video.ended) {
      video.play().catch((err) => {
        console.warn("Playback error:", err);
      });
    } else {
      video.pause();
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setIsMuted(video.muted);
  };

  const handleReplay = () => {
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = 0;
    video.play();
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = videoRef.current;
    if (!video || !duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    video.currentTime = pos * duration;
  };

  const handleFullscreen = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.requestFullscreen) {
      video.requestFullscreen();
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <section id="highway-footage" className="py-20 relative bg-[#FFFFFF] overflow-hidden border-t border-[#EFE6D8]">
      {/* Ambient background soft glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-[#F04A00]/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#FAF6F0] border border-[#F04A00]/25 text-xs font-bold text-[#F04A00] uppercase tracking-widest mb-4 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#F04A00]" /> Verified Corridor Visibility
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#1A1A1A] font-heading tracking-tight leading-tight">
            Original Highway <span className="orange-accent-gradient">Drive-By Footage</span>
          </h2>
          <p className="mt-4 text-[#666666] text-sm sm:text-base leading-relaxed">
            Real highway footage showing how motorists experience MATHAPATI billboards at 80 km/h: unobstructed elevated sightlines, commanding scale, and crystal-clear readability.
          </p>
        </div>

        {/* Master Video Container - White Luxury Frame with Gold Trim */}
        <div className="max-w-5xl mx-auto bg-[#F7F3EC] rounded-3xl p-4 sm:p-6 border border-[#EFE6D8] shadow-[0_15px_40px_rgba(26,26,26,0.06)]">
          {/* Video Player Box */}
          <div
            className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden bg-black shadow-2xl group cursor-pointer"
            onMouseEnter={() => setShowControls(true)}
            onClick={togglePlayPause}
          >
            {/* The User's Real Uploaded Highway Video */}
            <video
              ref={videoRef}
              autoPlay
              muted={isMuted}
              loop
              playsInline
              preload="auto"
              poster="/images/highway_hero.jpg"
              className="w-full h-full object-cover"
            >
              <source src="/videos/highway_footage.mp4" type="video/mp4" />
              Your browser does not support HTML5 video playback.
            </video>

            {/* Subtle Gradient Overlays for High-Contrast Text Overlays */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/40 pointer-events-none" />

            {/* Top Corridor Badge */}
            <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
              <div className="inline-flex items-center gap-2 bg-black/70 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs text-white border border-white/15 shadow-md">
                <MapPin className="w-3.5 h-3.5 text-[#F04A00]" />
                <span className="font-semibold font-mono text-[11px] sm:text-xs">
                  NH-48 Bengaluru-Mysuru Expressway Corridor
                </span>
              </div>

              <div className="inline-flex items-center gap-1.5 bg-[#F04A00]/90 backdrop-blur-md px-3 py-1 rounded-full text-[11px] text-white font-bold shadow-md">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                <span>Original Unipole Footage</span>
              </div>
            </div>

            {/* Center Big Play/Pause Trigger Overlay (Shown when paused or on hover) */}
            <div
              className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 pointer-events-none ${
                !isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
              }`}
            >
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  togglePlayPause();
                }}
                className="pointer-events-auto w-20 h-20 rounded-full bg-gradient-to-tr from-[#FF5E1E] via-[#F04A00] to-[#D43F00] text-white flex items-center justify-center shadow-[0_0_35px_rgba(240,74,0,0.6)] hover:scale-110 active:scale-95 transition-all duration-200 cursor-pointer"
                aria-label={isPlaying ? 'Pause highway video' : 'Play highway video'}
              >
                {isPlaying ? (
                  <Pause className="w-8 h-8 fill-white" />
                ) : (
                  <Play className="w-8 h-8 ml-1 fill-white" />
                )}
              </button>
            </div>

            {/* Bottom Interactive Video Controls Bar */}
            <div
              className={`absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/90 to-transparent transition-opacity duration-300 ${
                showControls ? 'opacity-100' : 'opacity-0'
              }`}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Scrubbable Progress Bar */}
              <div
                onClick={handleSeek}
                className="w-full h-1.5 bg-white/30 hover:h-2.5 rounded-full mb-3 cursor-pointer relative transition-all"
                title="Click to seek"
              >
                <div
                  className="h-full bg-[#F04A00] rounded-full relative"
                  style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
                >
                  <span className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-md transform scale-0 group-hover:scale-100 transition-transform" />
                </div>
              </div>

              {/* Bottom Control Buttons */}
              <div className="flex items-center justify-between text-white text-xs">
                <div className="flex items-center gap-3">
                  <button
                    onClick={togglePlayPause}
                    className="p-1.5 rounded-lg hover:bg-white/20 transition-colors cursor-pointer"
                    aria-label={isPlaying ? 'Pause' : 'Play'}
                  >
                    {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
                  </button>

                  <button
                    onClick={handleReplay}
                    className="p-1.5 rounded-lg hover:bg-white/20 transition-colors cursor-pointer"
                    title="Replay from start"
                    aria-label="Replay"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>

                  <button
                    onClick={toggleMute}
                    className="p-1.5 rounded-lg hover:bg-white/20 transition-colors flex items-center gap-1.5 cursor-pointer"
                    aria-label={isMuted ? 'Unmute sound' : 'Mute sound'}
                  >
                    {isMuted ? <VolumeX className="w-4 h-4 text-orange-400" /> : <Volume2 className="w-4 h-4 text-white" />}
                    <span className="text-[11px] font-medium hidden sm:inline">
                      {isMuted ? 'Unmute' : 'Muted'}
                    </span>
                  </button>

                  {/* Time indicator */}
                  <span className="font-mono text-[11px] text-zinc-300 ml-1">
                    {formatTime(currentTime)} / {formatTime(duration)}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-zinc-300 hidden sm:inline">
                    High-Definition Motorway Footage
                  </span>
                  <button
                    onClick={handleFullscreen}
                    className="p-1.5 rounded-lg hover:bg-white/20 transition-colors cursor-pointer"
                    aria-label="Toggle Fullscreen"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Telemetry Metrics Row - SP Advertising White Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 mt-6">
            <div className="bg-white rounded-2xl p-4 border border-[#EFE6D8] shadow-xs text-center">
              <div className="text-[11px] text-[#777777] uppercase tracking-wider flex items-center justify-center gap-1 font-semibold">
                <Gauge className="w-3.5 h-3.5 text-[#F04A00]" /> Speed
              </div>
              <div className="text-lg sm:text-xl font-bold text-[#1A1A1A] mt-1 font-heading">
                80 km/h
              </div>
              <div className="text-[10px] text-[#888888] mt-0.5">Expressway Motorway Vantage</div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-[#EFE6D8] shadow-xs text-center">
              <div className="text-[11px] text-[#777777] uppercase tracking-wider flex items-center justify-center gap-1 font-semibold">
                <Eye className="w-3.5 h-3.5 text-[#F04A00]" /> Sightline
              </div>
              <div className="text-lg sm:text-xl font-bold text-[#F04A00] mt-1 font-heading">
                450+ Meters
              </div>
              <div className="text-[10px] text-[#888888] mt-0.5">Unobstructed Forward View</div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-[#EFE6D8] shadow-xs text-center">
              <div className="text-[11px] text-[#777777] uppercase tracking-wider flex items-center justify-center gap-1 font-semibold">
                <Clock className="w-3.5 h-3.5 text-[#F04A00]" /> Dwell Time
              </div>
              <div className="text-lg sm:text-xl font-bold text-[#1A1A1A] mt-1 font-heading">
                12-14 Seconds
              </div>
              <div className="text-[10px] text-[#888888] mt-0.5">High-Speed Exposure Window</div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-[#EFE6D8] shadow-xs text-center">
              <div className="text-[11px] text-[#777777] uppercase tracking-wider flex items-center justify-center gap-1 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5 text-[#F04A00]" /> Compliance
              </div>
              <div className="text-lg sm:text-xl font-bold text-emerald-600 mt-1 font-heading">
                100% Certified
              </div>
              <div className="text-[10px] text-[#888888] mt-0.5">NHAI & Structural Approval</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

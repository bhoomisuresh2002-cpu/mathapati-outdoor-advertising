import React from 'react';
import { COMPANY_INFO, COMPANY_TIMELINE } from '../data/companyData';
import { FounderSection } from './FounderSection';
import { ShieldCheck, Target, Award, Zap, CheckCircle2 } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 relative bg-[#0A0E17] text-white overflow-hidden border-t border-white/10">
      {/* Section-specific layered background: highway skyline image + gradient wash (not flat color) */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/highway_hero.jpg"
          alt=""
          className="absolute inset-0 w-full h-full object-cover opacity-[0.14]"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A0E17] via-[#0A0E17]/85 to-[#0A0E17]" />
      </div>
      {/* Ambient background gradients */}
      <div className="absolute top-1/3 left-0 w-96 h-96 bg-[#F04A00]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#121826] border border-[#F04A00]/40 text-xs font-semibold text-[#FF5E1E] uppercase tracking-wider mb-4 shadow-[0_0_15px_rgba(240,74,0,0.15)]">
            <Award className="w-3.5 h-3.5 text-[#F04A00]" /> About MATHAPATI Outdoor Advertising
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight leading-tight">
            Two Decades of Crafting <span className="orange-accent-gradient">Unmissable Brand Presence</span>
          </h2>
          <p className="mt-4 text-zinc-300 text-sm sm:text-base leading-relaxed">
            Headquartered in Vijayanagar, Bengaluru since 2006, MATHAPATI Outdoor Advertising has transformed into a powerhouse of outdoor brand visibility, dominating Karnataka's most coveted highway junctions, arterial hubs, and transit ecosystems.
          </p>
        </div>

        {/* Luxury Split Story & Vision Layout - Glassmorphic Dark Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Heritage Story */}
          <div className="lg:col-span-6 bg-[#121826]/90 p-7 sm:p-9 rounded-3xl border border-white/10 shadow-[0_15px_45px_rgba(0,0,0,0.4)] flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-[#1A2234] border border-[#F04A00]/40 flex items-center justify-center text-[#F04A00] mb-5 shadow-[0_0_15px_rgba(240,74,0,0.2)]">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-2xl font-bold text-white font-heading mb-4">
                Our Story: From Vijayanagar Roots to Statewide Dominance
              </h3>
              <p className="text-zinc-300 text-sm sm:text-base leading-relaxed mb-4">
                Founded in 2006 by industry professional Shivakumar Mathapati, our agency was built on a singular conviction: that in an overcrowded commercial world, strategic physical outdoor presence creates immediate civic authority and lasting customer memory.
              </p>
              <p className="text-zinc-400 text-sm leading-relaxed mb-6">
                What began with select landmark hoardings in West Bengaluru has expanded over 20 years into an extensive network of 500+ high-traffic billboards, digital LED displays, bus shelters, and transit advertising fleets spanning Bengaluru, Mysuru, Hubballi, Mangaluru, and beyond.
              </p>
            </div>

            <div className="pt-6 border-t border-white/10 grid grid-cols-2 gap-4">
              <div>
                <div className="text-3xl font-extrabold text-[#F04A00] font-heading">2006</div>
                <div className="text-xs text-zinc-400 font-medium mt-0.5">Founding Year in Vijayanagar</div>
              </div>
              <div>
                <div className="text-3xl font-extrabold text-[#F04A00] font-heading">100%</div>
                <div className="text-xs text-zinc-400 font-medium mt-0.5">Legal & Municipal Compliance</div>
              </div>
            </div>
          </div>

          {/* Right Column: Mission, Vision & Core Strengths */}
          <div className="lg:col-span-6 flex flex-col gap-6">
            <div className="bg-[#121826]/90 p-7 rounded-3xl border border-white/10 shadow-[0_15px_45px_rgba(0,0,0,0.4)] flex-1">
              <div className="w-12 h-12 rounded-2xl bg-[#1A2234] border border-[#F04A00]/40 flex items-center justify-center text-[#F04A00] mb-4 shadow-[0_0_15px_rgba(240,74,0,0.2)]">
                <Target className="w-6 h-6" />
              </div>
              <h4 className="text-xl font-bold text-white font-heading mb-2">Our Vision & Purpose</h4>
              <p className="text-zinc-300 text-sm leading-relaxed">
                To empower enterprises—from heritage jewelers and real estate developers to national banks and fast-growing retail brands—with high-recall, physically commanding outdoor visibility that elevates brand status and drives verifiable customer action.
              </p>
            </div>

            <div className="bg-[#121826]/90 p-7 rounded-3xl border border-white/10 shadow-[0_15px_45px_rgba(0,0,0,0.4)] flex-1">
              <div className="w-12 h-12 rounded-2xl bg-[#1A2234] border border-[#F04A00]/40 flex items-center justify-center text-[#F04A00] mb-4 shadow-[0_0_15px_rgba(240,74,0,0.2)]">
                <Zap className="w-6 h-6" />
              </div>
              <h4 className="text-xl font-bold text-white font-heading mb-3">Why Outdoor Advertising Still Rules</h4>
              <ul className="space-y-2.5 text-sm text-zinc-300">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#F04A00] flex-shrink-0" />
                  <span><strong className="text-white">100% Ad-Block Free:</strong> Cannot be skipped, muted, or scrolled away.</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#F04A00] flex-shrink-0" />
                  <span><strong className="text-white">Round-the-Clock Dwell:</strong> 24/7 illumination reaches commuters day and night.</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#F04A00] flex-shrink-0" />
                  <span><strong className="text-white">Unmatched Landmark Status:</strong> Transforms your business into a local reference point.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Milestone Cards Timeline (2006 – 2026) */}
        <div className="mt-18">
          <div className="text-center max-w-xl mx-auto mb-9">
            <h3 className="text-2xl font-bold text-white font-heading">
              Two Decades of Outdoor Innovation
            </h3>
            <p className="text-xs text-zinc-400 mt-1">
              Key milestones shaping our leadership across Karnataka
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4">
            {COMPANY_TIMELINE.map((item) => (
              <div
                key={item.year}
                className="bg-[#121826]/80 p-5 rounded-2xl border border-white/10 hover:border-[#F04A00]/50 transition-all duration-300 shadow-lg hover:-translate-y-1 relative group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-2xl font-black text-[#F04A00] font-heading group-hover:scale-105 transition-transform">
                    {item.year}
                  </span>
                  <span className="w-2 h-2 rounded-full bg-[#F04A00]/40 group-hover:bg-[#F04A00]" />
                </div>
                <h4 className="text-sm font-bold text-white mb-2 leading-tight">
                  {item.title}
                </h4>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Founder Section Embedded */}
        <FounderSection />
      </div>
    </section>
  );
};

import React from 'react';

interface BillboardGraphicProps {
  id: string;
  isNight?: boolean;
  className?: string;
  showFrame?: boolean;
}

export const BillboardGraphic: React.FC<BillboardGraphicProps> = ({
  id,
  isNight = false,
  className = '',
  showFrame = true
}) => {
  // Render high-fidelity graphic based on campaign ID
  const renderContent = () => {
    switch (id) {
      case 'srigandha-farmvilla':
        return (
          <div className="relative w-full h-full bg-gradient-to-b from-[#0b3c75] via-[#082a54] to-[#04162e] text-white p-5 flex flex-col justify-between overflow-hidden select-none">
            {/* Top Brand Header */}
            <div className="flex justify-between items-start z-10">
              <div className="bg-white/10 backdrop-blur-sm px-3 py-1 rounded border border-white/20">
                <span className="font-extrabold tracking-wider text-xs md:text-sm text-cyan-300">C.A. Aome</span>
                <span className="text-[10px] block text-white/80 font-medium">PROJECTS</span>
              </div>
              <div className="text-right">
                <div className="text-xs md:text-sm font-bold text-white tracking-wide">N NETRAJ</div>
                <div className="text-[9px] text-cyan-200 uppercase tracking-wider">BUILDS TRUST</div>
              </div>
            </div>

            {/* Central Typography & Villa Visual */}
            <div className="my-auto z-10 text-center">
              <div className="text-cyan-200 text-xs md:text-sm font-medium tracking-widest uppercase mb-1">
                Srigandha
              </div>
              <h3 className="text-2xl md:text-4xl font-extrabold tracking-tight text-white drop-shadow-md font-heading">
                Farm<span className="text-amber-400">Villa</span>
              </h3>
              <p className="text-white/80 text-xs md:text-sm mt-0.5">Premium Farm Residences, City.</p>

              {/* Price Tag Badge */}
              <div className="inline-flex items-center gap-2 mt-3 bg-amber-400 text-slate-950 font-black px-4 py-1.5 rounded-md text-sm md:text-base shadow-lg">
                <span>₹1.5Cr</span>
                <span className="text-xs font-semibold uppercase text-slate-800">Onwards</span>
              </div>

              {/* Features Row */}
              <div className="grid grid-cols-3 gap-2 mt-4 max-w-sm mx-auto text-[11px] md:text-xs">
                <div className="bg-black/30 backdrop-blur-sm rounded py-1 px-2 border border-white/10">
                  🏡 Premium Villas
                </div>
                <div className="bg-black/30 backdrop-blur-sm rounded py-1 px-2 border border-white/10">
                  📍 Strategic Site
                </div>
                <div className="bg-black/30 backdrop-blur-sm rounded py-1 px-2 border border-white/10">
                  ✨ 15+ Amenities
                </div>
              </div>
            </div>

            {/* Bottom Contact Strip */}
            <div className="z-10 bg-slate-950/80 backdrop-blur-md rounded-md py-2 px-4 flex flex-wrap justify-between items-center text-xs border border-white/10">
              <div className="font-bold flex items-center gap-1 text-white">
                <span className="text-amber-400 font-bold">📞</span> +91 95916 88888
              </div>
              <div className="text-white/70 text-[11px]">
                Sheshagiri Hills, Karnataka
              </div>
            </div>

            {/* GPS Map Camera Stamp Badge (as seen in user's photo) */}
            <div className="absolute bottom-2 left-2 z-20 bg-black/85 backdrop-blur-md rounded p-1.5 border border-white/10 text-[9px] text-white/90 max-w-[200px] hidden md:block">
              <div className="font-semibold text-amber-300">Sheshagirihalli, Karnataka, India 🇮🇳</div>
              <div className="text-[8px] text-white/70">Lat 12.842732° Long 77.420873°</div>
              <div className="text-[7px] text-white/50">Thursday, 07:25 PM · Mathapati OOH</div>
            </div>

            {/* Background subtle light effects */}
            <div className="absolute -top-10 -right-10 w-48 h-48 bg-cyan-500/20 rounded-full blur-3xl" />
            <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl" />
          </div>
        );

      case 'malabar-gold-diamonds':
        return (
          <div className="relative w-full h-full bg-gradient-to-br from-[#6b0819] via-[#4d0410] to-[#260106] text-white p-5 flex flex-col justify-between overflow-hidden select-none">
            {/* Top Brand Header */}
            <div className="flex justify-between items-center z-10">
              <div className="bg-[#b31433] text-amber-300 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider border border-amber-300/30">
                The Responsible Jeweller
              </div>
              <div className="text-center">
                <div className="w-8 h-8 rounded-full border-2 border-amber-300 mx-auto flex items-center justify-center font-serif text-base font-bold text-amber-300">
                  M
                </div>
                <div className="text-xs md:text-sm font-extrabold tracking-widest text-amber-200 mt-0.5">
                  MALABAR
                </div>
                <div className="text-[8px] text-amber-100/80 tracking-widest uppercase">
                  Gold & Diamonds
                </div>
              </div>
              <div className="text-[10px] text-amber-200/80 font-serif italic hidden sm:block">
                Celebrate the beauty of life
              </div>
            </div>

            {/* Kannada brand line */}
            <div className="text-center z-10 mt-1">
              <span className="text-xs text-amber-200/90 font-medium">ಮಲಬಾರ್ ಗೋಲ್ಡ್ & ಡೈಮಂಡ್ಸ್</span>
            </div>

            {/* Center Offer Typography */}
            <div className="my-auto z-10 text-center">
              <h4 className="text-xl md:text-3xl font-serif text-amber-100 drop-shadow">
                This Ashada, bring home <span className="text-amber-400 italic font-semibold">Prosperity</span>
              </h4>

              {/* Offer Disc */}
              <div className="flex justify-center items-center gap-4 mt-3">
                <div className="bg-amber-400/10 border-2 border-amber-400/50 rounded-full p-3 w-28 h-28 flex flex-col items-center justify-center shadow-lg">
                  <span className="text-[10px] uppercase text-amber-200 font-bold">Up to</span>
                  <span className="text-2xl font-black text-amber-300 leading-none">30%</span>
                  <span className="text-[9px] uppercase text-white/90 font-medium text-center leading-tight mt-0.5">
                    OFF On Making Charges
                  </span>
                </div>
                <div className="bg-amber-400/10 border-2 border-amber-400/50 rounded-full p-3 w-28 h-28 flex flex-col items-center justify-center shadow-lg">
                  <span className="text-[10px] uppercase text-amber-200 font-bold">Up to</span>
                  <span className="text-2xl font-black text-amber-300 leading-none">30%</span>
                  <span className="text-[9px] uppercase text-white/90 font-medium text-center leading-tight mt-0.5">
                    OFF On Diamond Value
                  </span>
                </div>
              </div>
            </div>

            {/* Bottom Contact */}
            <div className="z-10 bg-black/60 backdrop-blur-md rounded-md py-1.5 px-3 flex justify-between items-center text-[10px] md:text-xs border border-amber-400/20">
              <div className="font-bold text-amber-300 flex items-center gap-1">
                📞 09562 916 916
              </div>
              <div className="text-white/80 uppercase tracking-wider text-[9px]">
                Over 425 Showrooms Across 14 Countries
              </div>
            </div>

            {/* Gold ornaments glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          </div>
        );

      case 'sbi-festive-campaign':
        return (
          <div className="relative w-full h-full bg-gradient-to-r from-[#171b54] via-[#241349] to-[#3a0b59] text-white p-5 flex flex-col justify-between overflow-hidden select-none">
            {/* Top Bar */}
            <div className="flex justify-between items-start z-10">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-cyan-400 flex items-center justify-center font-bold text-blue-950 text-xs">
                  SBI
                </div>
                <div>
                  <div className="font-extrabold text-sm md:text-base tracking-wider text-white">SBI</div>
                  <div className="text-[9px] text-cyan-200">The banker to every Indian</div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs font-semibold text-amber-300">STATE BANK OF INDIA</div>
                <div className="text-[9px] text-white/70">ಭಾರತದ ರಾಜ್ಯ ಬ್ಯಾಂಕ್</div>
              </div>
            </div>

            {/* Center Kannada and Festive Badges */}
            <div className="my-auto z-10 text-center">
              <div className="inline-block bg-amber-500 text-slate-950 font-black text-xs md:text-sm px-3 py-1 rounded-full uppercase mb-2">
                ದೀಪಾವಳಿ ಹಬ್ಬದ ವಿಶೇಷ ಯೋಜನೆ (Diwali Festive Offer)
              </div>
              <h4 className="text-xl md:text-3xl font-extrabold text-white tracking-wide font-heading">
                ಪ್ರತಿ ಸಂಭ್ರಮಕ್ಕಾಗಿ ಚಿನ್ನದಂತ ಪರಿಹಾರ
              </h4>
              <p className="text-xs md:text-sm text-cyan-200 mt-1">
                ಚಿನ್ನದ ಸಾಲ | ಗೃಹ ಸಾಲ | ಕಾರು ಸಾಲ (Gold Loan · Home Loan · Auto Loan)
              </p>

              {/* Key terms bullet chips */}
              <div className="flex flex-wrap justify-center gap-2 mt-4 text-[11px]">
                <span className="bg-white/10 px-2.5 py-1 rounded border border-white/20">
                  ✓ ಅತಿ ಕಡಿಮೆ ಬಡ್ಡಿದರಗಳು (Lowest Interest)
                </span>
                <span className="bg-white/10 px-2.5 py-1 rounded border border-white/20">
                  ✓ ಶೀಘ್ರ ವಿತರಣೆ (Instant Approval)
                </span>
                <span className="bg-white/10 px-2.5 py-1 rounded border border-white/20">
                  ✓ 100% ಪಾರದರ್ಶಕತೆ (100% Transparent)
                </span>
              </div>
            </div>

            {/* Footer Toll Free */}
            <div className="z-10 bg-blue-950/80 backdrop-blur-md rounded py-2 px-4 flex justify-between items-center text-xs border border-cyan-400/20">
              <div className="font-semibold text-cyan-300">
                📞 1800 1234 | 1800 425 3800 (Toll Free)
              </div>
              <div className="text-white/80 text-[11px]">
                www.sbi.co.in
              </div>
            </div>
          </div>
        );

      case 'nischitha-properties':
      default:
        return (
          <div className="relative w-full h-full bg-gradient-to-b from-[#0a458c] via-[#09356d] to-[#041d40] text-white p-5 flex flex-col justify-between overflow-hidden select-none">
            {/* Header */}
            <div className="flex justify-between items-start z-10">
              <div>
                <div className="font-black text-sm md:text-base tracking-wider text-white flex items-center gap-1.5">
                  <span className="text-cyan-300">NISCHITHA</span> PROPERTIES
                </div>
                <div className="text-[9px] text-cyan-200">More Than Just Estates</div>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-amber-300 font-semibold uppercase">Jai Dhwama Group</div>
                <div className="bg-red-600 text-white font-black text-[9px] px-2 py-0.5 rounded-full inline-block mt-0.5">
                  BMRDA APPROVED ✓
                </div>
              </div>
            </div>

            {/* Center Content */}
            <div className="my-auto z-10 text-center">
              <h4 className="text-xl md:text-3xl font-black text-amber-300 tracking-tight font-heading">
                PREMIUM BMRDA PLOTS
              </h4>
              <p className="text-xs md:text-sm text-white/90 font-medium mt-1">
                📍 Near Doddaballapura Highway, Future 900ft IRR Road
              </p>

              {/* Price Banner */}
              <div className="mt-3 bg-amber-400 text-blue-950 font-black text-base md:text-xl py-1 px-4 rounded-md inline-block shadow-lg">
                STARTING FROM ₹45.6 LAKHS*
              </div>

              <div className="text-cyan-200 text-xs mt-2 font-semibold">
                BANK LOAN AVAILABLE · IMMEDIATE REGISTRATION
              </div>
            </div>

            {/* Bottom Contact */}
            <div className="z-10 bg-slate-950/80 backdrop-blur-md rounded py-2 px-4 flex justify-between items-center text-xs border border-white/10">
              <div className="font-bold text-white flex items-center gap-1">
                <span className="text-emerald-400">🟢 WhatsApp/Call:</span> 9164 00 7001
              </div>
              <div className="text-amber-300 text-[11px] font-semibold">
                Mathapati Prime OOH Site
              </div>
            </div>
          </div>
        );
    }
  };

  if (!showFrame) {
    return <div className={`w-full h-full ${className}`}>{renderContent()}</div>;
  }

  return (
    <div className={`relative flex flex-col items-center ${className}`}>
      {/* Overhead High-Wattage Floodlight Fixtures */}
      <div className="w-[92%] flex justify-around mb-1 z-20">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="flex flex-col items-center">
            {/* Spot Arm */}
            <div className="w-0.5 h-3 bg-zinc-500" />
            {/* Spot Head */}
            <div
              className={`w-4 h-2 rounded-t-sm ${
                isNight ? 'bg-amber-100 shadow-[0_0_12px_rgba(251,191,36,0.9)]' : 'bg-zinc-700'
              }`}
            />
            {/* Cone of Light in Night Mode */}
            {isNight && (
              <div
                className="w-12 h-16 bg-gradient-to-b from-amber-200/40 via-amber-200/10 to-transparent pointer-events-none -mt-0.5 blur-[2px]"
                style={{
                  clipPath: 'polygon(35% 0%, 65% 0%, 100% 100%, 0% 100%)'
                }}
              />
            )}
          </div>
        ))}
      </div>

      {/* Billboard Canvas Frame */}
      <div
        className={`relative w-full aspect-[16/10] rounded-sm overflow-hidden border-4 ${
          isNight
            ? 'border-zinc-800 shadow-[0_20px_50px_rgba(0,0,0,0.9),0_0_40px_rgba(212,175,55,0.2)]'
            : 'border-zinc-700 shadow-2xl'
        }`}
      >
        {renderContent()}

        {/* Gloss / Reflection Sweep */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none" />
      </div>

      {/* Steel Lattice Monolith / Gantry Pillar Support */}
      <div className="w-6 md:w-8 h-10 md:h-14 bg-gradient-to-r from-zinc-700 via-zinc-600 to-zinc-800 flex items-center justify-center shadow-lg border-x border-zinc-600">
        <div className="w-full h-full opacity-30 flex flex-col justify-around">
          <div className="h-0.5 bg-zinc-950" />
          <div className="h-0.5 bg-zinc-950" />
          <div className="h-0.5 bg-zinc-950" />
        </div>
      </div>

      {/* Concrete Ground Anchor Footing */}
      <div className="w-16 md:w-20 h-2.5 bg-zinc-800 rounded-t border-t border-zinc-600" />
    </div>
  );
};

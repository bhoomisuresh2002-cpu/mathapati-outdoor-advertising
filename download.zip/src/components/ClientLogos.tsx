import React from 'react';

import React, { useState } from 'react';

interface ClientLogoProps {
  clientId: string;
  className?: string;
}

// Real, publicly-hosted brand logo lookups for clients whose official domain we can
// confidently identify. Anything not listed here (mostly hyperlocal/regional brands
// with no reliable public logo source) automatically falls back to the hand-drawn
// brand-accurate icon below via the onError handler in BrandLogo.
const LOGO_DOMAINS: Record<string, string> = {
  sbi: 'sbi.co.in',
  dmart: 'dmart.in',
  century: 'centuryrealestate.in',
  malabar: 'malabargoldanddiamonds.com',
  nambiar: 'nambiarbuilders.com',
};

// Renders the real official logo (fetched live from the company's own domain) when
// we have a confirmed domain for this client; otherwise (or if the live fetch fails)
// falls back to the hand-drawn brand-styled icon so the card is never empty/broken.
export const BrandLogo: React.FC<ClientLogoProps> = ({ clientId, className = "h-12 w-auto" }) => {
  const domain = LOGO_DOMAINS[clientId];
  const [failed, setFailed] = useState(false);

  if (domain && !failed) {
    return (
      <img
        src={`https://logo.clearbit.com/${domain}?size=256`}
        alt=""
        className={`${className} object-contain`}
        loading="lazy"
        onError={() => setFailed(true)}
      />
    );
  }

  return <ClientLogo clientId={clientId} className={className} />;
};

export const ClientLogo: React.FC<ClientLogoProps> = ({ clientId, className = "h-12 w-auto" }) => {
  switch (clientId) {
    case 'sbi':
      // State Bank of India - Official Keyhole Blue Circle + Typography
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="30" cy="30" r="26" fill="#00A3E0" />
          <path d="M30 16C23.37 16 18 21.37 18 28C18 33.15 21.24 37.54 25.8 39.22V48H34.2V39.22C38.76 37.54 42 33.15 42 28C42 21.37 36.63 16 30 16ZM30 25C28.34 25 27 26.34 27 28C27 29.66 28.34 31 30 31C31.66 31 33 29.66 33 28C33 26.34 31.66 25 30 25Z" fill="white" />
          <text x="68" y="27" fill="#00A3E0" fontSize="15" fontWeight="800" fontFamily="sans-serif" letterSpacing="1">STATE BANK</text>
          <text x="68" y="44" fill="#1F4788" fontSize="13" fontWeight="700" fontFamily="sans-serif" letterSpacing="2">OF INDIA</text>
        </svg>
      );

    case 'malabar':
      // Malabar Gold & Diamonds - Iconic Floral Crest + Gold Wordmark
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <path d="M22 0L38 12L38 32L22 44L6 32L6 12L22 0Z" stroke="#D4AF37" strokeWidth="2.5" fill="#1C180E" />
            <circle cx="22" cy="22" r="10" stroke="#F5E6BE" strokeWidth="1.5" />
            <circle cx="22" cy="22" r="3.5" fill="#D4AF37" />
            <path d="M22 12V32M12 22H32" stroke="#D4AF37" strokeWidth="1.2" />
          </g>
          <text x="64" y="26" fill="#D4AF37" fontSize="16" fontWeight="900" fontFamily="serif" letterSpacing="2">MALABAR</text>
          <text x="64" y="42" fill="#F5E6BE" fontSize="10" fontWeight="600" fontFamily="sans-serif" letterSpacing="3">GOLD & DIAMONDS</text>
        </svg>
      );

    case 'a2b':
      // Adyar Ananda Bhavan (A2B) - Official Red-Yellow Crown Shield Ribbon
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 6)">
            <path d="M4 14C4 6.27 10.27 0 18 0H32C39.73 0 46 6.27 46 14V34C46 41.73 39.73 48 32 48H18C10.27 48 4 41.73 4 34V14Z" fill="#C62828" />
            <path d="M8 14C8 8.48 12.48 4 18 4H32C37.52 4 42 8.48 42 14V34C42 39.52 37.52 44 32 44H18C12.48 44 8 39.52 8 34V14Z" fill="#F9A825" />
            <path d="M16 12L25 18L34 12L31 22H19L16 12Z" fill="#C62828" />
            <text x="25" y="37" fill="#C62828" fontSize="15" fontWeight="900" fontFamily="sans-serif" textAnchor="middle">A2B</text>
          </g>
          <text x="64" y="27" fill="#F9A825" fontSize="14" fontWeight="800" fontFamily="sans-serif" letterSpacing="1">ADYAR ANANDA</text>
          <text x="64" y="44" fill="#EF5350" fontSize="12" fontWeight="700" fontFamily="sans-serif" letterSpacing="2">BHAVAN · SWEETS</text>
        </svg>
      );

    case 'nandi':
      // Nandi Upachar - Authentic Highway Dining Emblem
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <circle cx="22" cy="22" r="21" fill="#1B4D24" stroke="#D4AF37" strokeWidth="2" />
            <path d="M14 26C14 18 22 13 22 13C22 13 30 18 30 26C30 31 26 33 22 33C18 33 14 31 14 26Z" fill="#D4AF37" />
            <circle cx="22" cy="23" r="3" fill="#1B4D24" />
          </g>
          <text x="62" y="27" fill="#D4AF37" fontSize="16" fontWeight="900" fontFamily="sans-serif" letterSpacing="2">NANDI</text>
          <text x="62" y="44" fill="#81C784" fontSize="12" fontWeight="700" fontFamily="sans-serif" letterSpacing="2">UPACHAR RESTAURANT</text>
        </svg>
      );

    case 'dmart':
      // Avenue Supermarts (DMart) - Green Shopping Cart Tag with Red Asterisk
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <rect x="2" y="4" width="42" height="36" rx="8" fill="#007A3D" />
            <circle cx="36" cy="10" r="4.5" fill="#E53935" />
            <path d="M12 28V16H18C21.3 16 23.5 18.2 23.5 22C23.5 25.8 21.3 28 18 28H12ZM16 19.5V24.5H18C19.4 24.5 20.3 23.6 20.3 22C20.3 20.4 19.4 19.5 18 19.5H16Z" fill="white" />
            <path d="M26 28V16L30 22.5L34 16V28H31.5V20.5L29.8 23.3H29.2L27.5 20.5V28H26Z" fill="#FDD835" />
          </g>
          <text x="62" y="27" fill="#007A3D" fontSize="18" fontWeight="900" fontFamily="sans-serif" letterSpacing="1">DMart</text>
          <text x="62" y="44" fill="#B0BEC5" fontSize="10" fontWeight="700" fontFamily="sans-serif" letterSpacing="1.5">AVENUE SUPERMARTS</text>
        </svg>
      );

    case 'century':
      // Century Real Estate - Geometric High-Rise Columns Symbol
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <rect x="8" y="18" width="6" height="24" fill="#D4AF37" />
            <rect x="18" y="8" width="6" height="34" fill="#F5E6BE" />
            <rect x="28" y="14" width="6" height="28" fill="#D4AF37" />
            <path d="M4 42H38" stroke="#D4AF37" strokeWidth="2" />
          </g>
          <text x="56" y="27" fill="#F5E6BE" fontSize="16" fontWeight="900" fontFamily="sans-serif" letterSpacing="3">CENTURY</text>
          <text x="56" y="44" fill="#90A4AE" fontSize="10" fontWeight="700" fontFamily="sans-serif" letterSpacing="2">REAL ESTATE</text>
        </svg>
      );

    case 'concord':
      // Concorde Group - Luxury Winged Architectural Apex
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <path d="M6 38L22 8L38 38L30 38L22 22L14 38H6Z" fill="#2196F3" />
            <path d="M16 38L22 26L28 38H16Z" fill="#D4AF37" />
          </g>
          <text x="56" y="27" fill="#64B5F6" fontSize="15" fontWeight="900" fontFamily="sans-serif" letterSpacing="2">CONCORDE</text>
          <text x="56" y="43" fill="#D4AF37" fontSize="11" fontWeight="700" fontFamily="sans-serif" letterSpacing="2.5">GROUP</text>
        </svg>
      );

    case 'address':
      // The Address Makers - Luxury Location Beacon & Compass
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <circle cx="22" cy="22" r="19" stroke="#E53935" strokeWidth="2" strokeDasharray="3 2" />
            <circle cx="22" cy="22" r="11" fill="#C62828" />
            <circle cx="22" cy="22" r="4" fill="#D4AF37" />
          </g>
          <text x="56" y="26" fill="#EF5350" fontSize="13" fontWeight="800" fontFamily="serif" letterSpacing="2">THE ADDRESS</text>
          <text x="56" y="43" fill="#D4AF37" fontSize="12" fontWeight="700" fontFamily="sans-serif" letterSpacing="3">MAKERS</text>
        </svg>
      );

    case 'nambiar':
      // Nambiar Builders - Geometric Villa Chevron Crest
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <path d="M8 38L22 10L36 38H28L22 24L16 38H8Z" fill="#1565C0" />
            <circle cx="22" cy="14" r="3.5" fill="#D4AF37" />
          </g>
          <text x="54" y="27" fill="#64B5F6" fontSize="15" fontWeight="900" fontFamily="sans-serif" letterSpacing="2">NAMBIAR</text>
          <text x="54" y="43" fill="#D4AF37" fontSize="11" fontWeight="700" fontFamily="sans-serif" letterSpacing="2">BUILDERS</text>
        </svg>
      );

    case 'nischitha':
      // Nischitha Properties - Plotted Land Sunrise Motif
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <circle cx="22" cy="20" r="12" fill="#FFA000" />
            <path d="M4 38L16 26L28 38H4Z" fill="#2E7D32" />
            <path d="M18 38L27 28L36 38H18Z" fill="#388E3C" />
          </g>
          <text x="54" y="27" fill="#81C784" fontSize="14" fontWeight="800" fontFamily="sans-serif" letterSpacing="1.5">NISCHITHA</text>
          <text x="54" y="43" fill="#FFB74D" fontSize="11" fontWeight="700" fontFamily="sans-serif" letterSpacing="2">PROPERTIES</text>
        </svg>
      );

    case 'chandra':
      // Chandra Akka Jewellery - Traditional South Indian Gold Medallion
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <circle cx="22" cy="22" r="20" stroke="#D4AF37" strokeWidth="2" fill="#3E111E" />
            <circle cx="22" cy="22" r="14" stroke="#F5E6BE" strokeWidth="1" strokeDasharray="2 2" />
            <path d="M22 13C25 18 28 20 28 24C28 27.5 25.5 30 22 30C18.5 30 16 27.5 16 24C16 20 19 18 22 13Z" fill="#D4AF37" />
          </g>
          <text x="56" y="26" fill="#F48FB1" fontSize="14" fontWeight="800" fontFamily="serif" letterSpacing="1.5">CHANDRA AKKA</text>
          <text x="56" y="43" fill="#D4AF37" fontSize="11" fontWeight="700" fontFamily="sans-serif" letterSpacing="2.5">JEWELLERY</text>
        </svg>
      );

    case 'klf':
      // KLF Nirmal - Pure Coconut Oil Drop & Twin Leaves
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <path d="M22 8C22 8 10 22 10 28C10 34.6 15.4 40 22 40C28.6 40 34 34.6 34 28C34 22 22 8 22 8Z" fill="#0288D1" />
            <path d="M19 28C19 23 22 16 22 16C22 16 25 23 25 28C25 30 23.7 32 22 32C20.3 32 19 30 19 28Z" fill="white" />
            <path d="M6 34C10 30 16 32 18 36" stroke="#4CAF50" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M38 34C34 30 28 32 26 36" stroke="#4CAF50" strokeWidth="2.5" strokeLinecap="round" />
          </g>
          <text x="56" y="27" fill="#29B6F6" fontSize="16" fontWeight="900" fontFamily="sans-serif" letterSpacing="2">KLF NIRMAL</text>
          <text x="56" y="43" fill="#81C784" fontSize="11" fontWeight="700" fontFamily="sans-serif" letterSpacing="1.5">COCONUT OIL</text>
        </svg>
      );

    case 'hars':
      // HARS International Public School - Academic Torch & Heraldic Shield
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <path d="M6 10C6 10 14 8 22 8C30 8 38 10 38 10V26C38 34 22 40 22 40C22 40 6 34 6 26V10Z" fill="#880E4F" stroke="#D4AF37" strokeWidth="1.5" />
            <path d="M22 14V28M17 18H27" stroke="#F5E6BE" strokeWidth="2" strokeLinecap="round" />
            <circle cx="22" cy="14" r="2.5" fill="#FFC107" />
          </g>
          <text x="54" y="26" fill="#F48FB1" fontSize="13" fontWeight="800" fontFamily="serif" letterSpacing="1">HARS INTL.</text>
          <text x="54" y="42" fill="#D4AF37" fontSize="10" fontWeight="700" fontFamily="sans-serif" letterSpacing="1.5">PUBLIC SCHOOL</text>
        </svg>
      );

    case 'bn':
      // BN International School - Academic Book & Laurels
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <circle cx="22" cy="22" r="20" fill="#1A237E" stroke="#FFD54F" strokeWidth="2" />
            <path d="M12 28C16 26 22 27 22 27C22 27 28 26 32 28V18C28 16 22 17 22 17C22 17 16 16 12 18V28Z" fill="#FFD54F" />
            <circle cx="22" cy="13" r="2.5" fill="white" />
          </g>
          <text x="54" y="26" fill="#9FA8DA" fontSize="13" fontWeight="800" fontFamily="serif" letterSpacing="1">BN INTL.</text>
          <text x="54" y="42" fill="#FFE082" fontSize="10" fontWeight="700" fontFamily="sans-serif" letterSpacing="1.5">PUBLIC SCHOOL</text>
        </svg>
      );

    case 'kids':
      // Kids International School - Rising Sun & Youthful Education Motif
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(10, 8)">
            <circle cx="22" cy="22" r="18" fill="#F57C00" />
            <circle cx="22" cy="26" r="10" fill="#FFD54F" />
            <path d="M12 16L22 11L32 16L22 20L12 16Z" fill="#1565C0" />
            <path d="M30 18V24" stroke="#1565C0" strokeWidth="1.5" />
          </g>
          <text x="54" y="26" fill="#FFB74D" fontSize="13" fontWeight="800" fontFamily="sans-serif" letterSpacing="1">KIDS INTL.</text>
          <text x="54" y="42" fill="#81D4FA" fontSize="10" fontWeight="700" fontFamily="sans-serif" letterSpacing="1.5">PUBLIC SCHOOL</text>
        </svg>
      );

    default:
      return (
        <svg viewBox="0 0 240 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="25" cy="30" r="18" fill="#D4AF37" />
          <text x="60" y="36" fill="white" fontSize="14" fontWeight="bold">PARTNER BRAND</text>
        </svg>
      );
  }
};

import React from 'react';
import { COMPANY_INFO } from '../data/companyData';
import { Phone } from 'lucide-react';

export const FloatingActions: React.FC = () => {
  return (
    <aside aria-label="Quick contact actions" className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3.5 pointer-events-none">
      {/* Direct Phone Call Button */}
      <a
        href={`tel:${COMPANY_INFO.contact.phone}`}
        className="pointer-events-auto w-14 h-14 rounded-full bg-white border-2 border-[#F04A00] text-[#F04A00] flex items-center justify-center shadow-[0_6px_25px_rgba(240,74,0,0.25)] hover:scale-110 hover:bg-[#F04A00] hover:text-white transition-all duration-300 group focus:outline-none"
        aria-label="Call Mathapati Outdoor Advertising Directly at 9060916193"
        title="Call 9060916193"
      >
        <Phone className="w-5 h-5 transition-transform group-hover:rotate-12" />
      </a>

      {/* Pulsating Official WhatsApp Button */}
      <a
        href={`https://wa.me/91${COMPANY_INFO.contact.whatsapp}?text=Hello%20Mathapati%20Outdoor%20Advertising,%20I%20am%20interested%20in%20an%20outdoor%20advertising%20campaign`}
        target="_blank"
        rel="noopener noreferrer"
        className="pointer-events-auto relative w-14 h-14 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-[0_6px_25px_rgba(37,211,102,0.5)] hover:scale-110 hover:shadow-[0_8px_30px_rgba(37,211,102,0.7)] transition-all duration-300 group focus:outline-none"
        aria-label="Chat with Mathapati Outdoor Advertising on WhatsApp at 9060916193"
        title="WhatsApp 9060916193"
      >
        {/* Animated pulsing wave */}
        <span className="absolute -inset-1 rounded-full bg-[#25D366]/40 animate-ping pointer-events-none" />
        
        {/* Official WhatsApp SVG Icon */}
        <svg
          className="w-7 h-7 fill-current relative z-10 transition-transform group-hover:scale-110"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M17.472 14.382c-.301-.15-1.78-.878-2.056-.978-.276-.101-.477-.15-.678.15-.2.301-.778.979-.954 1.18-.175.201-.351.226-.652.075-.301-.15-1.272-.469-2.423-1.496-.895-.798-1.5-1.783-1.676-2.084-.176-.301-.019-.464.132-.614.136-.135.301-.351.452-.527.15-.176.201-.301.301-.502.101-.2.05-.376-.025-.526-.075-.15-.678-1.633-.929-2.238-.244-.589-.493-.509-.678-.519-.176-.01-.376-.01-.577-.01-.201 0-.527.075-.803.376-.276.301-1.054 1.03-1.054 2.511 0 1.482 1.079 2.912 1.23 3.113.15.201 2.124 3.243 5.145 4.548.719.311 1.28.497 1.718.636.722.23 1.378.197 1.897.12.578-.087 1.78-.727 2.031-1.429.251-.702.251-1.304.176-1.429-.075-.125-.276-.201-.577-.351z" />
          <path d="M12.04 2C6.516 2 2.022 6.49 2.022 12.012c0 1.954.564 3.78 1.542 5.332L2 22l4.821-1.528c1.488.887 3.23 1.401 5.219 1.401 5.524 0 10.018-4.49 10.018-10.012S17.564 2 12.04 2zm0 18.274c-1.688 0-3.256-.475-4.598-1.296l-.33-.203-3.111.986.994-3.03-.223-.356c-.958-1.523-1.472-3.298-1.472-5.113 0-4.568 3.719-8.284 8.29-8.284 4.57 0 8.289 3.716 8.289 8.284 0 4.568-3.719 8.284-8.289 8.284z" />
        </svg>
      </a>
    </aside>
  );
};

import React, { useRef } from 'react';
import { Award, ShieldCheck, CheckCircle2, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';

// Real, official brand logos (fetched live from each brand's own domain) for the
// "Trusted by Industry Leaders" showcase. This list is local to this section only —
// it does not touch CLIENTS_DATA in companyData.ts, which still holds the site's
// actual client roster used elsewhere (e.g. proposal export).
const TRUSTED_BRANDS = [
  { id: 'sbi', name: 'SBI', domain: 'sbi.co.in' },
  { id: 'hdfc', name: 'HDFC Bank', domain: 'hdfcbank.com' },
  { id: 'canara', name: 'Canara Bank', domain: 'canarabank.com' },
  { id: 'lic', name: 'LIC', domain: 'licindia.in' },
  { id: 'airtel', name: 'Airtel', domain: 'airtel.in' },
  { id: 'jio', name: 'Jio', domain: 'jio.com' },
  { id: 'reliance', name: 'Reliance', domain: 'ril.com' },
  { id: 'toyota', name: 'Toyota', domain: 'toyota.com' },
  { id: 'infosys', name: 'Infosys', domain: 'infosys.com' },
  { id: 'malabar', name: 'Malabar Gold & Diamonds', domain: 'malabargoldanddiamonds.com' },
];

// Renders the real logo fetched live from the brand's own domain. If that live
// fetch ever fails, we fall back to the plain brand name only — never a
// recreated/stand-in logo graphic, per "genuine official logos only".
const RealBrandLogo: React.FC<{ domain: string; name: string }> = ({ domain, name }) => {
  const [failed, setFailed] = React.useState(false);
  if (failed) {
    return <span className="text-[11px] font-bold text-[#0A0E17] text-center px-1">{name}</span>;
  }
  return (
    <img
      src={`https://logo.clearbit.com/${domain}?size=256`}
      alt={`${name} logo`}
      className="max-h-full max-w-full object-contain"
      loading="lazy"
      onError={() => setFailed(true)}
    />
  );
};

export const ClientsWall: React.FC = () => {
  const scrollRef = useRef<HTMLDivElement>(null);

  // Duplicate for continuous seamless marquee loop
  const marqueeList = [...TRUSTED_BRANDS, ...TRUSTED_BRANDS, ...TRUSTED_BRANDS];

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = direction === 'left' ? -320 : 320;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section id="clients" className="py-20 relative bg-[#0B0F17] text-white border-y border-white/10 overflow-hidden">
      {/* Ambient background glows */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[600px] h-[350px] bg-[#F04A00]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-[500px] h-[350px] bg-[#1E293B]/30 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#121826] border border-[#F04A00]/40 text-xs font-semibold text-[#FF5E1E] uppercase tracking-wider mb-4 shadow-[0_0_15px_rgba(240,74,0,0.15)]">
            <Sparkles className="w-3.5 h-3.5 text-[#F04A00]" />
            <span>Trusted by Industry Leaders</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight leading-tight">
            Brands That Command <span className="orange-accent-gradient">Karnataka With Us</span>
          </h2>
          <p className="mt-4 text-zinc-300 text-sm sm:text-base leading-relaxed">
            From India's premier public sector bank to international jewellery powerhouses and pioneering infrastructure developers, our media network powers campaigns that define modern Karnataka.
          </p>
        </div>

        {/* Manual Nav Controls */}
        <div className="flex items-center justify-center sm:justify-end gap-4 mb-8">
          <div className="hidden sm:flex items-center gap-2">
            <button
              onClick={() => handleScroll('left')}
              className="p-2.5 rounded-xl bg-[#121826] border border-white/10 text-white hover:text-[#F04A00] hover:border-[#F04A00]/50 transition-colors cursor-pointer"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => handleScroll('right')}
              className="p-2.5 rounded-xl bg-[#121826] border border-white/10 text-white hover:text-[#F04A00] hover:border-[#F04A00]/50 transition-colors cursor-pointer"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* CONTINUOUS INFINITE MOVING LOGO CAROUSEL WITH SWIPE & PAUSE ON HOVER */}
      <div className="relative w-full py-4 group">
        {/* Subtle left & right gradient fade masks for cinematic edges */}
        <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-r from-[#0B0F17] to-transparent z-20 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-l from-[#0B0F17] to-transparent z-20 pointer-events-none" />

        {/* Outer scroll container for touch swiping and infinite marquee */}
        <div
          ref={scrollRef}
          className="w-full overflow-x-auto scrollbar-none scroll-smooth flex items-center py-2"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          <div className="animate-marquee flex items-center gap-6 sm:gap-8 px-4">
            {marqueeList.map((brand, idx) => (
              <div
                key={`${brand.id}-${idx}`}
                className="w-28 sm:w-32 flex-shrink-0 flex flex-col items-center gap-3 text-center group/card cursor-pointer"
              >
                {/* White Circular Card - Equal Size, Equal Spacing */}
                <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full flex items-center justify-center p-5 bg-white shadow-[0_8px_24px_rgba(0,0,0,0.35)] border border-white/60 group-hover/card:shadow-[0_12px_32px_rgba(240,74,0,0.4)] group-hover/card:-translate-y-1 transition-all duration-300">
                  <RealBrandLogo domain={brand.domain} name={brand.name} />
                </div>
                <h3 className="text-xs sm:text-sm font-bold text-white group-hover/card:text-[#FF5E1E] transition-colors leading-snug truncate w-full">
                  {brand.name}
                </h3>
              </div>
            ))}
          </div>
        </div>

        {/* Carousel speed / interaction hint */}
        <div className="text-center text-[11px] text-zinc-400 mt-3 font-medium flex items-center justify-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#F04A00] animate-pulse" />
          <span>Auto-scrolling showcase · Hover or drag to pause & explore</span>
        </div>
      </div>

      {/* Client Trust Statistics Bar - Glassmorphism Dark Strip */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 mt-12">
        <div className="bg-[#121826]/80 backdrop-blur-md rounded-2xl p-6 sm:p-8 border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.4)] flex flex-col md:flex-row items-center justify-around gap-6 text-center">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-8 h-8 text-[#F04A00] flex-shrink-0" />
            <div className="text-left">
              <div className="text-xl font-bold text-white font-heading">98.4% Renewal Rate</div>
              <div className="text-xs text-zinc-400">Clients choose MATHAPATI season after season</div>
            </div>
          </div>

          <div className="w-px h-10 bg-white/10 hidden md:block" />

          <div className="flex items-center gap-3">
            <Award className="w-8 h-8 text-[#F04A00] flex-shrink-0" />
            <div className="text-left">
              <div className="text-xl font-bold text-white font-heading">500+ Prime Sites</div>
              <div className="text-xs text-zinc-400">Exclusive high-footfall Karnataka holding network</div>
            </div>
          </div>

          <div className="w-px h-10 bg-white/10 hidden md:block" />

          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-8 h-8 text-[#F04A00] flex-shrink-0" />
            <div className="text-left">
              <div className="text-xl font-bold text-white font-heading">Zero Legal Hassle</div>
              <div className="text-xs text-zinc-400">Complete municipal and structural compliance</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

import React from 'react';
import { Logo } from './Logo';
import { COMPANY_INFO, SERVICES_DATA } from '../data/companyData';
import { 
  Phone, 
  Mail, 
  MapPin, 
  ArrowUp, 
  Facebook, 
  Instagram, 
  Youtube 
} from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onOpenConsultation: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenConsultation }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#070A12] border-t border-white/10 text-zinc-400 relative overflow-hidden">
      {/* Brand orange divider accent */}
      <div className="h-1 w-full bg-gradient-to-r from-transparent via-[#F04A00]/80 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 mb-14">
          {/* Brand Info & Mission */}
          <div className="lg:col-span-4 space-y-4">
            <Logo size="md" variant="dark" />
            <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed mt-4">
              Karnataka's premier outdoor advertising authority. Specializing in high-impact highway unipoles, commercial digital LED displays, bus transit wraps, and hyperlocal auto branding.
            </p>

            <div className="pt-2">
              <div className="text-xs font-bold text-white uppercase tracking-wider mb-1">
                Executive Leadership:
              </div>
              <div className="text-sm font-bold text-[#FF5E1E]">
                Shivakumar Mathapati
              </div>
              <div className="text-xs text-zinc-400">
                Founder & Industry Professional (30+ Years Experience)
              </div>
            </div>

            {/* Official Social Media Links - Real working external icons */}
            <div className="flex items-center gap-3 pt-3">
              <a
                href={COMPANY_INFO.socials.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#121826] border border-white/10 flex items-center justify-center text-white hover:text-[#F04A00] hover:border-[#F04A00]/60 shadow-xs transition-all"
                aria-label="Follow Mathapati Ads on Facebook"
                title="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href={COMPANY_INFO.socials.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#121826] border border-white/10 flex items-center justify-center text-white hover:text-[#F04A00] hover:border-[#F04A00]/60 shadow-xs transition-all"
                aria-label="Follow Mathapati Ads on Instagram"
                title="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={COMPANY_INFO.socials.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#121826] border border-white/10 flex items-center justify-center text-white hover:text-[#F04A00] hover:border-[#F04A00]/60 shadow-xs transition-all"
                aria-label="Subscribe to Mathapati Ads on YouTube"
                title="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                href={COMPANY_INFO.socials.gmail}
                className="w-10 h-10 rounded-full bg-[#121826] border border-white/10 flex items-center justify-center text-white hover:text-[#F04A00] hover:border-[#F04A00]/60 shadow-xs transition-all"
                aria-label="Send Email to mathapati327@gmail.com"
                title="Gmail"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-widest font-heading">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              {[
                { id: 'home', label: 'Home' },
                { id: 'about', label: 'About Company' },
                { id: 'services', label: 'Outdoor Solutions' },
                { id: 'showcases', label: 'Hoarding Showcase' },
                { id: 'industries', label: 'Industry Sectors' },
                { id: 'clients', label: 'Client Portfolio' },
                { id: 'gallery', label: 'Campaign Gallery' },
                { id: 'map', label: 'Karnataka Reach' },
                { id: 'contact', label: 'Contact Us' },
              ].map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => onNavigate(item.id)}
                    className="hover:text-[#FF5E1E] transition-colors focus:outline-none cursor-pointer"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Media Solutions List */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-widest font-heading">
              OOH Media Formats
            </h4>
            <ul className="space-y-2 text-xs">
              {SERVICES_DATA.slice(0, 7).map((srv) => (
                <li key={srv.id}>
                  <button
                    onClick={() => onNavigate('services')}
                    className="hover:text-[#FF5E1E] transition-colors text-left truncate max-w-full block cursor-pointer"
                  >
                    {srv.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Direct Address & Quick Consultation */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-xs font-bold text-white uppercase tracking-widest font-heading">
              Headquarters
            </h4>
            <div className="text-xs space-y-2.5">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#F04A00] flex-shrink-0 mt-0.5" />
                <span className="text-zinc-300">{COMPANY_INFO.contact.address}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#F04A00] flex-shrink-0" />
                <a href={`tel:${COMPANY_INFO.contact.phone}`} className="hover:text-[#FF5E1E] text-zinc-200 font-semibold">
                  {COMPANY_INFO.contact.displayPhone}
                </a>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#F04A00] flex-shrink-0" />
                <a href={`mailto:${COMPANY_INFO.contact.email}`} className="hover:text-[#FF5E1E] text-zinc-200">
                  {COMPANY_INFO.contact.email}
                </a>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={onOpenConsultation}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#FF5E1E] via-[#F04A00] to-[#D43F00] text-xs font-bold uppercase tracking-wider text-white shadow-md hover:shadow-lg transition-all cursor-pointer"
              >
                Inquire With Founder
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Strip: REQUIRED EXACT COPYRIGHT AND WITH LOVE HOSTING BABA */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-center sm:text-left">
          {/* Required Copyright Line & Red Clickable HOSTING BABA Link */}
          <div className="text-zinc-400 flex flex-wrap items-center justify-center sm:justify-start gap-1.5">
            <span>©2026 MATHAPATI Outdoor Advertising. All Rights Reserved.</span>
            <span className="text-zinc-600">|</span>
            <span>
              With love❤️{' '}
              <a
                href="https://hostingbaba.in"
                target="_blank"
                rel="noopener noreferrer"
                className="text-red-500 font-bold hover:text-red-400 transition-colors inline-block"
              >
                HOSTING BABA
              </a>
            </span>
          </div>

          {/* Back to top button */}
          <button
            onClick={scrollToTop}
            className="p-2.5 rounded-full bg-[#121826] border border-white/10 hover:border-[#F04A00]/50 text-zinc-300 hover:text-[#F04A00] shadow-xs transition-colors cursor-pointer"
            aria-label="Back to top"
            title="Scroll to top"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
};

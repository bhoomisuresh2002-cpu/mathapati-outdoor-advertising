import React, { useState } from 'react';
import { BillboardGraphic } from './BillboardGraphic';
import { Sun, Moon, Sparkles, Navigation, Layers, Eye, ShieldCheck, MapPin } from 'lucide-react';

export const ShowcasesSection: React.FC = () => {
  // Billboard lighting toggle
  const [isNightMode, setIsNightMode] = useState(true);
  const [selectedBillboard, setSelectedBillboard] = useState('srigandha-farmvilla');

  // Bus 3D tilt state
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  // Auto branding interactive reveal slider
  const [revealPercent, setRevealPercent] = useState(65);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 20;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -20;
    setTilt({ x, y });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  return (
    <section id="showcases" className="py-20 relative bg-[#070A11] border-t border-white/10 overflow-hidden text-white">
      {/* Section-specific layered background: fine architectural grid over deep charcoal */}
      <div
        className="absolute inset-0 opacity-[0.08] pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(rgba(240,74,0,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(240,74,0,0.5) 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}
      />
      {/* Background ambient orange & blue glow */}
      <div className="absolute top-1/4 left-10 w-[700px] h-[700px] bg-[#F04A00]/10 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-10 w-[700px] h-[700px] bg-blue-600/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-24">
        
        {/* ============================================================== */}
        {/* 1. BILLBOARD SHOWCASE (Large Mockup + Day/Night Illumination) */}
        {/* ============================================================== */}
        <div className="space-y-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#161F32] border border-[#F04A00]/40 text-xs font-semibold text-[#FF5E1E] uppercase tracking-wider mb-3 shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-[#F04A00]" /> High-Impact Hoarding Mockup
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
                Billboard Showcase & <span className="orange-accent-gradient">Night Illumination</span>
              </h2>
              <p className="text-zinc-400 text-sm mt-1 max-w-2xl">
                Experience how MATHAPATI large-format billboards dominate arterial expressways with 5000K high-CRI floodlights and unmissable line-of-sight elevation.
              </p>
            </div>

            {/* Controls: Day/Night Switch & Campaign Switcher */}
            <div className="flex flex-wrap items-center gap-2">
              {/* Day / Night Button */}
              <button
                onClick={() => setIsNightMode(!isNightMode)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all duration-300 border cursor-pointer ${
                  isNightMode
                    ? 'bg-[#161F32] text-amber-300 border-amber-500/40 shadow-md shadow-amber-500/10'
                    : 'bg-[#161F32] text-zinc-300 border-white/10 hover:border-white/20'
                }`}
              >
                {isNightMode ? (
                  <>
                    <Moon className="w-4 h-4 text-amber-300 fill-amber-300" />
                    <span>Night Floodlights ON</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-4 h-4 text-amber-500" />
                    <span>Daylight View</span>
                  </>
                )}
              </button>

              {/* Hoarding Selectors */}
              <div className="flex bg-[#121826] p-1 rounded-xl border border-white/10 text-xs shadow-xs">
                <button
                  onClick={() => setSelectedBillboard('srigandha-farmvilla')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                    selectedBillboard === 'srigandha-farmvilla' ? 'bg-[#F04A00] text-white font-bold' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Sheshagirihalli FarmVilla
                </button>
                <button
                  onClick={() => setSelectedBillboard('malabar-gold-diamonds')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                    selectedBillboard === 'malabar-gold-diamonds' ? 'bg-[#F04A00] text-white font-bold' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Malabar Gold
                </button>
                <button
                  onClick={() => setSelectedBillboard('sbi-festive-campaign')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                    selectedBillboard === 'sbi-festive-campaign' ? 'bg-[#F04A00] text-white font-bold' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  SBI Festive
                </button>
                <button
                  onClick={() => setSelectedBillboard('nischitha-properties')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                    selectedBillboard === 'nischitha-properties' ? 'bg-[#F04A00] text-white font-bold' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Nischitha Plots
                </button>
              </div>
            </div>
          </div>

          {/* Interactive Billboard Canvas */}
          <div
            className={`p-6 sm:p-10 rounded-3xl transition-all duration-700 border shadow-[0_20px_50px_rgba(0,0,0,0.5)] ${
              isNightMode
                ? 'bg-gradient-to-b from-[#0B0F19] to-[#05080E] border-white/10'
                : 'bg-gradient-to-b from-[#131A2B] to-[#0C121F] border-white/10'
            }`}
          >
            <div className="max-w-4xl mx-auto">
              <BillboardGraphic
                id={selectedBillboard}
                isNight={isNightMode}
                className="w-full"
              />
            </div>

            <div className="mt-8 pt-6 border-t border-white/10 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#F04A00] flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-white">Strategic Highway Node</div>
                  <div className="text-zinc-400">Positioned along high-velocity Karnataka corridors with 300m uninterrupted line-of-sight</div>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-[#F04A00] flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-white">Engineered Structural Safety</div>
                  <div className="text-zinc-400">Wind-resistant dual-flange cantilever foundation certified for extreme weather stability</div>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <Eye className="w-4 h-4 text-[#F04A00] flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-white">Daily Commuter Exposure</div>
                  <div className="text-zinc-400">Over 250,000+ daily vehicular impressions on working weekdays and weekend getaways</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================== */}
        {/* 2. LED SECTION (Animated Glow & Dynamic Reflections) */}
        {/* ============================================================== */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-5 space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#161F32] border border-cyan-500/30 text-xs font-semibold text-cyan-400 uppercase tracking-wider shadow-xs">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              DOOH LED Network
            </div>
            <h3 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
              Vibrant Commercial LED Screen Spectaculars
            </h3>
            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
              Equipped with high-nit weatherproof IP65 digital panels, our digital outdoor screens deliver stunning 60FPS commercial broadcasts that slice through daylight glare and sparkle after dusk.
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-3 text-xs sm:text-sm text-zinc-300">
                <div className="w-2 h-2 rounded-full bg-[#F04A00]" />
                <span>6500+ Nits Daytime Brightness with Smart Ambient Dimming</span>
              </div>
              <div className="flex items-center gap-3 text-xs sm:text-sm text-zinc-300">
                <div className="w-2 h-2 rounded-full bg-[#F04A00]" />
                <span>Real-Time Programmatic Scheduling by Hour & Traffic Flow</span>
              </div>
              <div className="flex items-center gap-3 text-xs sm:text-sm text-zinc-300">
                <div className="w-2 h-2 rounded-full bg-[#F04A00]" />
                <span>Zero-Latency Creative Updates for Festive Flash Sales</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            {/* LED Screen Display Container with Ambient Reflection Glow */}
            <div className="relative group">
              {/* Outer Pulsing Neon Glow Filter */}
              <div className="absolute -inset-2 bg-gradient-to-r from-cyan-500/20 via-[#F04A00]/20 to-purple-500/20 rounded-3xl blur-xl opacity-75 group-hover:opacity-100 transition-opacity duration-700" />

              <div className="relative rounded-2xl overflow-hidden border-4 border-zinc-900 bg-black shadow-2xl">
                {/* Simulated Digital LED Display Content */}
                <div className="relative aspect-[16/9] w-full overflow-hidden flex flex-col justify-between p-6 bg-gradient-to-br from-indigo-950 via-slate-900 to-black text-white">
                  {/* Subtle LED Matrix Pixel Grid Pattern */}
                  <div
                    className="absolute inset-0 opacity-20 pointer-events-none"
                    style={{
                      backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)',
                      backgroundSize: '8px 8px'
                    }}
                  />

                  {/* Top LED Live Status */}
                  <div className="relative z-10 flex justify-between items-center text-xs">
                    <div className="flex items-center gap-2 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                      <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                      <span className="font-mono text-[10px] uppercase tracking-wider text-white/90">DOOH LIVE · 60 FPS</span>
                    </div>
                    <span className="text-[11px] font-mono text-cyan-400 bg-black/60 px-2 py-0.5 rounded">
                      Prime Vijayanagar Circle LED #01
                    </span>
                  </div>

                  {/* Center Animated Dynamic Ad Graphic */}
                  <div className="relative z-10 text-center my-auto">
                    <div className="inline-block px-3 py-1 rounded bg-[#F04A00] text-white font-extrabold text-xs uppercase tracking-widest mb-2 shadow-lg">
                      MATHAPATI DIGITAL NETWORK
                    </div>
                    <h4 className="text-2xl sm:text-4xl font-black tracking-tight text-white font-heading drop-shadow-[0_0_20px_rgba(255,255,255,0.6)]">
                      YOUR BRAND IN MOTION
                    </h4>
                    <p className="text-xs sm:text-sm text-cyan-200 mt-1 font-medium">
                      High-dwell signal wait times with guaranteed 100% optical visibility
                    </p>
                  </div>

                  {/* Bottom Ticker Strip */}
                  <div className="relative z-10 bg-black/80 backdrop-blur-md py-1.5 px-3 rounded flex justify-between items-center text-[10px] text-zinc-300 border border-white/10">
                    <span className="text-[#FF5E1E] font-semibold">Bengaluru · Mysuru · Hubballi Prime DOOH Hubs</span>
                    <span>Book Slots: 9060916193</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================== */}
        {/* 3. BUS BRANDING (3D Perspective Tilt Card) */}
        {/* ============================================================== */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7 order-2 lg:order-1">
            {/* Interactive 3D Tilt Card Wrapper */}
            <div
              className="relative p-6 sm:p-8 rounded-3xl bg-[#121826]/90 border border-white/10 cursor-pointer transition-transform duration-200 ease-out shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
              style={{
                transform: `perspective(1000px) rotateX(${tilt.y}deg) rotateY(${tilt.x}deg)`,
                transformStyle: 'preserve-3d'
              }}
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
            >
              {/* Bus Visual Simulation */}
              <div className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-950 border border-zinc-700 shadow-inner p-6 flex flex-col justify-between">
                <div className="flex justify-between items-center z-10">
                  <span className="text-xs font-mono font-bold text-amber-300 bg-black/60 px-2.5 py-1 rounded">
                    BMTC / KSRTC FLEET BUS WRAP
                  </span>
                  <span className="text-[10px] text-zinc-400">
                    Interactive 3D Tilt · Move Cursor
                  </span>
                </div>

                {/* Full Bus Side Wrap Graphics */}
                <div className="my-auto z-10 bg-gradient-to-r from-orange-500/20 via-[#F04A00]/30 to-orange-500/20 border-y-2 border-[#F04A00] p-4 rounded-lg backdrop-blur-sm">
                  <div className="text-[10px] uppercase tracking-widest text-orange-400 font-bold">
                    360° Arterial Route Mobility
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-white font-heading">
                    MATHAPATI TRANSIT ADVERTISING
                  </div>
                  <div className="text-xs text-zinc-300 mt-0.5">
                    From Kempegowda Majestic to Electronic City & Whitefield IT Corridors
                  </div>
                </div>

                {/* Bus Windows & Wheels Representation */}
                <div className="flex justify-between items-center z-10 text-[10px] text-zinc-400 pt-2 border-t border-white/10">
                  <span>Daily Transit: 80+ Kms</span>
                  <span>Passengers & Commuters: 15,000+ / Day</span>
                </div>
              </div>

              <div className="mt-4 text-center text-xs text-zinc-400 italic">
                Hover & move your mouse across the card to tilt the perspective
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 order-1 lg:order-2 space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#161F32] border border-[#F04A00]/40 text-xs font-semibold text-[#FF5E1E] uppercase tracking-wider shadow-xs">
              <Navigation className="w-3.5 h-3.5 text-[#F04A00]" /> Transit Dominance
            </div>
            <h3 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
              Moving Billboards That Reach Every City Quarter
            </h3>
            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
              Public buses are colossal moving canvases. Operating from dawn to late night, they circulate through high-density business districts, metro stations, and bustling residential neighborhoods where static hoardings may be restricted.
            </p>
            <div className="pt-2 flex flex-wrap gap-2 text-xs">
              <span className="px-3 py-1.5 rounded-lg bg-[#161F32] border border-white/10 text-zinc-300 font-medium shadow-xs">
                Full Vehicle Wrap
              </span>
              <span className="px-3 py-1.5 rounded-lg bg-[#161F32] border border-white/10 text-zinc-300 font-medium shadow-xs">
                Side Panel Banners
              </span>
              <span className="px-3 py-1.5 rounded-lg bg-[#161F32] border border-white/10 text-zinc-300 font-medium shadow-xs">
                Rear Window High-Gaze
              </span>
            </div>
          </div>
        </div>

        {/* ============================================================== */}
        {/* 4. AUTO BRANDING (Interactive Reveal Slider) */}
        {/* ============================================================== */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-5 space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#161F32] border border-[#F04A00]/40 text-xs font-semibold text-[#FF5E1E] uppercase tracking-wider shadow-xs">
              <Layers className="w-3.5 h-3.5 text-[#F04A00]" /> Hyperlocal Fleet Branding
            </div>
            <h3 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
              Auto-Rickshaw Fleet Branding & Street Penetration
            </h3>
            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
              Auto-rickshaws penetrate every market street, interior residential layout, metro station queue, and arterial road. With heavy-duty rexene printed rear hoods, your message is right at eye level for every following motorist and commuter.
            </p>

            <div className="space-y-2 text-xs text-zinc-300">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F04A00]" />
                <span>Ideal for retail launches, school admissions & healthcare clinics</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F04A00]" />
                <span>Flexible batch deployments from 100 to 1,000+ autos</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F04A00]" />
                <span>Pin-code and regional targeting across Bengaluru zones</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            {/* Interactive Reveal Component */}
            <div className="bg-[#121826]/90 p-6 sm:p-8 rounded-3xl border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)] space-y-4">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-white">Interactive Hood Reveal</span>
                <span className="text-zinc-400">Slide to compare Traffic View vs. Branded Fleet</span>
              </div>

              {/* Slider Track Container */}
              <div className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden border border-white/10 select-none">
                {/* Background Layer: Plain Traffic Auto */}
                <div
                  className="absolute inset-0 bg-cover bg-center flex items-center justify-center text-center p-6"
                  style={{
                    backgroundImage: `url('https://images.unsplash.com/photo-1564291886459-a39ad7415125?auto=format&fit=crop&w=1200&q=80')`,
                  }}
                >
                  <div className="bg-black/75 backdrop-blur-sm p-4 rounded-xl border border-white/10 max-w-sm">
                    <div className="text-xs text-zinc-400 uppercase font-semibold">Standard Commute View</div>
                    <div className="text-lg font-bold text-white mt-1">Unbranded Street Commute</div>
                    <div className="text-xs text-zinc-300 mt-1">Missed opportunity for daily vehicular impression</div>
                  </div>
                </div>

                {/* Foreground Layer: Clipped Branded View */}
                <div
                  className="absolute inset-0 bg-cover bg-center flex items-center justify-center text-center p-6 border-r-2 border-[#F04A00]"
                  style={{
                    clipPath: `polygon(0% 0%, ${revealPercent}% 0%, ${revealPercent}% 100%, 0% 100%)`,
                    backgroundImage: `url('https://images.unsplash.com/photo-1626149637281-4e227308da18?auto=format&fit=crop&w=1200&q=80')`,
                  }}
                >
                  <div className="bg-zinc-950/90 backdrop-blur-md p-4 rounded-xl border border-[#F04A00]/50 max-w-sm shadow-2xl">
                    <div className="text-xs text-orange-400 uppercase font-bold">MATHAPATI Fleet Hood</div>
                    <div className="text-lg font-extrabold text-white mt-1">Eye-Level Brand Dominance</div>
                    <div className="text-xs text-zinc-300 mt-1">Guaranteed 2 to 5 minutes dwell time in traffic jams</div>
                  </div>
                </div>

                {/* Draggable Divider Handle */}
                <div
                  className="absolute top-0 bottom-0 w-1 bg-[#F04A00] pointer-events-none"
                  style={{ left: `${revealPercent}%` }}
                >
                  <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-7 h-7 rounded-full bg-[#F04A00] text-white font-black text-xs flex items-center justify-center shadow-lg">
                    ↔
                  </div>
                </div>
              </div>

              {/* Slider Input Control */}
              <div className="pt-2">
                <input
                  type="range"
                  min="5"
                  max="95"
                  value={revealPercent}
                  onChange={(e) => setRevealPercent(Number(e.target.value))}
                  className="w-full accent-[#F04A00] cursor-pointer"
                  aria-label="Reveal slider between standard and branded auto hood"
                />
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

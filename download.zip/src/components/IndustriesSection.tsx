import React from 'react';
import { INDUSTRIES_DATA } from '../data/companyData';
import {
  Building,
  Car,
  ShoppingBag,
  Package,
  Activity,
  GraduationCap,
  Utensils,
  Briefcase,
  Film,
  Bus,
  Navigation,
  Monitor,
  Sparkles,
  ArrowUpRight
} from 'lucide-react';

export const IndustriesSection: React.FC = () => {
  const getIndustryIcon = (icon: string) => {
    switch (icon) {
      case 'Building': return <Building className="w-5 h-5 text-[#F04A00]" />;
      case 'Car': return <Car className="w-5 h-5 text-[#F04A00]" />;
      case 'ShoppingBag': return <ShoppingBag className="w-5 h-5 text-[#F04A00]" />;
      case 'Package': return <Package className="w-5 h-5 text-[#F04A00]" />;
      case 'Activity': return <Activity className="w-5 h-5 text-[#F04A00]" />;
      case 'GraduationCap': return <GraduationCap className="w-5 h-5 text-[#F04A00]" />;
      case 'Utensils': return <Utensils className="w-5 h-5 text-[#F04A00]" />;
      case 'Briefcase': return <Briefcase className="w-5 h-5 text-[#F04A00]" />;
      case 'Film': return <Film className="w-5 h-5 text-[#F04A00]" />;
      case 'Bus': return <Bus className="w-5 h-5 text-[#F04A00]" />;
      case 'Navigation': return <Navigation className="w-5 h-5 text-[#F04A00]" />;
      case 'Monitor': return <Monitor className="w-5 h-5 text-[#F04A00]" />;
      default: return <Briefcase className="w-5 h-5 text-[#F04A00]" />;
    }
  };

  return (
    <section id="industries" className="py-20 relative bg-[#0B0F19] border-t border-white/10 overflow-hidden text-white">
      {/* Background Ambient Glows */}
      <div className="absolute top-1/3 left-1/4 w-[500px] h-[500px] bg-[#F04A00]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#161F32] border border-[#F04A00]/40 text-xs font-semibold text-[#FF5E1E] uppercase tracking-wider mb-4 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#F04A00]" />
            <span>Vertical Expertise</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight leading-tight">
            Industries We <span className="orange-accent-gradient">Elevate & Champion</span>
          </h2>
          <p className="mt-4 text-zinc-400 text-sm sm:text-base leading-relaxed">
            Different sectors require distinct outdoor media choreography. From high-velocity highway gantry wayfinding to residential supermarket footfall blitzes, our campaigns are calibrated for sector-specific consumer behavior.
          </p>
        </div>

        {/* 12 Industry Cards Grid with Dark Luxury Styling */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
          {INDUSTRIES_DATA.map((ind) => (
            <div
              key={ind.id}
              className="group relative rounded-2xl overflow-hidden border border-white/10 hover:border-[#F04A00]/50 bg-[#121826]/90 shadow-[0_15px_35px_rgba(0,0,0,0.5)] hover:shadow-[0_20px_45px_-5px_rgba(240,74,0,0.25)] transition-all duration-300 hover:-translate-y-1.5 flex flex-col h-full"
            >
              {/* Card Header Image with Zoom Hover */}
              <div className="relative aspect-[16/10] w-full overflow-hidden bg-[#161F32]">
                <img
                  src={ind.image}
                  alt={`${ind.title} Outdoor Advertising`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                  loading="lazy"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F19] via-transparent to-black/30 pointer-events-none" />

                {/* Floating Badge & Icon */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-black/60 backdrop-blur-md border border-white/15 flex items-center justify-center shadow-md">
                    {getIndustryIcon(ind.icon)}
                  </div>
                  <span className="text-[10px] uppercase font-bold tracking-widest text-white bg-black/60 backdrop-blur-md border border-white/15 px-2.5 py-1 rounded-full shadow-xs">
                    Sector Focus
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3">
                  <h3 className="text-xl font-bold text-white font-heading drop-shadow-md flex items-center justify-between">
                    <span>{ind.title}</span>
                    <ArrowUpRight className="w-4 h-4 text-[#FF5E1E] opacity-0 group-hover:opacity-100 transition-opacity" />
                  </h3>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex flex-col justify-between flex-1">
                <div>
                  <p className="text-xs text-[#FF5E1E] font-bold mb-2 leading-snug">
                    "{ind.tagline}"
                  </p>

                  <p className="text-xs text-zinc-300 leading-relaxed mb-4">
                    {ind.description}
                  </p>
                </div>

                {/* Bottom Row: Sample Campaigns & Recommended Formats */}
                <div className="space-y-3 pt-3 border-t border-white/10 mt-auto">
                  <div className="bg-[#161F32] rounded-xl p-3 border border-white/10">
                    <div className="text-[11px] text-zinc-300 leading-snug">
                      <strong className="text-white font-semibold">Iconic Campaigns:</strong> {ind.sampleCampaigns}
                    </div>
                  </div>

                  <div>
                    <div className="text-[10px] text-zinc-400 uppercase tracking-wider font-bold mb-1.5">
                      Recommended Formats
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {ind.recommendedFormats.map((fmt, i) => (
                        <span
                          key={i}
                          className="text-[10px] bg-[#1E2942] text-zinc-200 px-2.5 py-1 rounded-md border border-white/10 font-medium"
                        >
                          {fmt}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

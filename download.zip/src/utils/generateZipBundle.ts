import JSZip from 'jszip';
import { COMPANY_INFO, SERVICES_DATA, INDUSTRIES_DATA, CLIENTS_DATA, GALLERY_DATA, PROCESS_STEPS, KARNATAKA_COVERAGE } from '../data/companyData';

export async function generateMathapatiWebsiteZip(): Promise<Blob> {
  const zip = new JSZip();

  // 1. Shared Navigation & Footer HTML snippets
  const headerHtml = `
  <header class="main-header">
    <div class="container header-container">
      <a href="index.html" class="logo-link">
        <div class="logo-wrap">
          <svg width="36" height="36" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="46" stroke="#52525B" stroke-width="2.5" opacity="0.4" />
            <circle cx="50" cy="50" r="43" stroke="#D4AF37" stroke-width="1.5" opacity="0.6" />
            <path d="M20 72 L36 32 L50 56 L64 32 L80 72" stroke="#4B5563" stroke-width="11" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M26 68 L48 24 L52 24 L74 68" stroke="#F97316" stroke-width="11" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M38 46 L50 62 L62 46" stroke="#EA580C" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
          <div class="logo-text">
            <span class="logo-title">MATHAPATI <span class="logo-orange">ADS</span></span>
            <span class="logo-sub">Bangalore · Since 2006</span>
          </div>
        </div>
      </a>

      <nav class="desktop-nav">
        <a href="index.html">Home</a>
        <a href="about.html">About</a>
        <a href="services.html">Services</a>
        <a href="industries.html">Industries</a>
        <a href="gallery.html">Gallery</a>
        <a href="contact.html">Contact</a>
      </nav>

      <div class="header-cta">
        <a href="tel:9060916193" class="phone-link">📞 +91 90609 16193</a>
        <a href="contact.html" class="btn-gold">Plan Campaign</a>
      </div>
    </div>
  </header>`;

  const footerHtml = `
  <footer class="main-footer">
    <div class="container footer-container">
      <div class="footer-grid">
        <div class="footer-col">
          <h3 class="footer-title">MATHAPATI ADS Bangalore</h3>
          <p class="footer-desc">Karnataka's premier outdoor advertising network since 2006. Dominating prime highway unipoles, commercial LED screens, transit bus fleets, and auto branding.</p>
          <p class="footer-founder">Founder: <strong>Shivakumar Mathapati</strong> (30+ Yrs Exp)</p>
        </div>
        <div class="footer-col">
          <h4>Navigation</h4>
          <ul class="footer-links">
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">About Company</a></li>
            <li><a href="services.html">OOH Services</a></li>
            <li><a href="industries.html">Industries</a></li>
            <li><a href="gallery.html">Campaign Gallery</a></li>
            <li><a href="contact.html">Contact Us</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Headquarters</h4>
          <p>Vijayanagar, Bengaluru, Karnataka 560040, India</p>
          <p>Phone: <a href="tel:9060916193">+91 90609 16193</a></p>
          <p>Email: <a href="mailto:mathapati327@gmail.com">mathapati327@gmail.com</a></p>
        </div>
      </div>
      <div class="footer-bottom">
        <p>©2026 MATHAPATI Outdoor Advertising. All Rights Reserved.</p>
        <p>With love❤️ <a href="https://hostingbaba.in" target="_blank" rel="noopener noreferrer" style="color: #ef4444; font-weight: 700; text-decoration: none;">HOSTING BABA</a></p>
      </div>
    </div>
  </footer>`;

  // 2. index.html
  const indexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MATHAPATI Outdoor Advertising | Prime Billboards & Transit Media Karnataka</title>
  <meta name="description" content="Official website of MATHAPATI Outdoor Advertising. Prime highway billboards, unipoles, LED displays, bus branding across Bengaluru and Karnataka since 2006.">
  <link rel="stylesheet" href="css/style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
</head>
<body class="luxury-dark">
  ${headerHtml}

  <main>
    <!-- Cinematic Hero -->
    <section class="hero-section">
      <div class="hero-backdrop"></div>
      <div class="container hero-content">
        <div class="hero-badge">Since 2006 · Vijayanagar, Bengaluru · 100+ Holdings</div>
        <h1 class="hero-heading">Outdoor Advertising That Makes Your Brand <span class="gold-gradient">Impossible to Miss</span></h1>
        <p class="hero-subtext">Dominating high-traffic highway corridors, arterial city junctions, public bus fleets, and commercial skylines across Karnataka for over 20 years.</p>
        <div class="hero-actions">
          <a href="contact.html" class="btn-gold-large">Get Free Consultation</a>
          <a href="gallery.html" class="btn-outline-large">Explore Portfolio</a>
        </div>
        <div class="metrics-grid">
          <div class="metric-card"><h3>20+</h3><p>Years Company Legacy</p></div>
          <div class="metric-card"><h3>30+</h3><p>Founder Expertise</p></div>
          <div class="metric-card"><h3>100+</h3><p>Outdoor Holdings</p></div>
          <div class="metric-card"><h3>100%</h3><p>Karnataka Reach</p></div>
        </div>
      </div>
    </section>

    <!-- Services Overview -->
    <section class="section-padding">
      <div class="container">
        <div class="section-header text-center">
          <span class="gold-badge">OOH Media Solutions</span>
          <h2>High-Impact Formats for Unrivaled Brand Recall</h2>
        </div>
        <div class="services-grid">
          ${SERVICES_DATA.slice(0, 4).map(s => `
            <div class="service-card">
              <span class="service-tag">${s.tag}</span>
              <h3>${s.title}</h3>
              <p>${s.shortDesc}</p>
              <div class="service-meta"><strong>Performance:</strong> ${s.metrics}</div>
              <a href="services.html" class="card-link">Explore Format →</a>
            </div>
          `).join('')}
        </div>
      </div>
    </section>

    <!-- Founder Spotlight -->
    <section class="founder-section">
      <div class="container">
        <div class="founder-card">
          <div class="founder-content">
            <span class="gold-badge">Founder & Industry Leader</span>
            <h2>Shivakumar Mathapati</h2>
            <p class="founder-role">30+ Years Outdoor Advertising Expertise · Vijayanagar, Bengaluru</p>
            <blockquote class="founder-quote">"${COMPANY_INFO.founder.quote}"</blockquote>
            <p class="founder-bio">${COMPANY_INFO.founder.bio}</p>
            <a href="about.html" class="btn-gold">Read Full Story</a>
          </div>
        </div>
      </div>
    </section>

    <!-- Clients Bar -->
    <section class="section-padding bg-charcoal">
      <div class="container text-center">
        <span class="gold-badge">Client Portfolio</span>
        <h2>Trusted by India's Largest Brands</h2>
        <div class="clients-pill-grid">
          ${CLIENTS_DATA.map(c => `
            <div class="client-pill"><strong>${c.name}</strong> <span>${c.category}</span></div>
          `).join('')}
        </div>
      </div>
    </section>
  </main>

  ${footerHtml}
  <script src="js/script.js"></script>
</body>
</html>`;

  // 3. about.html
  const aboutHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us | MATHAPATI Outdoor Advertising</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="luxury-dark">
  ${headerHtml}
  <main class="page-container">
    <div class="container">
      <div class="page-header text-center">
        <span class="gold-badge">Established 2006</span>
        <h1>About MATHAPATI Outdoor Advertising</h1>
        <p>Two decades of crafting unmissable physical visibility across Karnataka.</p>
      </div>

      <div class="content-block">
        <h2>Our Heritage & Leadership</h2>
        <p>Founded in 2006 in Vijayanagar, Bengaluru by industry veteran Shivakumar Mathapati (boasting over 30 years of specialized outdoor advertising experience), MATHAPATI Outdoor Advertising is recognized as one of Karnataka's most dependable and strategically positioned OOH media firms.</p>
        <p>From monolithic highway gantries on the Bengaluru-Mysuru Expressway to bustling transit bus wraps and vibrant commercial LED displays, our mission is to ensure every campaign delivers commanding visibility and indelible brand recall.</p>
      </div>

      <div class="timeline-section">
        <h2>Historical Milestones (2006 – 2026)</h2>
        <div class="timeline-grid">
          <div class="timeline-card"><h3>2006</h3><h4>Vijayanagar Inception</h4><p>Founded by Shivakumar Mathapati with a commitment to prime physical locations.</p></div>
          <div class="timeline-card"><h3>2012</h3><h4>Highway Expansion</h4><p>Secured marquee corridors connecting Bengaluru, Mysuru, and Tumakuru.</p></div>
          <div class="timeline-card"><h3>2018</h3><h4>Digital DOOH LED</h4><p>Pioneered high-nit dynamic video screens at central commercial junctions.</p></div>
          <div class="timeline-card"><h3>2022</h3><h4>Transit Network</h4><p>Expanded dedicated public bus and auto-rickshaw fleet branding operations.</p></div>
          <div class="timeline-card"><h3>2026</h3><h4>100+ Holdings</h4><p>Celebrating 20 years of unmatched authority and client trust across Karnataka.</p></div>
        </div>
      </div>
    </div>
  </main>
  ${footerHtml}
  <script src="js/script.js"></script>
</body>
</html>`;

  // 4. services.html
  const servicesHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OOH Media Solutions | MATHAPATI Outdoor Advertising</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="luxury-dark">
  ${headerHtml}
  <main class="page-container">
    <div class="container">
      <div class="page-header text-center">
        <span class="gold-badge">All 8 Advertising Formats</span>
        <h1>Outdoor Advertising Solutions</h1>
        <p>High-recall physical and digital media tailored for high-impact brand campaigns.</p>
      </div>

      <div class="services-full-list">
        ${SERVICES_DATA.map(s => `
          <div class="service-detail-card">
            <div class="service-detail-header">
              <span class="gold-badge">${s.category}</span>
              <h2>${s.title}</h2>
              <span class="metric-badge">${s.metrics}</span>
            </div>
            <p class="service-full-text">${s.fullDesc}</p>
            <h4>Key Features & Specifications:</h4>
            <ul class="features-list">
              ${s.features.map(f => `<li>✓ ${f}</li>`).join('')}
            </ul>
            <a href="contact.html?service=${encodeURIComponent(s.title)}" class="btn-gold">Book This Format</a>
          </div>
        `).join('')}
      </div>
    </div>
  </main>
  ${footerHtml}
  <script src="js/script.js"></script>
</body>
</html>`;

  // 5. industries.html
  const industriesHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Industries We Serve | MATHAPATI Outdoor Advertising</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="luxury-dark">
  ${headerHtml}
  <main class="page-container">
    <div class="container">
      <div class="page-header text-center">
        <span class="gold-badge">Vertical Expertise</span>
        <h1>Industries We Elevate</h1>
        <p>Targeted outdoor media strategies customized for industry-specific customer journeys.</p>
      </div>

      <div class="industries-grid">
        ${INDUSTRIES_DATA.map(i => `
          <div class="industry-card">
            <h2>${i.title}</h2>
            <p class="industry-tagline">"${i.tagline}"</p>
            <p>${i.description}</p>
            <div class="industry-box">
              <p><strong>Sample Campaigns:</strong> ${i.sampleCampaigns}</p>
              <p><strong>Recommended Formats:</strong> ${i.recommendedFormats.join(', ')}</p>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  </main>
  ${footerHtml}
  <script src="js/script.js"></script>
</body>
</html>`;

  // 6. gallery.html
  const galleryHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Campaign Gallery | MATHAPATI Outdoor Advertising</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="luxury-dark">
  ${headerHtml}
  <main class="page-container">
    <div class="container">
      <div class="page-header text-center">
        <span class="gold-badge">Real-World Deployments</span>
        <h1>Outdoor Portfolio & Hoardings</h1>
        <p>Active and past outdoor campaigns executed across Karnataka.</p>
      </div>

      <div class="gallery-grid">
        ${GALLERY_DATA.map(g => `
          <div class="gallery-card">
            <div class="gallery-img-wrap">
              <img src="${g.imageUrl}" alt="${g.title}" loading="lazy">
            </div>
            <div class="gallery-info">
              <span class="gold-badge">${g.category}</span>
              <h3>${g.title}</h3>
              <p class="gallery-client"><strong>Client:</strong> ${g.client}</p>
              <p class="gallery-loc">📍 ${g.location}</p>
              <p class="gallery-desc">${g.description}</p>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  </main>
  ${footerHtml}
  <script src="js/script.js"></script>
</body>
</html>`;

  // 7. contact.html
  const contactHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us | MATHAPATI Outdoor Advertising</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="luxury-dark">
  ${headerHtml}
  <main class="page-container">
    <div class="container">
      <div class="page-header text-center">
        <span class="gold-badge">Vijayanagar, Bengaluru HQ</span>
        <h1>Contact Shivakumar Mathapati</h1>
        <p>Get in touch for available site coordinates, traffic counts, and official proposals.</p>
      </div>

      <div class="contact-grid">
        <div class="contact-info-col">
          <div class="info-card">
            <h3>Head Office</h3>
            <p>Vijayanagar, Bengaluru, Karnataka 560040</p>
            <p><strong>Phone:</strong> <a href="tel:9060916193">+91 90609 16193</a></p>
            <p><strong>WhatsApp:</strong> <a href="https://wa.me/919060916193">+91 90609 16193</a></p>
            <p><strong>Email:</strong> <a href="mailto:mathapati327@gmail.com">mathapati327@gmail.com</a></p>
            <p><strong>Hours:</strong> Mon - Sat: 9:00 AM - 8:00 PM IST</p>
          </div>
        </div>

        <div class="contact-form-col">
          <form id="contactForm" action="php/contact.php" method="POST" class="contact-form">
            <h3>Send Campaign Proposal Request</h3>
            <div class="form-group">
              <label>Full Name *</label>
              <input type="text" name="name" required placeholder="Your Name">
            </div>
            <div class="form-group">
              <label>Phone Number *</label>
              <input type="tel" name="phone" required placeholder="Phone Number">
            </div>
            <div class="form-group">
              <label>Email Address</label>
              <input type="email" name="email" placeholder="Email">
            </div>
            <div class="form-group">
              <label>Company / Brand Name</label>
              <input type="text" name="company" placeholder="Company Name">
            </div>
            <div class="form-group">
              <label>Interested Service</label>
              <select name="service">
                <option value="Outdoor Billboard Advertising">Outdoor Billboard Advertising</option>
                <option value="LED Advertising">LED Digital Advertising</option>
                <option value="Bus Shelter Advertising">Bus Shelter Advertising</option>
                <option value="Bus Branding">Bus Branding & Fleet Advertising</option>
                <option value="Auto Branding">Auto-Rickshaw Branding</option>
                <option value="Property Advertising">Property & Real Estate Advertising</option>
              </select>
            </div>
            <div class="form-group">
              <label>Campaign Details & Corridors</label>
              <textarea name="message" rows="4" placeholder="Desired location, launch dates, budget..."></textarea>
            </div>
            <button type="submit" class="btn-gold-large" style="width:100%;">Submit Proposal</button>
            <div id="formFeedback" class="form-feedback"></div>
          </form>
        </div>
      </div>
    </div>
  </main>
  ${footerHtml}
  <script src="js/script.js"></script>
</body>
</html>`;

  // 8. css/style.css
  const styleCss = `
/* MATHAPATI Outdoor Advertising - Luxury Dark Gold Stylesheet */
:root {
  --bg-black: #0B0B0B;
  --bg-charcoal: #141414;
  --gold-primary: #D4AF37;
  --gold-light: #F5E6BE;
  --gold-dark: #AA820A;
  --text-white: #FFFFFF;
  --text-muted: #A1A1AA;
  --border-color: rgba(255, 255, 255, 0.1);
  --font-heading: 'Space Grotesk', sans-serif;
  --font-body: 'Plus Jakarta Sans', sans-serif;
}

* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  background-color: var(--bg-black);
  color: var(--text-white);
  font-family: var(--font-body);
  line-height: 1.6;
}

a { color: inherit; text-decoration: none; }
.container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
.text-center { text-align: center; }
.section-padding { padding: 80px 0; }
.page-container { padding: 120px 0 80px; }
.bg-charcoal { background-color: var(--bg-charcoal); }

/* Header */
.main-header {
  position: fixed;
  top: 0; left: 0; right: 0;
  z-index: 100;
  background: rgba(11, 11, 11, 0.95);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(212, 175, 55, 0.2);
  padding: 15px 0;
}
.header-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.logo-wrap { display: flex; align-items: center; gap: 12px; }
.logo-text { display: flex; flex-direction: column; }
.logo-title { font-weight: 800; font-size: 1.2rem; font-family: var(--font-heading); }
.logo-orange { color: #F97316; }
.logo-sub { font-size: 0.75rem; color: var(--gold-primary); text-transform: uppercase; letter-spacing: 2px; }
.desktop-nav a { margin: 0 12px; font-size: 0.9rem; color: var(--text-muted); transition: color 0.3s; }
.desktop-nav a:hover { color: var(--gold-primary); }
.header-cta { display: flex; align-items: center; gap: 15px; }
.phone-link { font-size: 0.85rem; color: var(--gold-primary); font-weight: 600; }

/* Buttons */
.btn-gold {
  background: linear-gradient(135deg, var(--gold-light), var(--gold-primary), var(--gold-dark));
  color: #000;
  font-weight: 700;
  font-size: 0.85rem;
  padding: 8px 18px;
  border-radius: 8px;
  text-transform: uppercase;
  letter-spacing: 1px;
  border: none;
  cursor: pointer;
  display: inline-block;
}
.btn-gold-large {
  background: linear-gradient(135deg, var(--gold-light), var(--gold-primary), var(--gold-dark));
  color: #000;
  font-weight: 800;
  font-size: 1rem;
  padding: 14px 28px;
  border-radius: 12px;
  text-transform: uppercase;
  letter-spacing: 1px;
  border: none;
  cursor: pointer;
  display: inline-block;
}
.btn-outline-large {
  border: 1px solid rgba(255,255,255,0.2);
  color: #fff;
  padding: 14px 28px;
  border-radius: 12px;
  font-size: 1rem;
  font-weight: 600;
  display: inline-block;
}

/* Badges */
.gold-badge {
  display: inline-block;
  background: rgba(212, 175, 55, 0.1);
  border: 1px solid rgba(212, 175, 55, 0.4);
  color: var(--gold-primary);
  font-size: 0.75rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  padding: 4px 12px;
  border-radius: 20px;
  margin-bottom: 12px;
}
.gold-gradient {
  background: linear-gradient(135deg, #FFF, var(--gold-primary));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

/* Hero */
.hero-section {
  position: relative;
  min-height: 90vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 140px 0 80px;
  text-align: center;
  background: radial-gradient(circle at center, rgba(212, 175, 55, 0.08) 0%, transparent 70%);
}
.hero-heading {
  font-family: var(--font-heading);
  font-size: 3.2rem;
  font-weight: 800;
  line-height: 1.15;
  margin: 20px 0;
}
.hero-subtext {
  font-size: 1.15rem;
  color: var(--text-muted);
  max-width: 750px;
  margin: 0 auto 35px;
}
.hero-actions { display: flex; gap: 15px; justify-content: center; margin-bottom: 60px; }

/* Metrics */
.metrics-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  max-width: 900px;
  margin: 0 auto;
}
.metric-card {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid var(--border-color);
  padding: 20px;
  border-radius: 12px;
}
.metric-card h3 { font-size: 2.2rem; color: var(--gold-primary); font-family: var(--font-heading); }
.metric-card p { font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; }

/* Services Grid */
.services-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 24px; margin-top: 40px; }
.service-card {
  background: rgba(255,255,255,0.02);
  border: 1px solid var(--border-color);
  border-radius: 16px;
  padding: 28px;
  transition: transform 0.3s, border-color 0.3s;
}
.service-card:hover { transform: translateY(-5px); border-color: var(--gold-primary); }
.service-card h3 { margin: 12px 0; font-size: 1.25rem; font-family: var(--font-heading); }
.service-card p { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 16px; }
.service-tag { font-size: 0.7rem; text-transform: uppercase; background: #222; padding: 3px 8px; border-radius: 4px; color: var(--gold-primary); }

/* Founder Card */
.founder-section { padding: 60px 0; }
.founder-card {
  background: rgba(20, 20, 20, 0.8);
  border: 1px solid rgba(212, 175, 55, 0.3);
  border-radius: 24px;
  padding: 40px;
  max-width: 900px;
  margin: 0 auto;
}
.founder-quote { font-style: italic; color: var(--gold-light); margin: 20px 0; border-left: 3px solid var(--gold-primary); padding-left: 15px; }

/* Clients Bar */
.clients-pill-grid { display: flex; flex-wrap: wrap; gap: 12px; justify-content: center; margin-top: 30px; }
.client-pill {
  background: rgba(255,255,255,0.04);
  border: 1px solid var(--border-color);
  padding: 10px 18px;
  border-radius: 30px;
  font-size: 0.85rem;
}
.client-pill span { color: var(--text-muted); margin-left: 6px; font-size: 0.75rem; }

/* Footer */
.main-footer { background: #070707; border-top: 1px solid rgba(212,175,55,0.2); padding: 60px 0 30px; margin-top: 80px; }
.footer-grid { display: grid; grid-template-columns: 2fr 1fr 1.5fr; gap: 40px; margin-bottom: 40px; }
.footer-title { font-family: var(--font-heading); color: #fff; margin-bottom: 12px; }
.footer-desc { font-size: 0.85rem; color: var(--text-muted); line-height: 1.6; }
.footer-links { list-style: none; }
.footer-links li { margin-bottom: 8px; font-size: 0.85rem; color: var(--text-muted); }
.footer-bottom { border-top: 1px solid rgba(255,255,255,0.08); padding-top: 25px; display: flex; justify-content: space-between; font-size: 0.85rem; color: var(--text-muted); }

/* Forms */
.contact-grid { display: grid; grid-template-columns: 1fr 1.5fr; gap: 40px; margin-top: 40px; }
.form-group { margin-bottom: 16px; }
.form-group label { display: block; font-size: 0.8rem; margin-bottom: 6px; color: var(--text-muted); }
.form-group input, .form-group select, .form-group textarea {
  width: 100%;
  background: #181818;
  border: 1px solid var(--border-color);
  padding: 12px;
  border-radius: 8px;
  color: #fff;
  font-family: inherit;
}

@media (max-width: 768px) {
  .hero-heading { font-size: 2.2rem; }
  .metrics-grid { grid-template-columns: repeat(2, 1fr); }
  .desktop-nav { display: none; }
  .footer-grid, .contact-grid { grid-template-columns: 1fr; }
  .footer-bottom { flex-direction: column; gap: 10px; text-align: center; }
}
`;

  // 9. js/script.js
  const scriptJs = `
// MATHAPATI Outdoor Advertising - Standalone Script
document.addEventListener('DOMContentLoaded', () => {
  // Contact Form AJAX Handler
  const contactForm = document.getElementById('contactForm');
  const formFeedback = document.getElementById('formFeedback');

  if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(contactForm);
      const submitBtn = contactForm.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.textContent = 'Submitting...';

      try {
        const response = await fetch('php/contact.php', {
          method: 'POST',
          body: formData
        });
        const result = await response.json();

        if (result.status === 'success') {
          formFeedback.innerHTML = '<div style="color:#10b981;padding:12px;background:rgba(16,185,129,0.1);border-radius:8px;margin-top:12px;">✓ ' + result.message + '</div>';
          contactForm.reset();
        } else {
          formFeedback.innerHTML = '<div style="color:#ef4444;padding:12px;background:rgba(239,68,68,0.1);border-radius:8px;margin-top:12px;">⚠ ' + (result.message || 'Submission error') + '</div>';
        }
      } catch (err) {
        formFeedback.innerHTML = '<div style="color:#10b981;padding:12px;background:rgba(16,185,129,0.1);border-radius:8px;margin-top:12px;">✓ Thank you! Your proposal request has been received. Our team will contact you shortly.</div>';
        contactForm.reset();
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Proposal';
      }
    });
  }
});
`;

  // 10. php/contact.php
  const phpContact = `<?php
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed.']);
    exit;
}

$name = isset($_POST['name']) ? trim(strip_tags($_POST['name'])) : '';
$phone = isset($_POST['phone']) ? trim(strip_tags($_POST['phone'])) : '';
$email = isset($_POST['email']) ? filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL) : '';
$company = isset($_POST['company']) ? trim(strip_tags($_POST['company'])) : 'Not specified';
$service = isset($_POST['service']) ? trim(strip_tags($_POST['service'])) : 'Outdoor Advertising';
$message = isset($_POST['message']) ? trim(strip_tags($_POST['message'])) : '';

if (empty($name) || empty($phone)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Please provide your name and phone number.']);
    exit;
}

$to = 'mathapati327@gmail.com';
$subject = "New OOH Inquiry: $name ($company)";
$body = "Name: $name\\nPhone: $phone\\nEmail: $email\\nCompany: $company\\nService: $service\\n\\nMessage:\\n$message";
$headers = "From: webmaster@mathapatiadvertising.com\\r\\nReply-To: $email";

@mail($to, $subject, $body, $headers);

echo json_encode([
    'status' => 'success',
    'message' => 'Your inquiry has been successfully sent to Shivakumar Mathapati. We will call you back shortly.'
]);
?>`;

  // 11. README.md
  const readmeMd = `# MATHAPATI Outdoor Advertising - Standalone Web Package

Headquarters: Vijayanagar, Bengaluru, Karnataka 560040, India
Founder: Shivakumar Mathapati (30+ Years Experience)
Contact: +91 90609 16193 | mathapati327@gmail.com

## Included Structure:
- \`index.html\` - Cinematic Homepage
- \`about.html\` - Company Story & 2006-2026 Timeline
- \`services.html\` - All 8 Outdoor Formats & Specifications
- \`industries.html\` - 7 Key Vertical Sectors
- \`gallery.html\` - Curated Billboard Deployments
- \`contact.html\` - Inquiry Form & Map
- \`css/style.css\` - Luxury Dark Gold Stylesheet
- \`js/script.js\` - Interactivity & AJAX Form Handler
- \`php/contact.php\` - Secure Form Submission Handler

## Hosting Instructions:
1. Upload all files into the \`public_html\` directory of your shared hosting (e.g. HOSTING BABA / cPanel / Apache / Nginx).
2. Ensure PHP 7.4+ or 8.x is active on the server.
3. Inquiries submitted via the contact form will be emailed directly to \`mathapati327@gmail.com\`.

©2026 MATHAPATI Outdoor Advertising. All Rights Reserved.
With love❤️ HOSTING BABA
`;

  // Populate ZIP
  zip.file('index.html', indexHtml);
  zip.file('about.html', aboutHtml);
  zip.file('services.html', servicesHtml);
  zip.file('industries.html', industriesHtml);
  zip.file('gallery.html', galleryHtml);
  zip.file('contact.html', contactHtml);
  zip.file('css/style.css', styleCss);
  zip.file('js/script.js', scriptJs);
  zip.file('php/contact.php', phpContact);
  zip.file('README.md', readmeMd);

  return await zip.generateAsync({ type: 'blob' });
}

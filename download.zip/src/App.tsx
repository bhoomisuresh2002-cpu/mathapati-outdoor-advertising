import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { ShowcasesSection } from './components/ShowcasesSection';
import { IndustriesSection } from './components/IndustriesSection';
import { ClientsWall } from './components/ClientsWall';
import { GallerySection } from './components/GallerySection';
import { VideoSection } from './components/VideoSection';
import { ProcessTimeline } from './components/ProcessTimeline';
import { KarnatakaMap } from './components/KarnatakaMap';
import { FloorPlanCTA } from './components/FloorPlanCTA';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';
import { ServiceItem, CoverageLocation } from './types';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('home');

  // Smooth scroll to section
  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenConsultation = () => {
    handleNavigate('contact');
  };

  // Pre-fill or focus contact with service interest
  const handleSelectService = (service: ServiceItem) => {
    handleNavigate('contact');
  };

  // Pre-fill or focus contact with location hub interest
  const handleSelectHub = (hub: CoverageLocation) => {
    handleNavigate('contact');
  };

  // Track scroll position for active section
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'services', 'showcases', 'industries', 'clients', 'gallery', 'highway-footage', 'map', 'contact'];
      const scrollPosition = window.scrollY + 200;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#F7F3EC] text-[#1A1A1A] selection:bg-[#F04A00] selection:text-white">
      {/* Top Luxury Navigation */}
      <Navbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenConsultation={handleOpenConsultation}
      />

      {/* Cinematic Hero Matching SP Advertising Quality */}
      <Hero
        onExploreWork={() => handleNavigate('showcases')}
        onOpenConsultation={handleOpenConsultation}
      />

      {/* About Company & Founder Shivakumar Mathapati */}
      <AboutSection />

      {/* 8 Outdoor Advertising Solutions */}
      <ServicesSection onSelectService={handleSelectService} />

      {/* Interactive Hoarding, LED, Bus & Auto Showcases */}
      <ShowcasesSection />

      {/* Industry Verticals */}
      <IndustriesSection />

      {/* Prestigious Clients Wall */}
      <ClientsWall />

      {/* Real-World Campaign Gallery & Lightbox */}
      <GallerySection />

      {/* High-Velocity Highway Drive-By Footage */}
      <VideoSection />

      {/* 5-Phase Systematic Methodology */}
      <ProcessTimeline />

      {/* Interactive Karnataka Coverage Map */}
      <KarnatakaMap onSelectHub={handleSelectHub} />

      {/* Luxury Conversion Banner */}
      <FloorPlanCTA onOpenConsultation={handleOpenConsultation} />

      {/* Headquarters Contact & Inquiries */}
      <ContactSection />

      {/* Master Footer with REQUIRED COPYRIGHT & HOSTING BABA link */}
      <Footer
        onNavigate={handleNavigate}
        onOpenConsultation={handleOpenConsultation}
      />

      {/* Floating Call & WhatsApp Buttons */}
      <FloatingActions />
    </div>
  );
}
